package com.linuxexplorer.files

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Clip(val files: List<File>, val cut: Boolean)

sealed interface Screen {
    data object Browser : Screen
    data object Settings : Screen
    data object Apps : Screen
    data class Editor(val file: File) : Screen
    data object Terminal : Screen
}

sealed interface DialogState {
    data class Input(
        val title: String, val initial: String, val confirm: String = "OK",
        val password: Boolean = false, val validate: (String) -> String? = { null },
        val onOk: (String) -> Unit
    ) : DialogState
    data class Confirm(val title: String, val text: String, val confirm: String = "OK", val onOk: () -> Unit) : DialogState
    data class Message(val title: String, val text: String) : DialogState
    data class Choice(val title: String, val options: List<Pair<String, String>>, val selected: String?, val onPick: (String) -> Unit) : DialogState
    data class Properties(val file: File) : DialogState
    data class Compress(val files: List<File>) : DialogState
    data class ArchiveMenu(val file: File) : DialogState
    data class ArchiveBrowse(val file: File, val password: String?, val entries: List<Archive.Entry>) : DialogState
    data class PickDir(val title: String, val start: File, val onPick: (File) -> Unit) : DialogState
}

class FileViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var settings by mutableStateOf(prefs.load()); private set
    val roots: List<Pair<String, File>> = FileOps.storageRoots(app)
    val internalRoot: File = FileOps.internalRoot()

    var dir by mutableStateOf(internalRoot); private set
    var items by mutableStateOf<List<File>>(emptyList()); private set
    /** Size/date/type of each listed file, read on a background thread (set just before [items]). */
    private var meta: Map<String, FileMeta> = emptyMap()
    fun metaOf(f: File): FileMeta = meta[f.path] ?: FileMeta(f, f.isDirectory, f.length(), f.lastModified(), FileOps.kind(f))

    var apps by mutableStateOf<List<AppEntry>>(emptyList()); private set
    var appsLoading by mutableStateOf(false); private set
    var loading by mutableStateOf(false); private set
    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var query by mutableStateOf(""); private set
    var searching by mutableStateOf(false); private set
    var clip by mutableStateOf<Clip?>(null); private set
    var dialog by mutableStateOf<DialogState?>(null)
    var busy by mutableStateOf<String?>(null); private set
    var screen by mutableStateOf<Screen>(Screen.Browser)
    val terminal = TerminalSession()
    fun openTerminal() { terminal.open(dir); screen = Screen.Terminal }
    var message by mutableStateOf<String?>(null)

    private val history = ArrayDeque<File>()
    private var loadJob: Job? = null

    val canGoBack get() = history.isNotEmpty()
    val atRoot get() = roots.any { it.second.path == dir.path }
    val selectedFiles get() = items.filter { it.path in selected }
    val currentRoot: File get() = roots.map { it.second }.filter { dir.path.startsWith(it.path) }.maxByOrNull { it.path.length } ?: internalRoot

    init { refresh() }

    /* ---------- navigation ---------- */

    fun refresh() {
        loadJob?.cancel()
        val s = settings; val q = query; val d = dir
        loadJob = viewModelScope.launch {
            loading = true
            val metas = withContext(Dispatchers.IO) { FileOps.listMeta(d, s, q) { !isActive } }
            meta = metas.associateBy { it.file.path }
            val list = metas.map { it.file }
            items = list
            val paths = list.map { it.path }.toSet()
            selected = selected.filter { it in paths }.toSet()
            loading = false
        }
    }

    fun navigate(to: File, push: Boolean = true) {
        if (!to.isDirectory) { message = "Folder not found"; return }
        if (push && to.path != dir.path) history.addLast(dir)
        dir = to; selected = emptySet(); query = ""; searching = false
        refresh()
    }

    fun back() { history.removeLastOrNull()?.let { navigate(it, push = false) } }
    fun up() { if (!atRoot) dir.parentFile?.let { navigate(it) } }

    fun updateQuery(q: String) { query = q; refresh() }
    fun startSearch() { searching = true }
    fun stopSearch() { searching = false; if (query.isNotEmpty()) { query = ""; refresh() } }

    /* ---------- selection ---------- */

    fun toggle(f: File) { selected = if (f.path in selected) selected - f.path else selected + f.path }
    fun select(f: File) { selected = selected + f.path }
    fun clearSelection() { selected = emptySet() }
    fun selectAll() { selected = items.map { it.path }.toSet() }
    fun invertSelection() { selected = items.map { it.path }.toSet() - selected }

    /* ---------- settings ---------- */

    fun update(block: (Settings) -> Settings) {
        val old = settings
        settings = block(old); prefs.save(settings)
        if (old.sort != settings.sort || old.desc != settings.desc || old.foldersFirst != settings.foldersFirst ||
            old.showHidden != settings.showHidden) refresh()
    }

    fun resetSettings() { settings = Settings(favorites = settings.favorites); prefs.save(settings); refresh() }

    fun isFavorite(f: File) = f.path in settings.favorites
    fun toggleFavorite(f: File) = update {
        it.copy(favorites = if (f.path in it.favorites) it.favorites - f.path else it.favorites + f.path)
    }

    /* ---------- opening ---------- */

    fun open(f: File) {
        when {
            f.isDirectory -> navigate(f)
            FileOps.isArchive(f) -> dialog = DialogState.ArchiveMenu(f)
            FileOps.isText(f) -> if (f.length() <= 2_000_000) screen = Screen.Editor(f) else openWith(f)
            else -> openWith(f)
        }
    }

    fun openWith(f: File) {
        try { app.startActivity(FileOps.openIntent(app, f)) }
        catch (e: ActivityNotFoundException) { message = "No app can open this file" }
        catch (e: Exception) { message = "Cannot open: ${e.message}" }
    }

    fun share(files: List<File>) {
        if (files.none { it.isFile }) { message = "Select files (folders can't be shared directly)"; return }
        try { app.startActivity(FileOps.shareIntent(app, files)) } catch (e: Exception) { message = "Cannot share: ${e.message}" }
    }

    fun openFolderIn(f: File) { screen = Screen.Browser; navigate(f) }

    /* ---------- apps ---------- */

    fun loadApps() {
        if (appsLoading) return
        viewModelScope.launch {
            appsLoading = true
            apps = withContext(Dispatchers.IO) { runCatching { AppIcons.installedApps(app) }.getOrDefault(emptyList()) }
            appsLoading = false
        }
    }

    fun backupApk(a: AppEntry) = work("Backing up ${a.label}") {
        val dir = File(FileOps.internalRoot(), "Download/Apps")
        dir.mkdirs()
        val safe = (a.label + "_" + a.version).replace(Regex("[^A-Za-z0-9._-]"), "_")
        val out = File(dir, "$safe.apk")
        File(a.apk).copyTo(out, overwrite = true)
        "Saved to Download/Apps/${out.name}"
    }

    fun openAppData(pkg: String) {
        val root = FileOps.internalRoot()
        val candidates = listOf(File(root, "Android/data/$pkg"), File(root, "Android/media/$pkg"))
        val d = candidates.firstOrNull { it.isDirectory && it.listFiles() != null }
        if (d != null) openFolderIn(d) else message = "Android doesn't allow access to this app's data folder on this device"
    }

    /* ---------- background work ---------- */

    private fun work(title: String, block: suspend (progress: (String) -> Unit) -> String?) {
        viewModelScope.launch {
            busy = title
            val result = try {
                withContext(Dispatchers.IO) { block { step -> busy = "$title\n$step" } }
            } catch (e: PasswordRequired) { "Password required" }
            catch (e: Exception) { "Failed: ${e.message ?: e.javaClass.simpleName}" }
            busy = null
            if (result != null) message = result
            refresh()
        }
    }

    /* ---------- file actions ---------- */

    fun newFolder() = ask("New folder", "Untitled folder", "Create") { name ->
        val f = File(dir, name)
        message = if (f.mkdirs()) null else "Could not create folder"
        refresh()
    }

    fun newFile() = ask("New file", "untitled.txt", "Create") { name ->
        try { File(dir, name).createNewFile(); refresh() } catch (e: Exception) { message = "Could not create file: ${e.message}" }
    }

    fun newDocument() = ask("New document", "untitled.txt", "Create") { name ->
        val f = File(dir, name)
        try { f.createNewFile(); refresh(); screen = Screen.Editor(f) } catch (e: Exception) { message = "Could not create file: ${e.message}" }
    }

    private fun ask(title: String, initial: String, confirm: String, ok: (String) -> Unit) {
        dialog = DialogState.Input(title, initial, confirm, validate = { n ->
            FileOps.nameError(n) ?: if (File(dir, n).exists()) "A file with that name already exists" else null
        }, onOk = ok)
    }

    fun rename(f: File) {
        dialog = DialogState.Input("Rename", f.name, "Rename", validate = { n ->
            FileOps.nameError(n) ?: if (n != f.name && File(f.parentFile, n).exists()) "A file with that name already exists" else null
        }) { n ->
            message = if (f.renameTo(File(f.parentFile, n))) null else "Rename failed"
            clearSelection(); refresh()
        }
    }

    fun copy(files: List<File>) { clip = Clip(files, false); clearSelection() }
    fun cut(files: List<File>) { clip = Clip(files, true); clearSelection() }

    fun paste() { clip?.let { c -> transfer(c.files, dir, c.cut); clip = null } }

    fun transfer(files: List<File>, dest: File, move: Boolean) {
        clearSelection()
        work(if (move) "Moving…" else "Copying…") { progress ->
            var n = 0; var skipped = 0
            files.forEach { f ->
                val bad = (f.isDirectory && FileOps.isInside(f, dest)) || (move && f.parentFile?.canonicalPath == dest.canonicalPath)
                if (bad) { skipped++ } else {
                    if (move) FileOps.moveTo(f, dest, progress) else FileOps.copyTo(f, dest, progress)
                    n++
                }
            }
            "$n item(s) ${if (move) "moved" else "copied"}" + if (skipped > 0) " · $skipped skipped" else ""
        }
    }

    fun pickAndTransfer(files: List<File>, move: Boolean) {
        dialog = DialogState.PickDir(if (move) "Move to…" else "Copy to…", dir) { transfer(files, it, move) }
    }

    fun duplicate(files: List<File>) {
        clearSelection()
        work("Duplicating…") { progress ->
            files.forEach { FileOps.copyTo(it, it.parentFile ?: dir, progress) }
            "${files.size} item(s) duplicated"
        }
    }

    fun delete(files: List<File>) {
        val run = {
            clearSelection()
            work("Deleting…") { progress ->
                var failed = 0
                files.forEach { progress(it.name); if (!it.deleteRecursively()) failed++ }
                if (failed > 0) "$failed item(s) could not be deleted" else "${files.size} item(s) deleted"
            }
        }
        if (settings.confirmDelete) dialog = DialogState.Confirm(
            "Delete", "Permanently delete ${files.size} item(s)? This cannot be undone.", "Delete") { run() }
        else run()
    }

    /* ---------- archives ---------- */

    fun compress(files: List<File>, name: String, format: String, password: String?) {
        clearSelection()
        val dest = File(dir, FileOps.uniqueName(dir, name))
        work("Compressing…") { progress ->
            Archive.create(files, dest, format, password, progress)
            "Created ${dest.name}"
        }
    }

    fun extract(archive: File, dest: File, password: String?) {
        work("Extracting…") { progress ->
            Archive.extract(archive, dest, password, progress)
            "Extracted to ${dest.name}"
        }
    }

    /** Runs [then] with a password if the archive needs one, asking the user first. */
    fun withPassword(archive: File, then: (String?) -> Unit) {
        if (!Archive.needsPassword(archive)) { then(null); return }
        dialog = DialogState.Input("Password for ${archive.name}", "", "OK", password = true) { then(it) }
    }

    fun browseArchive(archive: File) = withPassword(archive) { pw ->
        viewModelScope.launch {
            busy = "Reading archive…"
            val r = withContext(Dispatchers.IO) { runCatching { Archive.list(archive, pw) } }
            busy = null
            r.onSuccess { dialog = DialogState.ArchiveBrowse(archive, pw, it) }
                .onFailure { message = "Cannot open archive: ${it.message}" }
        }
    }

    fun extractHere(archive: File) = withPassword(archive) { extract(archive, dir, it) }
    fun extractToFolder(archive: File) = withPassword(archive) { extract(archive, File(dir, FileOps.uniqueName(dir, Archive.baseName(archive))), it) }
    fun extractTo(archive: File) = withPassword(archive) { pw ->
        dialog = DialogState.PickDir("Extract to…", dir) { d -> extract(archive, d, pw) }
    }

    /* ---------- misc ---------- */

    fun goToPath() {
        dialog = DialogState.Input("Go to path", dir.path, "Go") { p ->
            val f = File(p.trim())
            if (f.isDirectory) navigate(f) else message = "Folder not found"
        }
    }
}
