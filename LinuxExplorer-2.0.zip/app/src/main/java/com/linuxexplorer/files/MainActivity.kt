package com.linuxexplorer.files

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import android.os.Bundle

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(0xFF263238.toInt()))
        setContent { App(onExit = { finish() }) }
    }
}

@Composable
private fun App(onExit: () -> Unit) {
    val vm: FileViewModel = viewModel()
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(FileOps.hasAllFilesAccess(ctx)) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                val now = FileOps.hasAllFilesAccess(ctx)
                if (now && !granted) vm.refresh()
                granted = now
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val dark = isDarkTheme(vm.settings.theme)
    val bar = barStyle(vm.settings, dark)
    val activity = ctx as? ComponentActivity
    SideEffect {

        val onTerm = vm.screen is Screen.Terminal
        val onView = vm.screen is Screen.Viewer
        val tcol = termColors(vm.settings).bg
        val argb = if (onView) Color.Black.toArgb() else if (onTerm) tcol.toArgb() else bar.container.toArgb()
        val lightIcons = if (onView) true else if (onTerm) tcol.luminance() < .5f else bar.content == Color.White
        activity?.enableEdgeToEdge(
            statusBarStyle = if (lightIcons) SystemBarStyle.dark(argb) else SystemBarStyle.light(argb, argb))
    }

    LxTheme(vm.settings) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!granted) {
                PermissionScreen { granted = it; if (it) vm.refresh() }
            } else {
                when (val s = vm.screen) {
                    is Screen.Browser -> BrowserScreen(vm, onExit)
                    is Screen.Settings -> SettingsScreen(vm)
                    is Screen.Apps -> AppsScreen(vm)
                    is Screen.Editor -> EditorScreen(vm, s.file)
                    is Screen.Terminal -> TerminalScreen(vm)
                    is Screen.Viewer -> ViewerScreen(vm, s.file)
                }
                Dialogs(vm)
            }
        }
    }
}

@Composable
private fun PermissionScreen(onResult: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        onResult(FileOps.hasAllFilesAccess(ctx))
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.app_logo), null, Modifier.size(96.dp))
        Spacer(Modifier.height(24.dp))
        Text("Linux Explorer", fontSize = 24.sp, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(
            "To browse, edit, copy, move, compress and extract files anywhere on your device, " +
                    "Linux Explorer needs access to all files on your storage.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) {
                val i = Intent(AndroidSettings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
                try { ctx.startActivity(i) }
                catch (e: Exception) { ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            } else {
                legacy.launch(arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text("Allow access to all files") }
    }
}
