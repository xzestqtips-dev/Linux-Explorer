package com.linuxexplorer.files

import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.rememberTextMeasurer
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream

class TermLine(val kind: Int, val text: String, val path: String? = null)

class TermSug(val name: String, val kind: Int)

class TerminalSession {
    val lines = mutableStateListOf<TermLine>()
    var cwd by mutableStateOf(File("/"))
    var running by mutableStateOf(false)
    var tf by mutableStateOf(TextFieldValue(""))
    var input: String
        get() = tf.text
        set(v) { tf = TextFieldValue(v, TextRange(v.length)); typed = "" }
    var copyRequest by mutableStateOf(false)

    var typed = ""
    var usePriv: () -> Boolean = { false }
    private var started = false
    private val history = ArrayList<String>()
    private var histPos = -1
    @Volatile private var proc: Process? = null
    private val main = Handler(Looper.getMainLooper())
    private val home: File = Environment.getExternalStorageDirectory()
    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    fun open(dir: File) {
        if (!started) {
            started = true
            cwd = dir
            listOf(
                "Welcome to Linux Explorer Terminal!", "",
                "Shell:   Android sh (/system/bin/sh)",
                "Help:    tap ? (top right) or type 'help'",
                "Keys:    CTRL + C stops a command, TAB completes names", ""
            ).forEach { lines.add(TermLine(0, it)) }
            if (usePriv()) lines.add(TermLine(3, "-- privileged shell active (${Priv.label})"))
        } else if (dir.path != cwd.path && !running) {
            cwd = dir
            lines.add(TermLine(3, "-- now in ${dir.path}"))
        }
    }

    fun shortPath(): String =
        if (cwd.path == home.path) "~" else if (cwd.path.startsWith(home.path + "/")) "~" + cwd.path.removePrefix(home.path) else cwd.path

    private fun post(l: TermLine) = main.post {
        lines.add(l)
        if (lines.size > 3000) lines.removeRange(0, lines.size - 3000)
    }

    fun submit(): Boolean {
        val cmd = input
        input = ""
        histPos = -1
        if (running) {
            lines.add(TermLine(0, cmd))
            try { proc?.outputStream?.let { it.write((cmd + "\n").toByteArray()); it.flush() } } catch (_: Throwable) {}
            return false
        }
        lines.add(TermLine(2, cmd, shortPath()))
        val c = cmd.trim()
        if (c.isEmpty()) return false
        if (history.lastOrNull() != c) history.add(c)
        val word = c.substringBefore(' ')
        val rest = c.substringAfter(' ', "").trim()
        when (word) {
            "exit", "logout" -> return true
            "clear", "cls" -> lines.clear()
            "cd" -> cd(rest)
            "history" -> history.forEachIndexed { i, h -> lines.add(TermLine(0, "%4d  %s".format(i + 1, h))) }
            "copy" -> copyRequest = true
            "help" -> HELP.forEach { lines.add(TermLine(3, it)) }
            else -> run(c)
        }
        return false
    }

    private fun cd(arg: String) {
        val a = arg.trim('"', '\'')
        val target = when {
            a.isEmpty() || a == "~" -> home
            a.startsWith("~/") -> File(home, a.substring(2))
            a.startsWith("/") -> File(a)
            else -> File(cwd, a)
        }
        val t = try { target.canonicalFile } catch (e: Exception) { target }
        if (t.isDirectory || (usePriv() && Priv.isDir(t.path))) cwd = t else lines.add(TermLine(1, "cd: $a: No such file or directory"))
    }

    private fun run(cmd: String) {
        running = true
        val dir = cwd
        val priv = usePriv()
        Thread {
            try {
                val p = if (priv) Priv.start(cmd, dir) else {
                    val pb = ProcessBuilder("/system/bin/sh", "-c", cmd).directory(dir)
                    pb.environment().apply { put("HOME", home.path); put("PWD", dir.path); put("TERM", "dumb") }
                    pb.start()
                }
                proc = p
                val t1 = pump(p.inputStream, 0)
                val t2 = pump(p.errorStream, 1)
                val code = p.waitFor()
                t1.join(800); t2.join(800)
                if (code != 0) post(TermLine(3, "[exit $code]"))
            } catch (e: Throwable) {
                post(TermLine(1, "sh: ${e.message}"))
            } finally {
                proc = null
                main.post { running = false }
            }
        }.start()
    }

    private fun pump(s: InputStream, kind: Int): Thread = Thread {
        try { s.bufferedReader().forEachLine { post(TermLine(kind, ansi.replace(it, ""))) } } catch (_: Throwable) {}
    }.also { it.start() }

    fun interrupt() {
        val p = proc
        if (p == null) { input = ""; lines.add(TermLine(3, "^C")); return }
        lines.add(TermLine(3, "^C"))
        p.destroy()
        Thread { try { Thread.sleep(800); if (p.isAlive) p.destroyForcibly() } catch (_: Throwable) {} }.start()
    }

    fun historyUp() {
        if (history.isEmpty()) return
        histPos = if (histPos < 0) history.size - 1 else maxOf(0, histPos - 1)
        input = history[histPos]
    }

    fun historyDown() {
        if (histPos < 0) return
        histPos++
        if (histPos >= history.size) { histPos = -1; input = "" } else input = history[histPos]
    }

    private fun cur() = tf.selection.start
    fun moveCursor(pos: Int) { tf = tf.copy(selection = TextRange(pos.coerceIn(0, tf.text.length))) }
    fun insert(str: String) {
        val a = tf.selection.min; val b = tf.selection.max
        tf = TextFieldValue(tf.text.substring(0, a) + str + tf.text.substring(b), TextRange(a + str.length))
        typed = tf.text
    }
    fun home() = moveCursor(0)
    fun end() = moveCursor(tf.text.length)
    fun left() = moveCursor(cur() - 1)
    fun right() = moveCursor(cur() + 1)

    private fun wordStart(from: Int): Int {
        var i = from
        while (i > 0 && tf.text[i - 1] == ' ') i--
        while (i > 0 && tf.text[i - 1] != ' ') i--
        return i
    }

    private fun wordEnd(from: Int): Int {
        var i = from
        while (i < tf.text.length && tf.text[i] == ' ') i++
        while (i < tf.text.length && tf.text[i] != ' ') i++
        return i
    }

    fun ctrl(ch: Char): Boolean {
        val t = tf.text
        val c = cur()
        when (ch.lowercaseChar()) {
            'c' -> interrupt()
            'l' -> lines.clear()
            'd' -> if (t.isEmpty()) return true
            'u' -> tf = TextFieldValue(t.substring(c), TextRange(0))
            'k' -> tf = TextFieldValue(t.substring(0, c), TextRange(c))
            'w' -> { val w = wordStart(c); tf = TextFieldValue(t.substring(0, w) + t.substring(c), TextRange(w)) }
            'a' -> home()
            'e' -> end()
            'p' -> historyUp()
            'n' -> historyDown()
        }
        return false
    }

    fun alt(ch: Char) {
        when (ch.lowercaseChar()) {
            'b' -> moveCursor(wordStart(cur()))
            'f' -> moveCursor(wordEnd(cur()))
        }
    }

    fun complete() {
        val s = input
        val idx = s.lastIndexOf(' ') + 1
        val word = s.substring(idx)
        val slash = word.lastIndexOf('/')
        val dirPart = if (slash >= 0) word.substring(0, slash + 1) else ""
        val prefix = word.substring(slash + 1)
        val base = when {
            dirPart.startsWith("~") -> File(home, dirPart.removePrefix("~").trimStart('/'))
            dirPart.startsWith("/") -> File(dirPart)
            dirPart.isEmpty() -> cwd
            else -> File(cwd, dirPart)
        }
        val all = base.list()?.toList() ?: (if (usePriv()) Priv.names(base) else null) ?: return
        val names = all.filter { it.startsWith(prefix) }.sorted()
        if (names.isEmpty()) return
        val esc = { n: String -> n.replace(" ", "\\ ") }
        if (names.size == 1) {
            val f = File(base, names[0])
            input = s.substring(0, idx) + dirPart + esc(names[0]) + if (f.isDirectory) "/" else " "
        } else {
            val common = names.reduce { a, b -> a.commonPrefixWith(b) }
            if (common.length > prefix.length) input = s.substring(0, idx) + dirPart + esc(common)
            lines.add(TermLine(0, names.joinToString("  ") { if (File(base, it).isDirectory) "$it/" else it }))
        }
    }

    private class Word(val start: Int, val quote: Char, val dir: String, val prefix: String, val cmd: Boolean, val verb: String)

    private fun parse(s: String): Word {
        var start = 0
        var q = '\u0000'
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (q == '\u0000') {
                when (ch) {
                    '\\' -> i++
                    '"', '\'' -> q = ch
                    ' ', '|', ';', '&', '<', '>' -> start = i + 1
                }
            } else if (ch == '\\' && q == '"') i++
            else if (ch == q) q = '\u0000'
            i++
        }
        val raw = s.substring(start)
        val quote = if (q != '\u0000' && raw.isNotEmpty() && raw[0] == q) q else '\u0000'
        val word = if (quote != '\u0000') raw.substring(1) else raw.replace(Regex("\\\\(.)"), "\$1")
        val slash = word.lastIndexOf('/')
        val head = s.substring(0, start)
        val seg = head.substring(head.lastIndexOfAny(charArrayOf('|', ';', '&', '(')) + 1).trim()
        return Word(start, quote, word.substring(0, slash + 1), word.substring(slash + 1), seg.isEmpty(), seg.substringBefore(' '))
    }

    private fun escape(n: String) = buildString {
        for (ch in n) { if (ch in " ()&;|<>'\"\$`\\*?[]!#") append('\\'); append(ch) }
    }

    fun suggest(text: String, cursor: Int, dir: File, priv: Boolean): List<TermSug> {
        val w = parse(text.substring(0, cursor.coerceIn(0, text.length)))
        val p = w.prefix
        if (w.cmd && w.dir.isEmpty() && !p.startsWith(".") && !p.startsWith("~")) {
            if (p.isEmpty()) return emptyList()
            val hits = COMMANDS.filter { it.startsWith(p, ignoreCase = true) }
            if (hits.size == 1 && hits[0] == p) return emptyList()
            return hits.take(60).map { TermSug(it, 0) }
        }
        if (w.dir.isEmpty() && p.isEmpty()) return emptyList()
        val base = when {
            w.dir.startsWith("~") -> File(home, w.dir.removePrefix("~").trimStart('/'))
            w.dir.startsWith("/") -> File(w.dir)
            w.dir.isEmpty() -> dir
            else -> File(dir, w.dir)
        }
        val all = base.list()?.toList() ?: (if (priv) Priv.names(base) else null) ?: return emptyList()
        val pool = all.filter { p.startsWith(".") || !it.startsWith(".") }
        val front = pool.filter { it.startsWith(p, ignoreCase = true) }.sortedBy { it.lowercase() }
        val inside = if (p.length < 2) emptyList() else
            pool.filter { !it.startsWith(p, ignoreCase = true) && it.contains(p, ignoreCase = true) }.sortedBy { it.lowercase() }
        val foldersOnly = !w.cmd && w.verb == "cd"
        val out = ArrayList<TermSug>()
        for (n in front + inside) {
            val isDir = File(base, n).isDirectory
            if (foldersOnly && !isDir && !priv) continue
            out.add(TermSug(n, if (isDir || (foldersOnly && priv)) 2 else 1))
            if (out.size >= 60) break
        }
        if (out.size == 1 && out[0].kind != 2 && out[0].name == p) return emptyList()
        return out
    }

    fun accept(sg: TermSug) {
        val cur = tf.selection.end.coerceIn(0, tf.text.length)
        val before = tf.text.substring(0, cur)
        val after = tf.text.substring(cur)
        val w = parse(before)
        val raw = before.substring(w.start)
        val slash = raw.lastIndexOf('/')
        val keep = if (slash >= 0) raw.substring(0, slash + 1) else if (w.quote != '\u0000') w.quote.toString() else ""
        val name = if (w.quote == '\u0000') escape(sg.name) else sg.name
        val space = if (after.startsWith(" ")) "" else " "
        val end = when {
            sg.kind == 2 -> "/"
            w.quote != '\u0000' -> w.quote + space
            else -> space
        }
        val line = before.substring(0, w.start) + keep + name + end
        tf = TextFieldValue(line + after, TextRange(line.length))
        if (sg.kind == 2) typed = tf.text
    }

    companion object {
        val HELP = listOf(
            "Built-in:  cd  clear  copy  history  help  exit",
            "Everything else runs in Android's shell, e.g. ls -la, cp, mv, rm, cat, grep, find,",
            "tar, chmod, ping, df, du, ps, top -n 1, getprop, pm list packages, am start ...",
            "Tab completes file names, Up/Down browse history, CTRL-C stops a running command.",
            "While a command is running, what you type is sent to it as input.",
            "No apt/git/python: Android doesn't ship them. Run scripts with: sh script.sh"
        )

        private val BUILTIN = listOf("cd", "clear", "copy", "exit", "help", "history")
        private val COMMON = listOf(
            "am", "cat", "chmod", "chown", "cp", "cut", "date", "df", "du", "echo", "find", "getprop", "grep", "head",
            "id", "kill", "ln", "ls", "mkdir", "mv", "ping", "pm", "ps", "pwd", "rm", "rmdir", "sh", "sort", "stat",
            "tail", "tar", "top", "touch", "uname", "wc", "whoami"
        )
        private val CMD_NAME = Regex("[A-Za-z0-9_.+-]+")

        private val COMMANDS: List<String> by lazy {
            val found = HashSet<String>()
            for (d in listOf("/system/bin", "/system/xbin")) File(d).list()?.forEach { if (CMD_NAME.matches(it)) found.add(it) }
            val first = (BUILTIN + COMMON.filter { found.isEmpty() || it in found }).distinct().sorted()
            first + found.filter { it !in first }.sorted()
        }
    }
}

class TermColors(val bg: Color, val fg: Color, val user: Color, val path: Color, val err: Color, val info: Color)

private fun tc(bg: Long, fg: Long, user: Long, path: Long, err: Long, info: Long) =
    TermColors(Color(bg), Color(fg), Color(user), Color(path), Color(err), Color(info))

val TERM_SCHEMES: LinkedHashMap<String, Pair<String, TermColors>> = linkedMapOf(
    "termux" to ("Termux" to tc(0xFF000000, 0xFFFFFFFF, 0xFF4CAF50, 0xFF4CAF50, 0xFFFF6B6B, 0xFF9E9E9E)),
    "classic" to ("Classic" to tc(0xFF000000, 0xFFD7D7D7, 0xFF4EC94E, 0xFF5C9CFF, 0xFFFF6B6B, 0xFF8A8A8A)),
    "ubuntu" to ("Ubuntu" to tc(0xFF300A24, 0xFFEEEEEE, 0xFF8AE234, 0xFF729FCF, 0xFFEF2929, 0xFFAD7FA8)),
    "solarized" to ("Solarized Dark" to tc(0xFF002B36, 0xFF93A1A1, 0xFF859900, 0xFF268BD2, 0xFFDC322F, 0xFF657B83)),
    "dracula" to ("Dracula" to tc(0xFF282A36, 0xFFF8F8F2, 0xFF50FA7B, 0xFFBD93F9, 0xFFFF5555, 0xFF6272A4)),
    "matrix" to ("Matrix" to tc(0xFF000000, 0xFF00D84A, 0xFF00FF66, 0xFF00B341, 0xFFFF5252, 0xFF007A2B)),
    "amber" to ("Amber" to tc(0xFF1A0F00, 0xFFFFB000, 0xFFFFC940, 0xFFFFA000, 0xFFFF6B3D, 0xFFA66F00)),
    "light" to ("Light" to tc(0xFFFAFAFA, 0xFF2B2B2B, 0xFF2E7D32, 0xFF1565C0, 0xFFC62828, 0xFF777777))
)

fun termColors(s: Settings): TermColors = (TERM_SCHEMES[s.termScheme] ?: TERM_SCHEMES.getValue("classic")).second

val NAME_RE = Regex("^[A-Za-z0-9_.-]{1,20}$")

private fun termStyle(c: TermColors, s: Settings): TextStyle {
    val (fs, lh) = when (s.termFont) { "small" -> 12 to 16; "large" -> 16 to 21; "xl" -> 18 to 24; else -> 14 to 18 }
    return TextStyle(fontFamily = FontFamily.Monospace, fontSize = fs.sp, lineHeight = lh.sp, color = c.fg)
}

private fun baseName(path: String) = if (path == "~" || path == "/") path else path.substringAfterLast('/')

fun promptSpans(s: Settings, c: TermColors, path: String): AnnotatedString = buildAnnotatedString {
    val sym = if (s.termUser == "root") "#" else "\$"
    val id = s.termUser + "@" + s.termHost
    when (s.termPrompt) {
        "termux" -> {
            withStyle(SpanStyle(color = c.path)) { append(path) }
            withStyle(SpanStyle(color = c.fg)) { append(" $sym ") }
        }
        "fedora" -> {
            withStyle(SpanStyle(color = c.fg)) { append("[") }
            withStyle(SpanStyle(color = c.user, fontWeight = FontWeight.Bold)) { append(id) }
            withStyle(SpanStyle(color = c.path)) { append(" " + baseName(path)) }
            withStyle(SpanStyle(color = c.fg)) { append("]$sym ") }
        }
        "zsh" -> {
            withStyle(SpanStyle(color = c.user, fontWeight = FontWeight.Bold)) { append("➜ ") }
            withStyle(SpanStyle(color = c.path, fontWeight = FontWeight.Bold)) { append(" " + baseName(path) + " ") }
        }
        else -> {
            withStyle(SpanStyle(color = c.user, fontWeight = FontWeight.Bold)) { append(id) }
            withStyle(SpanStyle(color = c.fg)) { append(":") }
            withStyle(SpanStyle(color = c.path, fontWeight = FontWeight.Bold)) { append(path) }
            withStyle(SpanStyle(color = c.fg)) { append("$sym ") }
        }
    }
}

fun promptPlain(s: Settings, path: String): String = promptSpans(s, termColors(s), path).text

@Composable
fun TermText(l: TermLine, s: Settings, c: TermColors) {
    val text = if (l.kind == 2) buildAnnotatedString { append(promptSpans(s, c, l.path ?: "~")); append(l.text) }
    else AnnotatedString(l.text.ifEmpty { " " })
    Text(text, style = termStyle(c, s), color = when (l.kind) { 1 -> c.err; 3 -> c.info; else -> c.fg })
}

@Composable
private fun RowScope.TermKey(label: String, c: TermColors, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.weight(1f).height(46.dp)
            .background(if (active) c.fg.copy(alpha = .25f) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = c.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
}

private val GUIDE: List<Pair<String, List<Pair<String, String>>>> = listOf(
    "THE BASICS" to listOf(
        "" to "Type a command and press Enter. The result shows up above the prompt.",
        "" to "Commands run in Android's own shell: much like Linux, with fewer tools.",
        "" to "~ is your internal storage."
    ),
    "SUGGESTIONS" to listOf(
        "" to "While you type, matching commands, files and folders show above the line.",
        "UP / DOWN" to "move through the list",
        "ENTER" to "fill in the highlighted one (it does not run it)",
        "TAP" to "fill in the one you touch",
        "ESC" to "hide the list",
        "" to "Nothing highlighted? Enter runs the line as you typed it.",
        "" to "Settings > Terminal can turn the list off."
    ),
    "GETTING AROUND" to listOf(
        "pwd" to "show the folder you are in",
        "ls" to "list what is in this folder",
        "ls -la" to "same, with hidden files, sizes and dates",
        "cd Download" to "go into a folder",
        "cd .." to "go up one level",
        "cd ~" to "back to internal storage"
    ),
    "FILES AND FOLDERS" to listOf(
        "mkdir photos" to "make a folder",
        "touch notes.txt" to "make an empty file",
        "cp a.txt b.txt" to "copy a file (cp -r for a folder)",
        "mv a.txt Docs/" to "move it; mv a.txt b.txt renames",
        "rm a.txt" to "delete a file. There is no trash, it is gone",
        "rm -r old" to "delete a folder and everything in it",
        "cat a.txt" to "print a file (head and tail show the ends)"
    ),
    "LOOKING FOR THINGS" to listOf(
        "find . -name \"*.jpg\"" to "search by name, from here downwards",
        "grep -ri hello ." to "search inside files for a word",
        "du -sh *" to "how big each item here is",
        "df -h" to "free space on each storage"
    ),
    "GOOD TO KNOW" to listOf(
        "" to "Names with a space need quotes: cd \"My Folder\"",
        "" to "Upper and lower case count. Download is not download.",
        "" to "Pipes and > work: ls | grep png, or ls > list.txt",
        "" to "Run a script with: sh script.sh",
        "" to "While a command runs, what you type is sent to it.",
        "" to "apt, git and python are not on Android.",
        "" to "To look inside Android/data from here, turn on Shizuku or root in Settings."
    ),
    "BUILT IN" to listOf(
        "help" to "short command list",
        "clear" to "wipe the screen",
        "copy" to "put all the output on the clipboard",
        "history" to "commands you typed before",
        "exit" to "leave the terminal"
    ),
    "KEYS" to listOf(
        "TAB" to "finish a file or folder name",
        "UP / DOWN" to "step through earlier commands (or the list, when it is open)",
        "CTRL, then C" to "stop a running command",
        "CTRL, then L" to "clear the screen",
        "CTRL, then U" to "delete everything before the cursor",
        "CTRL, then A / E" to "jump to start / end of the line",
        "ALT, then B / F" to "move back / forward one word"
    )
)

@Composable
private fun TermGuide(c: TermColors, s: Settings, modifier: Modifier = Modifier) {
    val st = termStyle(c, s)
    Column(
        modifier.background(c.bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState())
            .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 20.dp)
    ) {
        Text("How to use the terminal", style = st, color = c.fg, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(end = 44.dp, top = 6.dp))
        GUIDE.forEach { (title, items) ->
            Text(title, style = st, color = c.path, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
            items.forEach { (cmd, text) ->
                if (cmd.isEmpty()) {
                    Text(text, style = st, color = c.fg, modifier = Modifier.padding(bottom = 5.dp))
                } else {
                    Column(Modifier.padding(bottom = 7.dp)) {
                        Text(cmd, style = st, color = c.user)
                        Text(text, style = st, color = c.fg.copy(alpha = .75f), modifier = Modifier.padding(start = 16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SuggestPopup(
    items: List<TermSug>, sel: Int, c: TermColors, style: TextStyle,
    modifier: Modifier = Modifier, onPick: (TermSug) -> Unit
) {
    val density = LocalDensity.current
    val rowH = with(density) { style.lineHeight.toDp() } + 10.dp
    val scroll = rememberScrollState()

    LaunchedEffect(sel) {
        if (sel < 0) return@LaunchedEffect
        val row = with(density) { rowH.roundToPx() }
        val view = (row * 5.5f).toInt()
        val top = sel * row
        if (top < scroll.value) scroll.scrollTo(top)
        else if (top + row > scroll.value + view) scroll.scrollTo(top + row - view)
    }
    val shape = RoundedCornerShape(4.dp)
    Column(
        modifier.widthIn(min = 120.dp, max = 300.dp).width(IntrinsicSize.Max)
            .heightIn(max = rowH * 5.5f)
            .clip(shape).background(c.bg).border(1.dp, c.fg.copy(alpha = .4f), shape)
            .verticalScroll(scroll)
    ) {
        items.forEachIndexed { i, sg ->
            Box(
                Modifier.fillMaxWidth().height(rowH)
                    .background(if (i == sel) c.fg.copy(alpha = .22f) else Color.Transparent)
                    .clickable { onPick(sg) }
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    if (sg.kind == 2) sg.name + "/" else sg.name, style = style,
                    color = if (sg.kind == 2) c.path else c.fg, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TermHelpButton(label: String, c: TermColors, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.size(46.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).semantics { contentDescription = "Terminal help" },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(28.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(c.bg.copy(alpha = .9f))
                .border(1.dp, c.fg.copy(alpha = .45f), RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) { Text(label, color = c.fg, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun TerminalScreen(vm: FileViewModel) {
    val t = vm.terminal
    val s = vm.settings
    val c = termColors(s)
    val style = termStyle(c, s)
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var showHelp by rememberSaveable { mutableStateOf(false) }
    val density = LocalDensity.current
    var areaWin by remember { mutableStateOf<Rect?>(null) }
    var promptWin by remember { mutableStateOf<Rect?>(null) }
    val promptShown by remember { derivedStateOf { promptWin != null } }
    var popupH by remember { mutableIntStateOf(0) }
    var dismissedFor by remember { mutableStateOf<String?>(null) }
    var sel by remember(t.tf.text) { mutableIntStateOf(-1) }

    val wantSugg = s.termSuggest && !t.running && t.tf.text.isNotEmpty() && t.tf.text == t.typed
    val found by produceState(emptyList<TermSug>(), t.tf.text, t.tf.selection.end, t.cwd.path, wantSugg) {
        if (!wantSugg) { value = emptyList(); return@produceState }
        val text = t.tf.text
        val cur = t.tf.selection.end
        val dir = t.cwd
        val priv = t.usePriv()
        if (priv) delay(120)
        value = withContext(Dispatchers.IO) { t.suggest(text, cur, dir, priv) }
    }
    val popupOpen = wantSugg && found.isNotEmpty() && dismissedFor != t.tf.text && promptShown && !showHelp
    val selIdx = if (sel in found.indices) sel else -1

    fun moveSel(d: Int) {
        val n = found.size + 1
        sel = (((selIdx + 1 + d) % n) + n) % n - 1
    }

    fun popupOffset(): IntOffset {
        val p = promptWin ?: return IntOffset.Zero
        val a = areaWin ?: return IntOffset.Zero
        val gap = with(density) { 4.dp.toPx() }
        val above = p.top - a.top - gap - popupH
        val y = if (above >= 0f) above else p.bottom - a.top + gap
        return IntOffset((p.left - a.left).roundToInt(), y.roundToInt().coerceIn(0, maxOf(0, (a.height - popupH).roundToInt())))
    }
    var ctrl by remember { mutableStateOf(false) }
    var alt by remember { mutableStateOf(false) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val measurer = rememberTextMeasurer()
    val charW = remember(style) { measurer.measure("M", style).size.width.toFloat() }

    BackHandler { vm.screen = Screen.Browser }
    BackHandler(enabled = showHelp) { showHelp = false; focus.requestFocus() }
    LaunchedEffect(t.lines.size) { listState.scrollToItem(t.lines.size) }
    LaunchedEffect(Unit) { if (!showHelp) focus.requestFocus() }
    LaunchedEffect(t.copyRequest) {
        if (t.copyRequest) {
            clipboard.setText(AnnotatedString(t.lines.joinToString("\n") {
                if (it.kind == 2) promptPlain(s, it.path ?: "~") + it.text else it.text }))
            t.copyRequest = false
            t.lines.add(TermLine(3, "[output copied to clipboard]"))
        }
    }

    fun page(dir: Int) = scope.launch {
        val n = maxOf(1, listState.layoutInfo.visibleItemsInfo.size - 1)
        listState.scrollToItem((listState.firstVisibleItemIndex + dir * n).coerceIn(0, t.lines.size))
    }

    Column(Modifier.fillMaxSize().background(c.bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { areaWin = it.boundsInWindow() }) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize()
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { focus.requestFocus() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                items(t.lines.size) { i -> TermText(t.lines[i], s, c) }
                item {
                    DisposableEffect(Unit) { onDispose { promptWin = null } }
                    Row(Modifier.onGloballyPositioned { promptWin = it.boundsInWindow() }, verticalAlignment = Alignment.Top) {
                        if (t.running) Text("> ", style = style, color = c.info)
                        else Text(promptSpans(s, c, t.shortPath()), style = style)
                        BasicTextField(
                            value = t.tf,
                            onValueChange = { v ->
                                val old = t.tf.text
                                val nt = v.text.replace("\n", "")
                                val typed = nt.length == old.length + 1 && v.selection.collapsed && v.selection.start > 0
                                if ((ctrl || alt) && typed) {
                                    val ch = nt[v.selection.start - 1]
                                    if (ctrl) { if (t.ctrl(ch)) vm.screen = Screen.Browser } else t.alt(ch)
                                    ctrl = false; alt = false
                                } else {
                                    t.typed = nt
                                    t.tf = if (nt == v.text) v else v.copy(text = nt, selection = TextRange(nt.length))
                                }
                            },
                            textStyle = style,
                            cursorBrush = SolidColor(Color.Transparent),
                            onTextLayout = { layout = it },
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (popupOpen && selIdx >= 0) t.accept(found[selIdx])
                                else if (t.submit()) vm.screen = Screen.Browser
                            }),
                            modifier = Modifier.weight(1f).focusRequester(focus).drawBehind {

                                val l = layout ?: return@drawBehind
                                val off = t.tf.selection.start.coerceIn(0, l.layoutInput.text.length)
                                val r = l.getCursorRect(off)
                                drawRect(c.fg.copy(alpha = .85f), Offset(r.left, r.top), Size(charW, r.height))
                            }
                        )
                    }
                }
            }
            if (popupOpen) {
                SuggestPopup(
                    found, selIdx, c, style,
                    Modifier.onSizeChanged { popupH = it.height }
                        .graphicsLayer { alpha = if (popupH == 0) 0f else 1f }
                        .offset { popupOffset() },
                    onPick = { t.accept(it); focus.requestFocus() }
                )
            }
            if (showHelp) TermGuide(c, s, Modifier.fillMaxSize())
            TermHelpButton(if (showHelp) "x" else "?", c, Modifier.align(Alignment.TopEnd)) {
                if (showHelp) { showHelp = false; focus.requestFocus() }
                else { showHelp = true; focusManager.clearFocus() }
            }
        }

        Row(Modifier.fillMaxWidth()) {
            TermKey("ESC", c) {
                if (popupOpen) dismissedFor = t.tf.text
                else { t.input = ""; ctrl = false; alt = false }
            }
            TermKey("/", c) { t.insert("/") }
            TermKey("—", c) { t.insert("-") }
            TermKey("HOME", c) { t.home() }
            TermKey("↑", c) { if (popupOpen) moveSel(-1) else t.historyUp() }
            TermKey("END", c) { t.end() }
            TermKey("PGUP", c) { page(-1) }
        }
        Row(Modifier.fillMaxWidth()) {
            TermKey("⇥", c) { if (popupOpen && selIdx >= 0) t.accept(found[selIdx]) else t.complete() }
            TermKey("CTRL", c, ctrl) { ctrl = !ctrl; if (ctrl) alt = false }
            TermKey("ALT", c, alt) { alt = !alt; if (alt) ctrl = false }
            TermKey("←", c) { t.left() }
            TermKey("↓", c) { if (popupOpen) moveSel(1) else t.historyDown() }
            TermKey("→", c) { t.right() }
            TermKey("PGDN", c) { page(1) }
        }
    }
}
