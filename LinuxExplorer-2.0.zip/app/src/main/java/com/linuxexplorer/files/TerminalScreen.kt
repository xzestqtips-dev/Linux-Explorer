package com.linuxexplorer.files

import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.InputStream

/* ---------------- session (survives leaving the screen) ---------------- */

/** kind: 0 output, 1 error, 2 command (echoed with its prompt), 3 info */
class TermLine(val kind: Int, val text: String, val path: String? = null)

class TerminalSession {
    val lines = mutableStateListOf<TermLine>()
    var cwd by mutableStateOf(File("/"))
    var running by mutableStateOf(false)
    var input by mutableStateOf("")
    private var started = false
    private val history = ArrayList<String>()
    private var histPos = -1
    @Volatile private var proc: Process? = null
    private val main = Handler(Looper.getMainLooper())
    private val home: File = Environment.getExternalStorageDirectory()
    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]")

    fun open(dir: File) {
        if (!started) {
            started = true
            cwd = dir
            lines.add(TermLine(3, "Linux Explorer Terminal  (Android shell: /system/bin/sh)"))
            lines.add(TermLine(3, "Type 'help' for the built-in commands."))
        } else if (dir.path != cwd.path && !running) {
            cwd = dir
            lines.add(TermLine(3, "-- now in ${dir.path}"))
        }
    }

    fun shortPath(): String =
        if (cwd.path == home.path) "~" else if (cwd.path.startsWith(home.path + "/")) "~" + cwd.path.removePrefix(home.path) else cwd.path

    private fun post(l: TermLine) = main.post {
        lines.add(l)
        if (lines.size > 3000) lines.removeRange(0, lines.size - 3000)
    }

    /** Runs the typed line. Returns true when the user asked to exit. */
    fun submit(): Boolean {
        val cmd = input
        input = ""
        histPos = -1
        if (running) { // forward to the running program's stdin
            lines.add(TermLine(0, cmd))
            try { proc?.outputStream?.let { it.write((cmd + "\n").toByteArray()); it.flush() } } catch (_: Throwable) {}
            return false
        }
        lines.add(TermLine(2, cmd, shortPath()))
        val c = cmd.trim()
        if (c.isEmpty()) return false
        if (history.lastOrNull() != c) history.add(c)
        val word = c.substringBefore(' ')
        val rest = c.substringAfter(' ', "").trim()
        when (word) {
            "exit", "logout" -> return true
            "clear", "cls" -> lines.clear()
            "cd" -> cd(rest)
            "history" -> history.forEachIndexed { i, h -> lines.add(TermLine(0, "%4d  %s".format(i + 1, h))) }
            "help" -> HELP.forEach { lines.add(TermLine(3, it)) }
            else -> run(c)
        }
        return false
    }

    private fun cd(arg: String) {
        val a = arg.trim('"', '\'')
        val target = when {
            a.isEmpty() || a == "~" -> home
            a.startsWith("~/") -> File(home, a.substring(2))
            a.startsWith("/") -> File(a)
            else -> File(cwd, a)
        }
        val t = try { target.canonicalFile } catch (e: Exception) { target }
        if (t.isDirectory) cwd = t else lines.add(TermLine(1, "cd: $a: No such file or directory"))
    }

    private fun run(cmd: String) {
        running = true
        val dir = cwd
        Thread {
            try {
                val pb = ProcessBuilder("/system/bin/sh", "-c", cmd).directory(dir)
                pb.environment().apply { put("HOME", home.path); put("PWD", dir.path); put("TERM", "dumb") }
                val p = pb.start()
                proc = p
                val t1 = pump(p.inputStream, 0)
                val t2 = pump(p.errorStream, 1)
                val code = p.waitFor()
                t1.join(800); t2.join(800)
                if (code != 0) post(TermLine(3, "[exit $code]"))
            } catch (e: Throwable) {
                post(TermLine(1, "sh: ${e.message}"))
            } finally {
                proc = null
                main.post { running = false }
            }
        }.start()
    }

    private fun pump(s: InputStream, kind: Int): Thread = Thread {
        try { s.bufferedReader().forEachLine { post(TermLine(kind, ansi.replace(it, ""))) } } catch (_: Throwable) {}
    }.also { it.start() }

    /** Ctrl-C */
    fun interrupt() {
        val p = proc
        if (p == null) { input = ""; lines.add(TermLine(3, "^C")); return }
        lines.add(TermLine(3, "^C"))
        p.destroy()
        Thread { try { Thread.sleep(800); if (p.isAlive) p.destroyForcibly() } catch (_: Throwable) {} }.start()
    }

    fun historyUp() {
        if (history.isEmpty()) return
        histPos = if (histPos < 0) history.size - 1 else maxOf(0, histPos - 1)
        input = history[histPos]
    }

    fun historyDown() {
        if (histPos < 0) return
        histPos++
        if (histPos >= history.size) { histPos = -1; input = "" } else input = history[histPos]
    }

    /** Tab completion for the last word (file and folder names). */
    fun complete() {
        val s = input
        val idx = s.lastIndexOf(' ') + 1
        val word = s.substring(idx)
        val slash = word.lastIndexOf('/')
        val dirPart = if (slash >= 0) word.substring(0, slash + 1) else ""
        val prefix = word.substring(slash + 1)
        val base = when {
            dirPart.startsWith("~") -> File(home, dirPart.removePrefix("~").trimStart('/'))
            dirPart.startsWith("/") -> File(dirPart)
            dirPart.isEmpty() -> cwd
            else -> File(cwd, dirPart)
        }
        val names = base.list()?.filter { it.startsWith(prefix) }?.sorted() ?: return
        if (names.isEmpty()) return
        val esc = { n: String -> n.replace(" ", "\\ ") }
        if (names.size == 1) {
            val f = File(base, names[0])
            input = s.substring(0, idx) + dirPart + esc(names[0]) + if (f.isDirectory) "/" else " "
        } else {
            val common = names.reduce { a, b -> a.commonPrefixWith(b) }
            if (common.length > prefix.length) input = s.substring(0, idx) + dirPart + esc(common)
            lines.add(TermLine(0, names.joinToString("  ") { if (File(base, it).isDirectory) "$it/" else it }))
        }
    }

    fun promptText(path: String?) = "user@android:${path ?: "~"}\$ "

    companion object {
        val HELP = listOf(
            "Built-in:  cd  clear  history  help  exit",
            "Everything else runs in Android's shell, e.g. ls -la, cp, mv, rm, cat, grep, find,",
            "tar, chmod, ping, df, du, ps, top -n 1, getprop, pm list packages, am start ...",
            "Tab completes file names, Up/Down browse history, CTRL-C stops a running command.",
            "While a command is running, what you type is sent to it as input.",
            "No apt/git/python: Android doesn't ship them. Run scripts with: sh script.sh"
        )
    }
}

/* ---------------- screen ---------------- */

private val TermBg = Color(0xFF000000)
private val TermFg = Color(0xFFD7D7D7)
private val TermGreen = Color(0xFF4EC94E)
private val TermBlue = Color(0xFF5C9CFF)
private val TermRed = Color(0xFFFF6B6B)
private val TermGrey = Color(0xFF8A8A8A)
private val TermStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 17.sp, color = TermFg)

/** Dark rounded square with a ">_" prompt, like the Termux icon. */
@Composable
fun TerminalBadge(size: Dp) {
    val shape = RoundedCornerShape(size / 5)
    Box(Modifier.size(size).clip(shape).background(Color.Black).border(1.dp, Color(0xFF666666), shape),
        contentAlignment = Alignment.Center) {
        Text(">_", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.46f).sp)
    }
}

private fun prompt(path: String): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(color = TermGreen, fontWeight = FontWeight.Bold)) { append("user@android") }
    withStyle(SpanStyle(color = Color.White)) { append(":") }
    withStyle(SpanStyle(color = TermBlue, fontWeight = FontWeight.Bold)) { append(path) }
    withStyle(SpanStyle(color = Color.White)) { append("\$ ") }
}

@Composable
private fun TermText(l: TermLine) {
    val text = if (l.kind == 2) buildAnnotatedString { append(prompt(l.path ?: "~")); append(l.text) }
    else AnnotatedString(l.text.ifEmpty { " " })
    Text(text, style = TermStyle, color = when (l.kind) { 1 -> TermRed; 3 -> TermGrey; else -> TermFg })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(vm: FileViewModel) {
    val t = vm.terminal
    val clipboard = LocalClipboardManager.current
    val bar = LocalBar.current
    val listState = rememberLazyListState()
    val focus = remember { FocusRequester() }
    BackHandler { vm.screen = Screen.Browser }
    LaunchedEffect(t.lines.size) { listState.scrollToItem(t.lines.size) }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bar.container, titleContentColor = bar.content,
                    navigationIconContentColor = bar.content, actionIconContentColor = bar.content),
                navigationIcon = { IconButton({ vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                title = { Text("Terminal") },
                actions = {
                    IconButton({
                        clipboard.setText(AnnotatedString(t.lines.joinToString("\n") {
                            if (it.kind == 2) t.promptText(it.path) + it.text else it.text }))
                        vm.message = "Terminal output copied"
                    }) { Icon(Icons.Filled.ContentCopy, "Copy all") }
                    IconButton({ t.lines.clear() }) { Icon(Icons.Filled.DeleteSweep, "Clear") }
                })
        },
        containerColor = TermBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().navigationBarsPadding().imePadding()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth()
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { focus.requestFocus() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                items(t.lines.size) { i -> TermText(t.lines[i]) }
                item {
                    Row(verticalAlignment = Alignment.Top) {
                        if (t.running) Text("> ", style = TermStyle, color = TermGrey)
                        else Text(prompt(t.shortPath()), style = TermStyle)
                        BasicTextField(
                            value = t.input,
                            onValueChange = { t.input = it.replace("\n", "") },
                            textStyle = TermStyle.copy(color = Color.White),
                            cursorBrush = SolidColor(Color.White),
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { if (t.submit()) vm.screen = Screen.Browser }),
                            modifier = Modifier.weight(1f).focusRequester(focus)
                        )
                    }
                }
            }
            // extra keys row
            Row(Modifier.fillMaxWidth().background(Color(0xFF1A1A1A)).horizontalScroll(rememberScrollState()).padding(vertical = 2.dp)) {
                @Composable
                fun key(label: String, onClick: () -> Unit) = Text(
                    label, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp))
                key("ESC") { t.input = "" }
                key("TAB") { t.complete() }
                key("CTRL-C") { t.interrupt() }
                key("↑") { t.historyUp() }
                key("↓") { t.historyDown() }
                listOf("~", "/", "-", "|", "&", ">", "*", "\"").forEach { k -> key(k) { t.input += k } }
            }
        }
    }
}
