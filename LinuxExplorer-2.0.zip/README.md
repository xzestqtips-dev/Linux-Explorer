# Linux Explorer

Linux Explorer is an Android file manager built with Kotlin and Jetpack Compose.

## Build and run

1. Open the project in Android Studio and let Gradle finish syncing.
2. Run it on a device or emulator running Android 8.0 or newer, or choose **Build APK(s)** from the Build menu.
3. On Android 11 and newer, grant the app access to all files when prompted.
4. To build a smaller release, run `./gradlew assembleRelease -Pminify=true`.

## Features

- Browse internal storage, SD cards, USB storage, and common folders.
- Use list, grid, compact, or detailed list layouts; sort files and folders; show hidden files; and search recursively.
- Select multiple items to copy, move, rename, duplicate, delete, share, or inspect their properties.
- Create, browse, and extract ZIP, TAR, TAR.GZ, TAR.BZ2, TAR.XZ, 7Z, and GZ archives. Extraction blocks path-traversal entries.
- Edit text and code with line numbers, syntax coloring, undo and redo, find and replace, and save-as support.
- Browse files in the built-in image viewer, with zoom, rotation, slideshow, and sharing controls.
- Use the terminal, browse installed apps, and back up APK files.
- Open unsupported file types with compatible apps installed on Android.
- Customize the list appearance, file-name colors, row dividers, start folder, top-bar title, and image previews.

## Storage access

The app supports standard Android storage permissions. Access to `Android/data` and `Android/obb` depends on Android's folder-picker restrictions. On versions where Android blocks access through the picker, Shizuku or root access may be needed.
