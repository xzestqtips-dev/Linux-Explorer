package com.linuxexplorer.files

import android.content.Context

data class Settings(

    val theme: String = "system",
    val accent: String = "slate",
    val accentC: String = "#263238",
    val amoled: Boolean = false,
    val abStyle: String = "accent",
    val folderColor: String = "blue",
    val radius: String = "normal",

    val fz: String = "medium",
    val uz: String = "medium",
    val userFont: String = "",
    val fw: String = "regular",
    val ls: String = "normal",
    val nameLines: String = "trunc",
    val boldDirs: Boolean = false,
    val monoNames: Boolean = false,

    val view: String = "list",
    val density: String = "comfortable",
    val iconSize: String = "medium",
    val gridSize: String = "medium",
    val showSize: Boolean = true,
    val showDate: Boolean = true,
    val showExt: Boolean = true,
    val folderCount: Boolean = true,
    val showCrumbs: Boolean = true,
    val showStatus: Boolean = false,
    val showFab: Boolean = false,
    val dividers: Boolean = false,
    val thumbs: Boolean = true,
    val barTitle: String = "app",
    val startIn: String = "internal",

    val sort: String = "name",
    val desc: Boolean = false,
    val foldersFirst: Boolean = true,
    val showHidden: Boolean = false,
    val binaryUnits: Boolean = true,
    val dateFmt: String = "iso",
    val longPress: Boolean = true,
    val confirmDelete: Boolean = true,

    val showPerms: Boolean = false,
    val dirSlash: Boolean = false,
    val dircolors: Boolean = false,
    val pathStyle: String = "friendly",

    val termScheme: String = "termux",
    val termFont: String = "medium",
    val termUser: String = "user",
    val termHost: String = "android",
    val termPrompt: String = "termux",
    val termKeys: Boolean = true,
    val termSuggest: Boolean = true,

    val privMode: String = "saf",
    val termPriv: Boolean = false,

    val imgViewer: Boolean = true,
    val imgBg: String = "black",
    val imgInfo: Boolean = true,
    val imgSlide: String = "3",
    val imgKeepOn: Boolean = true,

    val anim: Boolean = true,
    val ripple: Boolean = true,
    val favorites: List<String> = emptyList()
)

// Saves settings to SharedPreferences. The privMode3 key replaced an older one; loadPriv() carries the old value over.
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lxe_settings", Context.MODE_PRIVATE)

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)

    fun load(): Settings {
        val d = Settings()
        return Settings(
            theme = s("theme", d.theme), accent = s("accent", d.accent), accentC = s("accentC", d.accentC),
            amoled = b("amoled", d.amoled), abStyle = s("abStyle", d.abStyle),
            folderColor = s("folderColor", d.folderColor), radius = s("radius", d.radius),
            fz = s("fz", d.fz), uz = s("uz", d.uz), userFont = s("userFont", d.userFont),
            fw = s("fw", d.fw), ls = s("ls", d.ls), nameLines = s("nameLines", d.nameLines),
            boldDirs = b("boldDirs", d.boldDirs), monoNames = b("monoNames", d.monoNames),
            view = s("view", d.view), density = s("density", d.density),
            iconSize = s("iconSize", d.iconSize), gridSize = s("gridSize", d.gridSize),
            showSize = b("showSize", d.showSize), showDate = b("showDate", d.showDate),
            showExt = b("showExt", d.showExt), folderCount = b("folderCount", d.folderCount),
            showCrumbs = b("showCrumbs", d.showCrumbs), showStatus = b("showStatus2", d.showStatus),
            showFab = b("showFab2", d.showFab), dividers = b("dividers", d.dividers), thumbs = b("thumbs", d.thumbs),
            barTitle = s("barTitle", d.barTitle), startIn = s("startIn", d.startIn),
            sort = s("sort", d.sort), desc = b("desc", d.desc), foldersFirst = b("foldersFirst", d.foldersFirst),
            showHidden = b("showHidden", d.showHidden), binaryUnits = b("binaryUnits", d.binaryUnits),
            dateFmt = s("dateFmt", d.dateFmt), longPress = b("longPress", d.longPress),
            confirmDelete = b("confirmDelete", d.confirmDelete),
            showPerms = b("showPerms", d.showPerms), dirSlash = b("dirSlash", d.dirSlash), dircolors = b("dircolors", d.dircolors), pathStyle = s("pathStyle", d.pathStyle),
            termScheme = s("termScheme2", d.termScheme), termFont = s("termFont", d.termFont),
            termUser = s("termUser", d.termUser), termHost = s("termHost", d.termHost),
            termPrompt = s("termPrompt2", d.termPrompt), termKeys = b("termKeys", d.termKeys), termSuggest = b("termSuggest", d.termSuggest),
            privMode = loadPriv(d), termPriv = b("termPriv", d.termPriv),
            imgViewer = b("imgViewer", d.imgViewer), imgBg = s("imgBg", d.imgBg), imgInfo = b("imgInfo", d.imgInfo),
            imgSlide = s("imgSlide", d.imgSlide), imgKeepOn = b("imgKeepOn", d.imgKeepOn),
            anim = b("anim", d.anim), ripple = b("ripple", d.ripple),
            favorites = s("favorites", "").split('\n').filter { it.isNotBlank() }
        )
    }

    // Moves people across from the older privMode setting without losing a Shizuku or root choice they'd already made.
    private fun loadPriv(d: Settings): String {
        sp.getString("privMode3", null)?.let { return it }
        val old = s("privMode", "off")
        return if (old == "shizuku" || old == "root") old else d.privMode
    }

    var lastDir: String
        get() = sp.getString("lastDir", "") ?: ""
        set(v) { sp.edit().putString("lastDir", v).apply() }

    fun save(v: Settings) {
        sp.edit()
            .putString("theme", v.theme).putString("accent", v.accent).putString("accentC", v.accentC)
            .putBoolean("amoled", v.amoled).putString("abStyle", v.abStyle)
            .putString("folderColor", v.folderColor).putString("radius", v.radius)
            .putString("fz", v.fz).putString("uz", v.uz).putString("userFont", v.userFont)
            .putString("fw", v.fw).putString("ls", v.ls).putString("nameLines", v.nameLines)
            .putBoolean("boldDirs", v.boldDirs).putBoolean("monoNames", v.monoNames)
            .putString("view", v.view).putString("density", v.density)
            .putString("iconSize", v.iconSize).putString("gridSize", v.gridSize)
            .putBoolean("showSize", v.showSize).putBoolean("showDate", v.showDate)
            .putBoolean("showExt", v.showExt).putBoolean("folderCount", v.folderCount)
            .putBoolean("showCrumbs", v.showCrumbs).putBoolean("showStatus2", v.showStatus)
            .putBoolean("showFab2", v.showFab).putBoolean("dividers", v.dividers).putBoolean("thumbs", v.thumbs)
            .putString("barTitle", v.barTitle).putString("startIn", v.startIn)
            .putString("sort", v.sort).putBoolean("desc", v.desc).putBoolean("foldersFirst", v.foldersFirst)
            .putBoolean("showHidden", v.showHidden).putBoolean("binaryUnits", v.binaryUnits)
            .putString("dateFmt", v.dateFmt).putBoolean("longPress", v.longPress)
            .putBoolean("confirmDelete", v.confirmDelete)
            .putBoolean("showPerms", v.showPerms).putBoolean("dirSlash", v.dirSlash).putBoolean("dircolors", v.dircolors).putString("pathStyle", v.pathStyle)
            .putString("termScheme2", v.termScheme).putString("termFont", v.termFont)
            .putString("termUser", v.termUser).putString("termHost", v.termHost)
            .putString("termPrompt2", v.termPrompt).putBoolean("termKeys", v.termKeys).putBoolean("termSuggest", v.termSuggest)
            .putString("privMode3", v.privMode).putBoolean("termPriv", v.termPriv)
            .putBoolean("imgViewer", v.imgViewer).putString("imgBg", v.imgBg).putBoolean("imgInfo", v.imgInfo)
            .putString("imgSlide", v.imgSlide).putBoolean("imgKeepOn", v.imgKeepOn)
            .putBoolean("anim", v.anim).putBoolean("ripple", v.ripple)
            .putString("favorites", v.favorites.joinToString("\n"))
            .apply()
    }
}
