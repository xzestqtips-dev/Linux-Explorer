package com.linuxexplorer.files

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.LruCache
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

// Loads and rotates pictures for the viewer. It reads the EXIF orientation so phone photos come up the right way round.
object ImageLoader {

    class Loaded(val bmp: Bitmap, val w: Int, val h: Int)

    private const val MAX_SIDE = 2048

    private val cache = object : LruCache<String, Loaded>(
        (Runtime.getRuntime().maxMemory() / 5L).toInt().coerceAtMost(96 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: Loaded): Int = value.bmp.allocationByteCount
    }
    private val gate = Semaphore(2)

    fun exifOrientation(open: () -> InputStream?): Int = try {
        open()?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } ?: 1
    } catch (e: Throwable) { 1 }

    fun applyExif(b: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            2 -> m.postScale(-1f, 1f)
            3 -> m.postRotate(180f)
            4 -> { m.postRotate(180f); m.postScale(-1f, 1f) }
            5 -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            6 -> m.postRotate(90f)
            7 -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            8 -> m.postRotate(-90f)
            else -> return b
        }
        return try { Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true) } catch (e: Throwable) { b }
    }

    private fun decode(open: () -> InputStream?, ext: String): Loaded? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var s = 1
        while (bounds.outWidth / s > MAX_SIDE || bounds.outHeight / s > MAX_SIDE) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        val raw = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orient = if (ext == "jpg" || ext == "jpeg" || ext == "heic" || ext == "heif") exifOrientation(open) else 1
        val swap = orient in 5..8
        return Loaded(applyExif(raw, orient),
            if (swap) bounds.outHeight else bounds.outWidth, if (swap) bounds.outWidth else bounds.outHeight)
    }

    private fun decodeFile(f: File, m: FileMeta): Loaded? = try {
        val open: () -> InputStream? =
            if (m.priv && Priv.routes(f)) ({ Priv.openIn(f) })
            else ({ try { FileInputStream(f) } catch (e: Exception) { null } })
        decode(open, FileOps.ext(f))
    } catch (e: Throwable) { null }

    private fun rotate(l: Loaded, deg: Int): Loaded {
        val m = Matrix().apply { postRotate(deg.toFloat()) }
        val b = try { Bitmap.createBitmap(l.bmp, 0, 0, l.bmp.width, l.bmp.height, m, true) } catch (e: Throwable) { return l }
        return if (deg % 180 == 0) Loaded(b, l.w, l.h) else Loaded(b, l.h, l.w)
    }

    suspend fun load(f: File, m: FileMeta, rotation: Int): Loaded? {
        val key = f.path + "|" + m.modified
        var base: Loaded? = cache.get(key)
        if (base == null) {
            base = gate.withPermit { withContext(Dispatchers.IO) { decodeFile(f, m) } }
            if (base != null) cache.put(key, base)
        }
        if (base == null) return null
        if (rotation % 360 == 0) return base
        return withContext(Dispatchers.IO) { rotate(base, rotation % 360) }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ViewerScreen(vm: FileViewModel, start: File) {
    val s = vm.settings
    val ctx = LocalContext.current

    val list = remember(vm.items) { vm.items.filter { f -> !vm.metaOf(f).isDir && FileOps.isViewable(f) } }
    val latest by rememberUpdatedState(list)
    val startIdx = remember { list.indexOfFirst { it.path == start.path }.coerceAtLeast(0) }
    val pager = rememberPagerState(initialPage = startIdx, pageCount = { latest.size })

    var chrome by remember { mutableStateOf(true) }
    var slide by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val rot = remember { mutableStateMapOf<String, Int>() }
    val dims = remember { mutableStateMapOf<String, String>() }

    BackHandler { vm.screen = Screen.Browser }
    LaunchedEffect(list.isEmpty()) { if (list.isEmpty()) vm.screen = Screen.Browser }

    val activity = ctx as? android.app.Activity
    DisposableEffect(s.imgKeepOn) {
        val w = activity?.window
        if (s.imgKeepOn) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    LaunchedEffect(pager.currentPage, list) {
        val i = pager.currentPage
        for (j in listOf(i + 1, i - 1)) latest.getOrNull(j)?.let { ImageLoader.load(it, vm.metaOf(it), 0) }
    }

    LaunchedEffect(slide, pager.currentPage) {
        if (slide) {
            delay((s.imgSlide.toLongOrNull() ?: 3L) * 1000L)
            val n = latest.size
            if (n > 1) pager.animateScrollToPage((pager.currentPage + 1) % n) else slide = false
        }
    }

    val bg = when (s.imgBg) {
        "theme" -> MaterialTheme.colorScheme.background
        "dark" -> Color(0xFF1B1B1B)
        else -> Color.Black
    }
    val cur = latest.getOrNull(pager.currentPage)
    val info = cur?.let { f ->
        val m = vm.metaOf(f)
        listOfNotNull(
            "${pager.currentPage + 1} / ${latest.size}",
            dims[f.path],
            FileOps.formatSize(m.size, s.binaryUnits),
            FileOps.formatDate(m.modified, s.dateFmt)
        ).joinToString("  ·  ")
    } ?: ""

    Box(Modifier.fillMaxSize().background(bg)) {
        HorizontalPager(
            state = pager, modifier = Modifier.fillMaxSize(),
            key = { latest.getOrNull(it)?.path ?: it }
        ) { page ->
            val f = latest.getOrNull(page)
            if (f != null) ViewerPage(vm, f, rot[f.path] ?: 0,
                onTap = { chrome = !chrome },
                onDims = { path, d -> dims[path] = d })
        }

        AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = fadeIn(), exit = fadeOut()) {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black.copy(alpha = .6f), titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White),
                navigationIcon = { IconButton({ vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                title = { Text(cur?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp) },
                actions = {
                    IconButton({ cur?.let { rot[it.path] = ((rot[it.path] ?: 0) + 90) % 360 } }) { Icon(Icons.Filled.RotateRight, "Rotate") }
                    IconButton({ cur?.let { vm.share(listOf(it)) } }) { Icon(Icons.Filled.Share, "Share") }
                    IconButton({ cur?.let { vm.delete(listOf(it)) } }) { Icon(Icons.Filled.Delete, "Delete") }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (slide) "Stop slideshow" else "Start slideshow") },
                                leadingIcon = { Icon(Icons.Filled.Slideshow, null) },
                                onClick = { menu = false; slide = !slide; if (slide) chrome = false })
                            DropdownMenuItem(
                                text = { Text("Open with…") }, leadingIcon = { Icon(Icons.Filled.Apps, null) },
                                onClick = { menu = false; cur?.let { vm.openExternally(it) } })
                            DropdownMenuItem(
                                text = { Text("Properties") }, leadingIcon = { Icon(Icons.Filled.Info, null) },
                                onClick = { menu = false; cur?.let { vm.dialog = DialogState.Properties(it) } })
                        }
                    }
                }
            )
        }

        AnimatedVisibility(chrome && s.imgInfo && info.isNotEmpty(), Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(), exit = fadeOut()) {
            Text(info, color = Color.White, fontSize = 13.sp, maxLines = 2,
                modifier = Modifier.fillMaxWidth().background(Color.Black.copy(alpha = .6f))
                    .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp))
        }
    }
}

@Composable
private fun ViewerPage(vm: FileViewModel, f: File, rotation: Int, onTap: () -> Unit, onDims: (String, String) -> Unit) {
    val m = vm.metaOf(f)
    var failed by remember(f.path, m.modified) { mutableStateOf(false) }
    val img by produceState<ImageLoader.Loaded?>(null, f.path, m.modified, rotation) {
        val r = ImageLoader.load(f, m, rotation)
        if (r == null) failed = true else { failed = false; value = r }
    }
    LaunchedEffect(img) { img?.let { onDims(f.path, "${it.w}×${it.h}") } }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val l = img
        if (l != null) {
            val ib = remember(l) { l.bmp.asImageBitmap() }
            ZoomImage(ib, onTap)
        } else if (failed) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.BrokenImage, null, Modifier.size(64.dp), tint = Color.White.copy(alpha = .6f))
                Spacer(Modifier.height(12.dp))
                Text("This image can't be shown here", color = Color.White.copy(alpha = .85f))
                TextButton({ vm.openExternally(f) }) { Text("Open with another app") }
            }
        } else {
            CircularProgressIndicator(color = Color.White)
        }
    }
}

// Pinch or double-tap to zoom (up to 6x), drag to pan, and clamp the offset so you can't lose the picture off-screen.
@Composable
private fun ZoomImage(bmp: ImageBitmap, onTap: () -> Unit) {
    var scale by remember(bmp) { mutableFloatStateOf(1f) }
    var offset by remember(bmp) { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, sc: Float): Offset {
        val mx = box.width * (sc - 1f) / 2f
        val my = box.height * (sc - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier.fillMaxSize().clipToBounds()
            .onSizeChanged { box = it }
            .pointerInput(bmp) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { p ->
                        if (scale > 1.05f) { scale = 1f; offset = Offset.Zero }
                        else {
                            val t = 2.5f
                            val c = Offset(box.width / 2f, box.height / 2f)
                            scale = t
                            offset = clamp((c - p) * (t - 1f), t)
                        }
                    })
            }
            .pointerInput(bmp) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val pointers = ev.changes.count { it.pressed }
                        if (pointers >= 2 || scale > 1.01f) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            val cen = ev.calculateCentroid(useCurrent = true)
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            if (ns <= 1.01f) { scale = 1f; offset = Offset.Zero }
                            else {
                                val focal = if (cen.isSpecified) cen - Offset(box.width / 2f, box.height / 2f) else Offset.Zero
                                val ratio = ns / scale
                                offset = clamp(focal - (focal - offset) * ratio + pan, ns)
                                scale = ns
                            }
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        Image(
            bmp, null,
            Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offset.x; translationY = offset.y
            },
            contentScale = ContentScale.Fit)
    }
}
