package com.linuxexplorer.files

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale

class SafNode(val name: String, val isDir: Boolean, val size: Long, val modified: Long)

// Folder access through Android's own picker (the Storage Access Framework).
// From Android 11, apps can't open Android/data directly, but you can pick the folder once and Android remembers.
// This file makes that feel like working with ordinary files.
object Saf {
    const val AUTH = "com.android.externalstorage.documents"
    private const val RW = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION

    private val PATH = Regex("^(.*?)/Android/(data|obb)(?:/(.*))?$")
    private val TREE_ID = Regex("^([^:]+):Android/(data|obb)/?$")

    private var app: Context? = null
    private var sp: SharedPreferences? = null
    private var cache: Set<String> = emptySet()

    var rev by mutableIntStateOf(0)
        private set

    fun init(ctx: Context) {
        if (app != null) return
        app = ctx.applicationContext
        sp = app!!.getSharedPreferences("lxe_saf", Context.MODE_PRIVATE)
        reload()
    }

    private val cr get() = app!!.contentResolver

    class Loc(val vol: String, val type: String, val rel: String) {
        val rootId: String get() = "$vol:Android/$type"
        fun docId(): String = if (rel.isEmpty()) rootId else "$rootId/$rel"
    }

    // Splits a normal path such as /storage/emulated/0/Android/data/com.example into the pieces the picker's document IDs are built from.
    fun locate(f: File): Loc? {
        val m = PATH.matchEntire(f.path) ?: return null
        val base = m.groupValues[1]
        val vol = if (base == FileOps.internalRoot().path || base == "/sdcard" ||
            base == "/storage/self/primary" || base == "/storage/emulated/0") "primary" else File(base).name
        return Loc(vol, m.groupValues[2], m.groupValues[3])
    }

    private fun key(vol: String, type: String) = "$vol|$type"

    // Re-checks which grants Android still remembers. They can vanish if someone revokes them in system settings.
    fun reload() {
        val prefs = sp ?: return
        val perms = try { cr.persistedUriPermissions } catch (e: Exception) { emptyList() }
        val ok = HashSet<String>()
        for ((k, v) in prefs.all) {
            val u = Uri.parse(v as? String ?: continue)
            if (perms.any { it.uri == u && it.isReadPermission && it.isWritePermission }) ok.add(k)
        }
        if (ok != cache) { cache = ok; rev += 1 }
    }

    fun granted(vol: String, type: String): Boolean {
        if (rev < 0) return false
        return cache.contains(key(vol, type))
    }

    fun anyGranted(): Boolean {
        if (rev < 0) return false
        return cache.isNotEmpty()
    }

    fun has(f: File): Boolean = locate(f)?.let { cache.contains(key(it.vol, it.type)) } ?: false

    fun summary(): String = listOf("data", "obb").joinToString("  ·  ") { t ->
        "Android/$t " + if (granted("primary", t)) "✓" else "–"
    }

    private fun tree(loc: Loc): Uri? {
        val s = sp?.getString(key(loc.vol, loc.type), null) ?: return null
        return if (cache.contains(key(loc.vol, loc.type))) Uri.parse(s) else null
    }

    fun requestIntent(vol: String, type: String): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri(AUTH, "$vol:Android/$type"))
            addFlags(RW or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }

    // Called with whatever folder the person picked. Returns an error message, or null if it worked.
    fun accept(uri: Uri): String? {
        val id = try { DocumentsContract.getTreeDocumentId(uri) } catch (e: Exception) { return "That folder won't work here. Try Android › data (or obb)." }
        val m = TREE_ID.matchEntire(id)
            ?: return "Please open Android › data (or obb) and tap “Use this folder”, then “Allow”."
        try { cr.takePersistableUriPermission(uri, RW) }
        catch (e: Exception) { return "Android refused to keep this permission. Try again." }
        sp?.edit()?.putString(key(m.groupValues[1], m.groupValues[2]), uri.toString())?.apply()
        reload()
        rev += 1
        return null
    }

    fun revoke(vol: String, type: String) {
        val k = key(vol, type)
        sp?.getString(k, null)?.let { s -> try { cr.releasePersistableUriPermission(Uri.parse(s), RW) } catch (_: Exception) {} }
        sp?.edit()?.remove(k)?.apply()
        cache = cache - k
        rev += 1
    }

    private val COLS = arrayOf(
        Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED)

    private fun docUri(tree: Uri, id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    private fun node(c: Cursor): SafNode = SafNode(
        c.getString(0) ?: "",
        (c.getString(1) ?: "") == Document.MIME_TYPE_DIR,
        if (c.isNull(2)) 0L else c.getLong(2),
        if (c.isNull(3)) 0L else c.getLong(3))

    fun mimeFor(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(FileOps.ext(name)) ?: "application/octet-stream"

    fun children(dir: File): List<SafNode>? {
        val loc = locate(dir) ?: return null
        val t = tree(loc) ?: return null
        return try {
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(t, loc.docId())
            cr.query(uri, COLS, null, null, null)?.use { c ->
                val out = ArrayList<SafNode>(c.count)
                while (c.moveToNext()) out.add(node(c))
                out
            }
        } catch (e: Exception) { null }
    }

    fun stat(f: File): SafNode? {
        val loc = locate(f) ?: return null
        val t = tree(loc) ?: return null
        return try {
            cr.query(docUri(t, loc.docId()), COLS, null, null, null)?.use { c -> if (c.moveToFirst()) node(c) else null }
        } catch (e: Exception) { null }
    }

    fun listMeta(dir: File, s: Settings, query: String, cancelled: () -> Boolean): List<FileMeta>? {
        val q = query.trim().lowercase(Locale.ROOT)
        val out = ArrayList<FileMeta>()
        fun meta(parent: File, n: SafNode): FileMeta {
            val f = File(parent, n.name)
            return FileMeta(f, n.isDir, if (n.isDir) 0L else n.size, n.modified, FileOps.kind(f, n.isDir), priv = true)
        }
        if (q.isEmpty()) {
            val kids = children(dir) ?: return null
            for (k in kids) if (s.showHidden || !k.name.startsWith(".")) out.add(meta(dir, k))
        } else {
            val stack = ArrayDeque<File>()
            stack.add(dir)
            while (stack.isNotEmpty() && out.size < 1000 && !cancelled()) {
                val d = stack.removeLast()
                val kids = children(d) ?: continue
                for (k in kids) {
                    if (!s.showHidden && k.name.startsWith(".")) continue
                    if (k.name.lowercase(Locale.ROOT).contains(q)) out.add(meta(d, k))
                    if (k.isDir) stack.add(File(d, k.name))
                }
            }
        }
        return FileOps.sortMetas(out, s)
    }

    fun exists(f: File): Boolean = if (has(f)) stat(f) != null else f.exists()

    fun openIn(f: File): InputStream? {
        val loc = locate(f) ?: return null
        val t = tree(loc) ?: return null
        return try { cr.openInputStream(docUri(t, loc.docId())) } catch (e: Exception) { null }
    }

    fun mkdirs(dir: File): Boolean {
        val loc = locate(dir) ?: return false
        val t = tree(loc) ?: return false
        if (stat(dir)?.isDir == true) return true
        if (loc.rel.isEmpty()) return false
        val parent = dir.parentFile ?: return false
        if (!mkdirs(parent)) return false
        val pl = locate(parent) ?: return false
        return try {
            DocumentsContract.createDocument(cr, docUri(t, pl.docId()), Document.MIME_TYPE_DIR, dir.name) != null
        } catch (e: Exception) { false }
    }

    fun createFile(f: File): Boolean {
        val loc = locate(f) ?: return false
        val t = tree(loc) ?: return false
        if (stat(f) != null) return true
        val parent = f.parentFile ?: return false
        if (!mkdirs(parent)) return false
        val pl = locate(parent) ?: return false
        return try {
            DocumentsContract.createDocument(cr, docUri(t, pl.docId()), mimeFor(f.name), f.name) != null
        } catch (e: Exception) { false }
    }

    fun openOut(f: File): OutputStream? {
        if (!createFile(f)) return null
        val loc = locate(f) ?: return null
        val t = tree(loc) ?: return null
        return try { cr.openOutputStream(docUri(t, loc.docId()), "wt") } catch (e: Exception) { null }
    }

    fun rename(f: File, newName: String): Boolean {
        val loc = locate(f) ?: return false
        val t = tree(loc) ?: return false
        return try { DocumentsContract.renameDocument(cr, docUri(t, loc.docId()), newName) != null } catch (e: Exception) { false }
    }

    fun remove(f: File): Boolean {
        if (!has(f)) return f.deleteRecursively()
        val loc = locate(f) ?: return false
        val t = tree(loc) ?: return false
        return try { DocumentsContract.deleteDocument(cr, docUri(t, loc.docId())) } catch (e: Exception) { false }
    }

    private fun isDirAny(f: File) = if (has(f)) stat(f)?.isDir == true else f.isDirectory
    private fun kidsAny(f: File): List<String> =
        if (has(f)) children(f)?.map { it.name } ?: emptyList() else f.list()?.toList() ?: emptyList()
    private fun openInAny(f: File): InputStream? = if (has(f)) openIn(f) else try { f.inputStream() } catch (e: Exception) { null }
    private fun openOutAny(f: File): OutputStream? =
        if (has(f)) openOut(f) else try { f.parentFile?.mkdirs(); f.outputStream() } catch (e: Exception) { null }
    private fun mkdirsAny(f: File): Boolean = if (has(f)) mkdirs(f) else (f.mkdirs() || f.isDirectory)

    private fun uniqueName(dir: File, name: String): String {
        if (!exists(File(dir, name))) return name
        val e = FileOps.ext(name)
        val base = if (e.isEmpty()) name else name.dropLast(e.length + 1)
        var i = 1
        while (true) {
            val n = if (e.isEmpty()) "$base ($i)" else "$base ($i).$e"
            if (!exists(File(dir, n))) return n
            i++
        }
    }

    fun copy(src: File, destDir: File, newName: String? = null, progress: (String) -> Unit = {}): Boolean {
        if (destDir.path == src.path || destDir.path.startsWith(src.path + "/")) return false
        val target = File(destDir, uniqueName(destDir, newName ?: src.name))
        progress(src.name)
        if (isDirAny(src)) {
            val kids = kidsAny(src)
            if (!mkdirsAny(target)) return false
            var ok = true
            for (k in kids) if (!copy(File(src, k), target, null, progress)) ok = false
            return ok
        }
        val i = openInAny(src) ?: return false
        val o = openOutAny(target)
        if (o == null) { try { i.close() } catch (_: Exception) {}; return false }
        return try { i.use { a -> o.use { b -> a.copyTo(b, 64 * 1024) } }; true } catch (e: Exception) { false }
    }

    fun move(src: File, dest: File): Boolean {
        val dp = dest.parentFile ?: return false
        val sp0 = src.parentFile
        if (sp0 != null && sp0.path == dp.path) return if (src.name == dest.name) true else rename(src, dest.name)
        val sl = locate(src); val dl = locate(dp)
        if (sl != null && dl != null && sl.vol == dl.vol && sl.type == dl.type && sp0 != null) {
            val t = tree(sl)
            val pl = locate(sp0)
            if (t != null && pl != null) {
                try {
                    val moved = DocumentsContract.moveDocument(cr, docUri(t, sl.docId()), docUri(t, pl.docId()), docUri(t, dl.docId()))
                    if (moved != null) {
                        return if (dest.name == src.name) true else rename(File(dp, src.name), dest.name)
                    }
                } catch (_: Exception) {  }
            }
        }
        if (!copy(src, dp, dest.name)) return false
        return remove(src)
    }
}
