package com.linuxexplorer.files

import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

// Access to Android/data and Android/obb, which Android keeps away from ordinary apps.
// There are three ways in: the built-in folder picker ("saf"), Shizuku, or root.
// Shizuku and root run shell commands; the folder picker goes through n.kt instead.
object Priv {
    var mode by mutableStateOf("saf")
    var ready by mutableStateOf(false)
    var status by mutableStateOf("Checking…")

    val shell: Boolean get() = (mode == "shizuku" || mode == "root") && ready
    val active: Boolean get() = shell || (mode == "saf" && Saf.anyGranted())
    val label: String get() = when (mode) { "root" -> "root"; "shizuku" -> "Shizuku"; else -> "Built-in" }

    private val PROTECTED = Regex("/Android/(data|obb)(/|$)")
    fun isProtected(f: File) = PROTECTED.containsMatchIn(f.path)

    // True when this path has to take the special-access route instead of plain java.io.File.
    fun routes(f: File): Boolean = isProtected(f) && when (mode) {
        "saf" -> Build.VERSION.SDK_INT >= 30 && Saf.has(f)
        "shizuku", "root" -> ready
        else -> false
    }

    // Wraps text in single quotes for the shell, escaping any quotes inside it, so odd file names can't break a command.
    fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    // Shizuku's newProcess is private in the library, so we reach it with reflection.
    private fun shizukuProcess(cmd: Array<String>): Process {

        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    fun start(cmd: String, dir: File? = null): Process {
        val full = if (dir != null) "cd ${q(dir.path)} && $cmd" else cmd
        return if (mode == "root") ProcessBuilder("su", "-c", full).start()
        else shizukuProcess(arrayOf("sh", "-c", full))
    }

    private fun drainErrors(p: Process) = Thread {
        try { p.errorStream.copyTo(ByteArrayOutputStream()) } catch (_: Throwable) {}
    }.also { it.start() }

    fun run(cmd: String, dir: File? = null, timeoutSec: Long = 30): String? = try {
        val p = start(cmd, dir)
        drainErrors(p)
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(timeoutSec, TimeUnit.SECONDS)
        out
    } catch (e: Throwable) { null }

    fun ok(cmd: String, timeoutSec: Long = 120): Boolean = try {
        val p = start(cmd)
        drainErrors(p)
        p.inputStream.copyTo(ByteArrayOutputStream())
        p.waitFor(timeoutSec, TimeUnit.SECONDS) && p.exitValue() == 0
    } catch (e: Throwable) { false }

    // Checks whether the chosen access mode really works right now, and writes a plain-English status for the Settings screen.
    fun verify() {
        if (mode == "off") { ready = false; status = "Off"; return }
        if (mode == "saf") {
            Saf.reload()
            ready = Saf.anyGranted()
            status = when {
                Build.VERSION.SDK_INT < 30 -> "Not needed on this Android version. Android/data opens directly."
                ready -> "Connected · " + Saf.summary()
                Build.VERSION.SDK_INT >= 33 -> "Not set up yet. Android 13+ may refuse the folder picker; if it does, use Shizuku or root."
                else -> "Not set up yet. Grant Android/data and Android/obb below."
            }
            return
        }
        if (mode == "shizuku") {
            val problem = try {
                when {
                    !Shizuku.pingBinder() -> "Shizuku isn't running. Open Shizuku, start it, then tap here again."
                    Shizuku.isPreV11() -> "This version of Shizuku is too old. Please update it."
                    Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Shizuku is running. Tap here to grant access."
                    else -> null
                }
            } catch (e: Throwable) { "Shizuku isn't installed, or it isn't available." }
            if (problem != null) { ready = false; status = problem; return }
        }
        val id = run("id", timeoutSec = 20)?.trim().orEmpty()
        ready = id.contains("uid=0") || id.contains("uid=2000")
        status = when {
            ready -> "Connected (" + id.substringBefore(" gid").removePrefix("uid=") + ")"
            mode == "root" -> "Root isn't available. Check that your phone is rooted, and allow Linux Explorer in your root app."
            else -> "Shizuku is running, but it didn't pass our test command."
        }
    }

    // Asks Shizuku for permission, then carries on whether or not they said yes. verify() reports what actually happened.
    fun requestShizuku(onDone: () -> Unit) {
        try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { onDone(); return }
            val l = object : Shizuku.OnRequestPermissionResultListener {
                override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                    Shizuku.removeRequestPermissionResultListener(this)
                    onDone()
                }
            }
            Shizuku.addRequestPermissionResultListener(l)
            Shizuku.requestPermission(4321)
        } catch (e: Throwable) { onDone() }
    }

    private val viaSaf: Boolean get() = mode == "saf"

    fun isDir(path: String): Boolean =
        if (viaSaf) Saf.stat(File(path))?.isDir == true else ok("[ -d ${q(path)} ]", 10)

    fun names(dir: File): List<String>? =
        if (viaSaf) Saf.children(dir)?.map { it.name }
        else run("ls -1A ${q(dir.path)} 2>/dev/null", timeoutSec = 15)?.lines()?.filter { it.isNotEmpty() }

    fun listMeta(dir: File, s: Settings, query: String, cancelled: () -> Boolean = { false }): List<FileMeta>? {
        if (viaSaf) return Saf.listMeta(dir, s, query, cancelled)

        val script = "cd ${q(dir.path)} 2>/dev/null || exit 3; " +
            "stat -L -c '%F|%s|%Y|%n' ./.[!.]* ./..?* ./* 2>/dev/null"
        val out = run(script) ?: return null
        val qq = query.trim().lowercase(Locale.ROOT)
        val metas = out.lineSequence().mapNotNull { line ->
            val p = line.split('|', limit = 4)
            if (p.size < 4) return@mapNotNull null
            val name = p[3].removePrefix("./")
            if (name.isEmpty() || (!s.showHidden && name.startsWith("."))) return@mapNotNull null
            if (qq.isNotEmpty() && !name.lowercase(Locale.ROOT).contains(qq)) return@mapNotNull null
            val isDir = p[0].startsWith("directory")
            val f = File(dir, name)
            FileMeta(f, isDir, if (isDir) 0L else (p[1].toLongOrNull() ?: 0L), (p[2].toLongOrNull() ?: 0L) * 1000L,
                FileOps.kind(f, isDir), priv = true)
        }.toList()
        return FileOps.sortMetas(metas, s)
    }

    fun openIn(f: File): InputStream? =
        if (viaSaf) Saf.openIn(f)
        else try { val p = start("cat ${q(f.path)}"); drainErrors(p); p.inputStream } catch (e: Throwable) { null }

    fun readTo(src: File, out: File): Boolean {
        if (viaSaf) return try {
            out.parentFile?.mkdirs()
            Saf.openIn(src)?.use { i -> out.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            out.exists() && (out.length() > 0L || (Saf.stat(src)?.size ?: 1L) == 0L)
        } catch (e: Throwable) { false }
        return try {
            out.parentFile?.mkdirs()
            val p = start("cat ${q(src.path)}")
            drainErrors(p)
            out.outputStream().use { p.inputStream.copyTo(it) }
            p.waitFor(60, TimeUnit.SECONDS)
            out.length() > 0L || p.exitValue() == 0
        } catch (e: Throwable) { false }
    }

    fun rm(f: File) = if (viaSaf) Saf.remove(f) else ok("rm -rf ${q(f.path)}")
    fun mv(src: File, dest: File) = if (viaSaf) Saf.move(src, dest) else ok("mv -f ${q(src.path)} ${q(dest.path)}")
    fun cp(src: File, destDir: File, progress: (String) -> Unit = {}) =
        if (viaSaf) Saf.copy(src, destDir, null, progress) else ok("cp -r -f ${q(src.path)} ${q(destDir.path + "/")}")
    fun mkdir(f: File) = if (viaSaf) Saf.mkdirs(f) else ok("mkdir -p ${q(f.path)}")
    fun touch(f: File) = if (viaSaf) Saf.createFile(f) else ok("touch ${q(f.path)}")
}
