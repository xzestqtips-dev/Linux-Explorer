package com.linuxexplorer.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

// "1 item" / "3 items" so messages read like a person wrote them.
fun pluralize(n: Int, word: String): String = if (n == 1) "1 $word" else "$n ${word}s"

class FileMeta(val file: File, val isDir: Boolean, val size: Long, val modified: Long, val kind: FileOps.Kind, val priv: Boolean = false)

// Odds and ends for working with files: sorting them into kinds by extension, listing and sorting, copy and move,
// and building the intents that open or share a file.
object FileOps {

    val ARCHIVE_EXT = setOf("zip", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "7z")
    val TEXT_EXT = setOf(
        "txt", "md", "conf", "ini", "cfg", "toml", "sh", "bash", "zsh", "py", "html", "htm", "css", "js", "mjs",
        "ts", "tsx", "jsx", "json", "xml", "yml", "yaml", "sql", "csv", "log", "c", "h", "cpp", "hpp", "java",
        "kt", "kts", "gradle", "php", "rb", "go", "rs", "swift", "dart", "lua", "pl", "desktop", "service",
        "properties", "gitignore", "env", "bat", "cmd", "tex", "srt", "vtt"
    )
    private val IMAGE = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "heic", "avif")
    private val AUDIO = setOf("mp3", "flac", "wav", "ogg", "m4a", "opus", "aac", "amr")
    private val VIDEO = setOf("mp4", "mkv", "avi", "webm", "mov", "3gp", "flv")

    private val VIEWABLE: Set<String> by lazy {
        buildSet {
            addAll(listOf("png", "jpg", "jpeg", "gif", "webp", "bmp"))
            if (Build.VERSION.SDK_INT >= 28) { add("heic"); add("heif") }
            if (Build.VERSION.SDK_INT >= 31) add("avif")
        }
    }
    fun isViewable(f: File): Boolean = ext(f) in VIEWABLE
    fun isViewable(name: String): Boolean = ext(name) in VIEWABLE

    enum class Kind { FOLDER, TEXT, CODE, ARCHIVE, IMAGE, AUDIO, VIDEO, PDF, DOC, SHEET, APK, PACKAGE, EXEC, DISK, OTHER }

    fun ext(f: File): String = ext(f.name)
    fun ext(name: String): String =
        if (name.lastIndexOf('.') > 0) name.substringAfterLast('.').lowercase(Locale.ROOT) else ""

    fun isArchive(f: File): Boolean {
        if (!f.isFile) return false
        return ext(f) in ARCHIVE_EXT
    }

    fun isText(f: File): Boolean = f.isFile && (ext(f) in TEXT_EXT || ext(f).isEmpty())

    fun kind(f: File): Kind = kind(f, f.isDirectory)

    fun kind(f: File, isDir: Boolean): Kind {
        if (isDir) return Kind.FOLDER
        val e = ext(f)
        return when {
            e in ARCHIVE_EXT || e == "rar" -> Kind.ARCHIVE
            e in IMAGE -> Kind.IMAGE
            e in AUDIO -> Kind.AUDIO
            e in VIDEO -> Kind.VIDEO
            e == "pdf" -> Kind.PDF
            e in setOf("doc", "docx", "odt", "rtf", "epub") -> Kind.DOC
            e in setOf("xls", "xlsx", "ods", "csv") -> Kind.SHEET
            e == "apk" -> Kind.APK
            e in setOf("deb", "rpm", "flatpak", "snap") -> Kind.PACKAGE
            e in setOf("run", "bin", "appimage", "so") -> Kind.EXEC
            e in setOf("iso", "img") -> Kind.DISK
            e in setOf("sh", "bash", "zsh", "py", "js", "ts", "c", "cpp", "h", "java", "kt", "kts", "rs", "go", "rb", "php",
                "html", "htm", "css", "json", "xml", "yml", "yaml", "sql", "lua", "pl", "swift", "dart") -> Kind.CODE
            e in TEXT_EXT || e.isEmpty() -> Kind.TEXT
            else -> Kind.OTHER
        }
    }

    fun kindLabel(f: File): String = when (kind(f)) {
        Kind.FOLDER -> "Folder"
        Kind.TEXT -> "Text document"
        Kind.CODE -> "Source / script (${ext(f).uppercase()})"
        Kind.ARCHIVE -> "${ext(f).uppercase()} archive"
        Kind.IMAGE -> "${ext(f).uppercase()} image"
        Kind.AUDIO -> "${ext(f).uppercase()} audio"
        Kind.VIDEO -> "${ext(f).uppercase()} video"
        Kind.PDF -> "PDF document"
        Kind.DOC -> "Document"
        Kind.SHEET -> "Spreadsheet"
        Kind.APK -> "Android package"
        Kind.PACKAGE -> "Software package"
        Kind.EXEC -> "Executable / library"
        Kind.DISK -> "Disk image"
        Kind.OTHER -> "${ext(f).uppercase()} file"
    }

    fun mime(f: File): String {
        if (f.isDirectory) return "resource/folder"
        val e = ext(f)
        if (e == "apk") return "application/vnd.android.package-archive"
        if (e in TEXT_EXT) return "text/plain"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(e) ?: "*/*"
    }

    fun formatSize(b: Long, binary: Boolean = true): String {
        val k = if (binary) 1024.0 else 1000.0
        val d = b.toDouble()
        return when {
            d < k -> "$b B"
            d < k * k -> String.format(Locale.US, "%.1f KB", d / k)
            d < k * k * k -> String.format(Locale.US, "%.1f MB", d / k / k)
            else -> String.format(Locale.US, "%.2f GB", d / k / k / k)
        }
    }

    fun formatDate(ms: Long, fmt: String): String = when (fmt) {
        "locale" -> DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))
        "relative" -> {
            val s = (System.currentTimeMillis() - ms) / 1000
            val units = listOf(31536000L to "year", 2592000L to "month", 86400L to "day", 3600L to "hour", 60L to "minute")
            val u = units.firstOrNull { s >= it.first }
            if (u == null) "just now" else {
                val v = s / u.first
                "$v ${u.second}${if (v > 1) "s" else ""} ago"
            }
        }
        else -> java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))
    }

    fun perms(f: File): String {
        val sb = StringBuilder(if (f.isDirectory) "d" else "-")
        sb.append(if (f.canRead()) 'r' else '-').append(if (f.canWrite()) 'w' else '-')
            .append(if (f.canExecute()) 'x' else '-')
        return sb.toString()
    }

    fun list(dir: File, s: Settings, query: String, cancelled: () -> Boolean): List<File> =
        listMeta(dir, s, query, cancelled).map { it.file }

    // Lists a folder. With a search query it walks down through subfolders instead, stopping at 3,000 hits
    // and not following symlinks, so it can't loop forever.
    fun listMeta(dir: File, s: Settings, query: String, cancelled: () -> Boolean): List<FileMeta> {
        val q = query.trim().lowercase(Locale.ROOT)
        val out = ArrayList<File>()
        fun visible(f: File) = s.showHidden || !f.name.startsWith(".")
        if (q.isEmpty()) {
            dir.listFiles()?.forEach { if (visible(it)) out.add(it) }
        } else {
            val stack = ArrayDeque<File>()
            stack.add(dir)
            while (stack.isNotEmpty() && out.size < 3000 && !cancelled()) {
                val d = stack.removeLast()
                d.listFiles()?.forEach {
                    if (visible(it)) {
                        if (it.name.lowercase(Locale.ROOT).contains(q)) out.add(it)
                        if (it.isDirectory && !isSymlink(it)) stack.add(it)
                    }
                }
            }
        }

        return sortMetas(out.map { metaOf(it) }, s)
    }

    private fun metaOf(f: File): FileMeta = try {
        val a = Files.readAttributes(f.toPath(), BasicFileAttributes::class.java)
        val d = a.isDirectory
        FileMeta(f, d, if (d) 0L else a.size(), a.lastModifiedTime().toMillis(), kind(f, d))
    } catch (e: Throwable) {
        val d = f.isDirectory
        FileMeta(f, d, if (d) 0L else f.length(), f.lastModified(), kind(f, d))
    }

    fun sortMetas(metas: List<FileMeta>, s: Settings): List<FileMeta> {
        val dir1 = if (s.desc) -1 else 1
        val cmp: Comparator<FileMeta> = when (s.sort) {
            "size" -> compareBy<FileMeta> { if (it.isDir) 0L else it.size }
            "date" -> compareBy<FileMeta> { it.modified }
            "type" -> compareBy<FileMeta> { ext(it.file) }.thenBy { it.file.name.lowercase(Locale.ROOT) }
            else -> compareBy<FileMeta, String>(String.CASE_INSENSITIVE_ORDER) { it.file.name }
        }
        return metas.sortedWith { a, b ->
            val folderOrder = if (s.foldersFirst && a.isDir != b.isDir) (if (a.isDir) -1 else 1) else 0
            if (folderOrder != 0) folderOrder else dir1 * cmp.compare(a, b)
        }
    }

    private fun isSymlink(f: File): Boolean = try {
        Files.isSymbolicLink(f.toPath())
    } catch (e: Throwable) { true }

    fun dirSize(f: File, cancelled: () -> Boolean = { false }): Long {
        if (f.isFile) return f.length()
        var total = 0L
        val stack = ArrayDeque<File>()
        stack.add(f)
        while (stack.isNotEmpty() && !cancelled()) {
            val d = stack.removeLast()
            d.listFiles()?.forEach { if (it.isDirectory && !isSymlink(it)) stack.add(it) else total += it.length() }
        }
        return total
    }

    fun childCount(f: File): Int = f.list()?.size ?: 0

    private val counts = ConcurrentHashMap<String, Int>()
    private fun countKey(f: File, modified: Long) = f.path + "|" + modified
    fun peekCount(f: File, modified: Long): Int = counts[countKey(f, modified)] ?: -1
    fun childCountCached(f: File, modified: Long): Int {
        if (counts.size > 5000) counts.clear()
        return counts.getOrPut(countKey(f, modified)) { childCount(f) }
    }

    fun permString(f: File): String = try {
        val m = android.system.Os.lstat(f.path).st_mode
        val t = when (m and 0xF000) { 0x4000 -> 'd'; 0xA000 -> 'l'; 0x2000 -> 'c'; 0x6000 -> 'b'; 0x1000 -> 'p'; 0xC000 -> 's'; else -> '-' }
        val sb = StringBuilder().append(t)
        "rwxrwxrwx".forEachIndexed { i, ch -> sb.append(if ((m and (1 shl (8 - i))) != 0) ch else '-') }
        sb.toString()
    } catch (e: Throwable) { "----------" }

    // "photo.jpg" becomes "photo (1).jpg", then "photo (2).jpg", so a copy never overwrites anything.
    fun uniqueName(dir: File, name: String): String {
        if (!File(dir, name).exists()) return name
        val e = ext(name)
        val base = if (e.isEmpty()) name else name.dropLast(e.length + 1)
        var i = 1
        while (true) {
            val n = if (e.isEmpty()) "$base ($i)" else "$base ($i).$e"
            if (!File(dir, n).exists()) return n
            i++
        }
    }

    fun nameError(name: String): String? = when {
        name.isBlank() -> "Give it a name"
        name.contains('/') || name == "." || name == ".." -> "Names can't contain \"/\" and can't be \".\" or \"..\""
        name.length > 255 -> "That name is too long"
        else -> null
    }

    // Used to stop someone copying a folder into itself.
    fun isInside(parent: File, child: File): Boolean {
        val p = parent.canonicalPath
        val c = child.canonicalPath
        return c == p || c.startsWith(p + File.separator)
    }

    fun copyTo(src: File, destDir: File, progress: (String) -> Unit = {}): File {
        val target = File(destDir, uniqueName(destDir, src.name))
        progress(src.name)
        if (src.isDirectory) {
            target.mkdirs()
            src.listFiles()?.forEach { copyTo(it, target, progress) }
        } else {
            src.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
            target.setLastModified(src.lastModified())
        }
        return target
    }

    // Try a cheap rename first. That fails across storage volumes, so fall back to copy and then delete.
    fun moveTo(src: File, destDir: File, progress: (String) -> Unit = {}): File {
        val target = File(destDir, uniqueName(destDir, src.name))
        progress(src.name)
        if (src.renameTo(target)) return target
        copyTo(src, destDir)
        if (!src.deleteRecursively()) throw java.io.IOException("Copied ${src.name}, but couldn't delete the original")
        return target
    }

    fun internalRoot(): File = Environment.getExternalStorageDirectory()

    fun storageRoots(ctx: Context): List<Pair<String, File>> {
        val list = ArrayList<Pair<String, File>>()
        list.add("Internal storage" to internalRoot())
        val internalPath = internalRoot().path
        ctx.getExternalFilesDirs(null).filterNotNull().forEach { d ->
            val root = d.path.substringBefore("/Android/data")
            if (root != d.path && root != internalPath && list.none { it.second.path == root }) {
                list.add("SD card / USB (${File(root).name})" to File(root))
            }
        }
        return list
    }

    fun quickFolders(): List<Triple<String, String, File>> {
        val r = internalRoot()
        return listOf(
            Triple("Downloads", "download", File(r, Environment.DIRECTORY_DOWNLOADS)),
            Triple("Documents", "docs", File(r, Environment.DIRECTORY_DOCUMENTS)),
            Triple("Pictures", "pictures", File(r, Environment.DIRECTORY_PICTURES)),
            Triple("Music", "music", File(r, Environment.DIRECTORY_MUSIC)),
            Triple("Movies", "video", File(r, Environment.DIRECTORY_MOVIES)),
            Triple("DCIM", "camera", File(r, Environment.DIRECTORY_DCIM))
        ).filter { it.third.isDirectory }
    }

    fun usage(root: File): Pair<Long, Long> = try {
        val st = StatFs(root.path)
        val total = st.totalBytes
        (total - st.availableBytes) to total
    } catch (e: Exception) { 0L to 0L }

    fun hasAllFilesAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED &&
                ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED

    fun uriFor(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun openIntent(ctx: Context, f: File): Intent =
        Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(ctx, f), mime(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    fun shareIntent(ctx: Context, files: List<File>): Intent {
        val fl = files.filter { it.isFile }
        val i = if (fl.size == 1) Intent(Intent.ACTION_SEND).apply {
            type = mime(fl[0]); putExtra(Intent.EXTRA_STREAM, uriFor(ctx, fl[0]))
        } else Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(fl.map { uriFor(ctx, it) }))
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
