package com.linuxexplorer.files

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import android.util.LruCache
import android.webkit.MimeTypeMap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class AppRes(val label: String, val sub: String?, val icon: ImageBitmap, val named: Boolean)

class AppEntry(
    val label: String, val pkg: String, val version: String, val system: Boolean,
    val apk: String, val size: Long, val icon: ImageBitmap
)

// Finds names and icons for apps and APK files, and lists what's installed.
object AppIcons {
    private const val PX = 112
    private val cache = LruCache<String, AppRes>(400)
    private val misses: MutableSet<String> = ConcurrentHashMap.newKeySet()
    @Volatile private var packages: Set<String>? = null

    private val IGNORED = setOf(
        "android", "com.android.documentsui", "com.google.android.documentsui",
        "com.android.packageinstaller", "com.google.android.packageinstaller"
    )

    fun key(f: File, kind: FileOps.Kind): String? = when (kind) {
        FileOps.Kind.FOLDER -> if ('.' in f.name) "pkg:" + f.name else null
        FileOps.Kind.APK -> "apk:" + f.path + "|" + f.lastModified()
        FileOps.Kind.TEXT, FileOps.Kind.CODE, FileOps.Kind.ARCHIVE -> null
        else -> FileOps.ext(f).let { if (it.isEmpty()) null else "ext:$it" }
    }

    fun peek(key: String?): AppRes? = if (key == null) null else cache.get(key)
    fun isMiss(key: String): Boolean = key in misses

    fun load(ctx: Context, f: File, kind: FileOps.Kind): AppRes? {
        val key = key(f, kind) ?: return null
        cache.get(key)?.let { return it }
        if (key in misses) return null
        val res = try {
            when {
                key.startsWith("pkg:") -> forPackage(ctx, f.name)
                key.startsWith("apk:") -> forApk(ctx, f)
                else -> forExtension(ctx, FileOps.ext(f))
            }
        } catch (e: Throwable) { null }
        if (res != null) cache.put(key, res) else misses.add(key)
        return res
    }

    private fun installed(ctx: Context): Set<String> {
        packages?.let { return it }
        val set = ctx.packageManager.getInstalledApplications(0).map { it.packageName }.toSet()
        packages = set
        return set
    }

    private fun forPackage(ctx: Context, pkg: String): AppRes? {
        if (pkg !in installed(ctx)) return null
        val pm = ctx.packageManager
        val ai = pm.getApplicationInfo(pkg, 0)
        return AppRes(ai.loadLabel(pm).toString(), null, ai.loadIcon(pm).toBitmap(PX, PX).asImageBitmap(), true)
    }

    private fun forApk(ctx: Context, f: File): AppRes? {
        val pm = ctx.packageManager
        val pi = pm.getPackageArchiveInfo(f.path, 0) ?: return null
        val ai = pi.applicationInfo ?: return null

        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Throwable) { null }
            ?: ai.nonLocalizedLabel?.toString() ?: pi.packageName ?: f.nameWithoutExtension
        val icon = archiveIcon(pm, ai) ?: return null
        val v = pi.versionName?.let { "v$it" }
        return AppRes(label, v, icon.toBitmap(PX, PX).asImageBitmap(), true)
    }

    private fun archiveIcon(pm: PackageManager, ai: ApplicationInfo): Drawable? {
        val id = if (ai.icon != 0) ai.icon else ai.logo
        if (id != 0) {
            try {
                val res = pm.getResourcesForApplication(ai)
                ResourcesCompat.getDrawable(res, id, null)?.let { return it }
            } catch (e: Throwable) {  }
            try { ai.loadIcon(pm)?.let { return it } } catch (e: Throwable) {  }
        }
        return null
    }

    private fun forExtension(ctx: Context, ext: String): AppRes? {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: return null
        val pm = ctx.packageManager
        val own = ctx.packageName
        val intent = Intent(Intent.ACTION_VIEW).setType(mime)
        val def = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val pkg = (if (def != null && def != own && def !in IGNORED) def
        else pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .map { it.activityInfo.packageName }
            .firstOrNull { it != own && it !in IGNORED }) ?: return null
        val ai = pm.getApplicationInfo(pkg, 0)
        return AppRes(ai.loadLabel(pm).toString(), null, ai.loadIcon(pm).toBitmap(PX, PX).asImageBitmap(), false)
    }

    fun installedApps(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val out = ArrayList<AppEntry>()
        for (ai in pm.getInstalledApplications(0)) {
            try {
                val version = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
                val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                        (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                out.add(AppEntry(
                    ai.loadLabel(pm).toString(), ai.packageName, version, system,
                    ai.sourceDir ?: "", File(ai.sourceDir ?: "").length(),
                    ai.loadIcon(pm).toBitmap(PX, PX).asImageBitmap()))
            } catch (e: Throwable) {  }
        }
        return out.sortedBy { it.label.lowercase() }
    }
}
