package com.linuxexplorer.files

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

val LocalThumbs = staticCompositionLocalOf { true }

private val THUMB_EXT = setOf("png", "jpg", "jpeg", "webp", "bmp", "gif")

// In-memory cache of picture thumbnails, so scrolling a big folder doesn't decode every image again.
object Thumbs {
    private val cache = object : LruCache<String, ImageBitmap>(
        (Runtime.getRuntime().maxMemory() / 8L).toInt().coerceAtMost(48 * 1024 * 1024)
    ) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }
    private val gate = Semaphore(3)

    fun peek(key: String): ImageBitmap? = cache.get(key)

    suspend fun load(key: String, f: File): ImageBitmap? {
        cache.get(key)?.let { return it }
        val b = gate.withPermit { withContext(Dispatchers.IO) { decodeThumb(f) } }
        if (b != null) cache.put(key, b)
        return b
    }
}

@Composable
fun rememberAppRes(f: File, kind: FileOps.Kind): AppRes? {
    val ctx = LocalContext.current.applicationContext
    val key = AppIcons.key(f, kind)
    val state = produceState<AppRes?>(AppIcons.peek(key), key) {
        if (key != null && value == null && !AppIcons.isMiss(key)) {
            value = withContext(Dispatchers.IO) { AppIcons.load(ctx, f, kind) }
        }
    }
    return state.value
}

@Composable
fun FileIcon(f: File, size: Dp = 40.dp, kind: FileOps.Kind? = null, modified: Long = 0L) {
    val k = kind ?: remember(f.path) { FileOps.kind(f) }
    val isThumb = LocalThumbs.current && k == FileOps.Kind.IMAGE && FileOps.ext(f) in THUMB_EXT
    if (isThumb) {
        val tkey = f.path + "|" + modified
        val bmp by produceState<ImageBitmap?>(Thumbs.peek(tkey), tkey) {
            if (value == null) value = Thumbs.load(tkey, f)
        }
        val b = bmp
        if (b != null) {
            Box(Modifier.size(size).clip(RoundedCornerShape(6.dp))) {
                Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            return
        }
    } else if (FileTextures.has(FileOps.ext(f), k)) {
        FileTextures.Icon(FileOps.ext(f), k, size)
        return
    } else {
        val app = rememberAppRes(f, k)
        if (app != null) {
            Image(app.icon, null, Modifier.size(size).clip(RoundedCornerShape(size / 5)))
            return
        }
    }
    val (icon, color) = when (k) {
        FileOps.Kind.FOLDER -> Icons.Filled.Folder to LocalFolderColor.current
        FileOps.Kind.ARCHIVE -> Icons.Filled.FolderZip to Color(0xFFC9A45A)
        FileOps.Kind.IMAGE -> Icons.Filled.Image to Color(0xFF3F8F5F)
        FileOps.Kind.AUDIO -> Icons.Filled.AudioFile to Color(0xFF8E5CD6)
        FileOps.Kind.VIDEO -> Icons.Filled.VideoFile to Color(0xFFE5733C)
        FileOps.Kind.PDF -> Icons.Filled.PictureAsPdf to Color(0xFFD94B4B)
        FileOps.Kind.DOC -> Icons.Filled.Description to Color(0xFF2B6CC4)
        FileOps.Kind.SHEET -> Icons.Filled.TableChart to Color(0xFF2E8B57)
        FileOps.Kind.CODE -> Icons.Filled.Code to Color(0xFF5C6BC0)
        FileOps.Kind.APK -> Icons.Filled.Android to Color(0xFF3DDC84)
        FileOps.Kind.PACKAGE -> Icons.Filled.Inventory2 to Color(0xFFC9954A)
        FileOps.Kind.EXEC -> Icons.Filled.Memory to Color(0xFF6D7B8D)
        FileOps.Kind.DISK -> Icons.Filled.Album to Color(0xFF7F8DA3)
        FileOps.Kind.TEXT -> Icons.Filled.Description to Color(0xFF8A94A3)
        FileOps.Kind.OTHER -> Icons.AutoMirrored.Filled.InsertDriveFile to Color(0xFF8A94A3)
    }
    Icon(icon, null, Modifier.size(size), tint = color)
}

private fun decodeThumb(f: File): ImageBitmap? = try {
    val e = FileOps.ext(f)
    val jpeg = e == "jpg" || e == "jpeg"
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (o.outWidth / s > 192 || o.outHeight / s > 192) s *= 2

    val o2 = BitmapFactory.Options().apply { inSampleSize = s; if (jpeg) inPreferredConfig = Bitmap.Config.RGB_565 }
    var b = BitmapFactory.decodeFile(f.path, o2)
    if (b != null && jpeg) b = ImageLoader.applyExif(b, ImageLoader.exifOrientation { FileInputStream(f) })
    b?.asImageBitmap()
} catch (e: Throwable) { null }

fun displayName(f: File, showExt: Boolean, isDir: Boolean = f.isDirectory): String =
    if (showExt || isDir || FileOps.ext(f).isEmpty()) f.name else f.name.dropLast(FileOps.ext(f).length + 1)

fun fzScale(s: Settings): Float = when (s.fz) { "xs" -> .8f; "small" -> .9f; "large" -> 1.15f; "xl" -> 1.3f; else -> 1f }

fun nameWeight(s: Settings, isDir: Boolean): androidx.compose.ui.text.font.FontWeight =
    if (isDir && s.boldDirs) androidx.compose.ui.text.font.FontWeight.Bold
    else when (s.fw) {
        "light" -> androidx.compose.ui.text.font.FontWeight.Light
        "medium" -> androidx.compose.ui.text.font.FontWeight.Medium
        "bold" -> androidx.compose.ui.text.font.FontWeight.Bold
        else -> androidx.compose.ui.text.font.FontWeight.Normal
    }

fun nameFont(s: Settings): androidx.compose.ui.text.font.FontFamily? = when {
    s.monoNames -> androidx.compose.ui.text.font.FontFamily.Monospace
    s.userFont.isNotBlank() -> userFontFamily(s.userFont)
    else -> null
}

// Every file row asks for the font, so the loaded one is kept until the choice changes.
private var fontCacheRef: String? = null
private var fontCacheFamily: androidx.compose.ui.text.font.FontFamily? = null

fun clearUserFontCache() { fontCacheRef = null; fontCacheFamily = null }

// `ref` is the path of the font file the person picked. Older installs stored a font family name instead, so those still work.
private fun userFontFamily(ref: String): androidx.compose.ui.text.font.FontFamily? {
    if (ref == fontCacheRef) return fontCacheFamily
    val family = try {
        val file = File(ref)
        val face = if (file.isAbsolute) {
            if (file.isFile) android.graphics.Typeface.Builder(file).build() else null
        } else android.graphics.Typeface.create(ref, android.graphics.Typeface.NORMAL)
        face?.let { androidx.compose.ui.text.font.FontFamily(it) }
    } catch (e: Throwable) { null }
    fontCacheRef = ref; fontCacheFamily = family
    return family
}

fun nameSpacing(s: Settings): androidx.compose.ui.unit.TextUnit = when (s.ls) {
    "tight" -> (-0.02).em; "wide" -> 0.03.em; "wider" -> 0.06.em; else -> 0.em
}

fun nameColor(kind: FileOps.Kind?, dark: Boolean): Color = when (kind) {
    FileOps.Kind.FOLDER -> if (dark) Color(0xFF6CB2FF) else Color(0xFF1565C0)
    FileOps.Kind.ARCHIVE, FileOps.Kind.PACKAGE -> if (dark) Color(0xFFEF6B68) else Color(0xFFC62828)
    FileOps.Kind.IMAGE, FileOps.Kind.AUDIO, FileOps.Kind.VIDEO -> if (dark) Color(0xFFD08BE6) else Color(0xFF8E24AA)
    FileOps.Kind.EXEC, FileOps.Kind.CODE, FileOps.Kind.APK -> if (dark) Color(0xFF6FCB74) else Color(0xFF2E7D32)
    FileOps.Kind.DISK -> if (dark) Color(0xFFFFCA28) else Color(0xFFB26A00)
    else -> Color.Unspecified
}

fun nameMaxLines(s: Settings): Int = when (s.nameLines) { "two" -> 2; "full" -> Int.MAX_VALUE; else -> 1 }
