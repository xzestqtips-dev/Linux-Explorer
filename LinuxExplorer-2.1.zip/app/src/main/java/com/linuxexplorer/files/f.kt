package com.linuxexplorer.files

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Dialogs(vm: FileViewModel) {
    val close = { vm.dialog = null }
    when (val d = vm.dialog) {
        null -> Unit
        is DialogState.Input -> InputDialog(d, close)
        is DialogState.Confirm -> AlertDialog(
            onDismissRequest = close, title = { Text(d.title) }, text = { Text(d.text) },
            confirmButton = { TextButton({ close(); d.onOk() }) { Text(d.confirm) } },
            dismissButton = { TextButton(close) { Text("Cancel") } })
        is DialogState.Message -> AlertDialog(
            onDismissRequest = close, title = { Text(d.title) }, text = { Text(d.text) },
            confirmButton = { TextButton(close) { Text("Close") } })
        is DialogState.Choice -> AlertDialog(
            onDismissRequest = close, title = { Text(d.title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    d.options.forEach { (key, label) ->
                        Row(Modifier.fillMaxWidth().clickable { close(); d.onPick(key) }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = key == d.selected, onClick = { close(); d.onPick(key) })
                            Spacer(Modifier.width(8.dp)); Text(label)
                        }
                    }
                }
            },
            confirmButton = { TextButton(close) { Text("Cancel") } })
        is DialogState.Properties -> PropertiesDialog(vm, d.file, close)
        is DialogState.Compress -> CompressDialog(vm, d.files, close)
        is DialogState.ArchiveMenu -> ArchiveMenuDialog(vm, d.file, close)
        is DialogState.ArchiveBrowse -> ArchiveBrowseDialog(vm, d, close)
        is DialogState.PickDir -> PickDirDialog(vm, d, close)
    }
    vm.busy?.let { b ->
        AlertDialog(
            onDismissRequest = {}, confirmButton = {},
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(32.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(20.dp))
                    Text(b, maxLines = 4, overflow = TextOverflow.Ellipsis)
                }
            })
    }
}

@Composable
private fun InputDialog(d: DialogState.Input, close: () -> Unit) {
    var tf by remember(d) { mutableStateOf(TextFieldValue(d.initial, TextRange(0, d.initial.length))) }
    val err = d.validate(tf.text.trim())
    val fr = remember { FocusRequester() }
    LaunchedEffect(d) { fr.requestFocus() }
    val ok = tf.text.isNotBlank() && err == null
    val submit = { if (ok) { close(); d.onOk(tf.text.trim()) } }
    AlertDialog(
        onDismissRequest = close, title = { Text(d.title) },
        text = {
            OutlinedTextField(
                value = tf, onValueChange = { tf = it }, singleLine = true,
                isError = err != null && tf.text.isNotBlank(),
                supportingText = { if (err != null && tf.text.isNotBlank()) Text(err) },
                visualTransformation = if (d.password) PasswordVisualTransformation() else VisualTransformation.None,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.fillMaxWidth().focusRequester(fr))
        },
        confirmButton = { TextButton({ submit() }, enabled = ok) { Text(d.confirm) } },
        dismissButton = { TextButton(close) { Text("Cancel") } })
}

@Composable
private fun PropertiesDialog(vm: FileViewModel, f: File, close: () -> Unit) {
    val s = vm.settings
    val m = vm.metaOf(f)
    val size by produceState<Long?>(null, f.path) {
        value = if (m.priv) m.size else withContext(Dispatchers.IO) { FileOps.dirSize(f) }
    }
    @Composable
    fun row(k: String, v: String) {
        Row(Modifier.padding(vertical = 4.dp)) {
            Text(k, Modifier.width(104.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(v, fontSize = 13.sp)
        }
    }
    AlertDialog(
        onDismissRequest = close,
        icon = { FileIcon(f, 36.dp) },
        title = { Text("Properties") },
        text = {
            Column {
                row("Name", f.name)
                row("Type", FileOps.kindLabel(f))
                if (!m.isDir) row("MIME type", FileOps.mime(f))
                row("Size", size?.let { "${FileOps.formatSize(it, s.binaryUnits)} ($it B)" } ?: "Calculating…")
                if (m.isDir && !m.priv) row("Contains", "${FileOps.childCount(f)} items")
                row("Location", f.parent ?: "/")
                row("Modified", FileOps.formatDate(if (m.priv) m.modified else f.lastModified(), s.dateFmt))
                row("Access", if (m.priv) "via ${Priv.label} access" else FileOps.perms(f))
            }
        },
        confirmButton = { TextButton(close) { Text("Close") } })
}

@Composable
private fun CompressDialog(vm: FileViewModel, files: List<File>, close: () -> Unit) {
    val defaultName = if (files.size == 1) Archive.baseName(files[0]).ifEmpty { files[0].name } else vm.dir.name.ifEmpty { "archive" }
    var name by remember { mutableStateOf(defaultName) }
    var format by remember { mutableStateOf("ZIP") }
    var pw by remember { mutableStateOf("") }
    val canRun = FileOps.nameError(name.trim()) == null &&
            !(format == "GZ (single file)" && !(files.size == 1 && files[0].isFile))
    AlertDialog(
        onDismissRequest = close, title = { Text("Create archive") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") },
                    suffix = { Text(Archive.suffix(format)) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Archive.FORMATS.forEach { f ->
                        FilterChip(selected = format == f, onClick = { format = f }, label = { Text(f) })
                    }
                }
                if (format == "ZIP") {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(pw, { pw = it }, singleLine = true, label = { Text("Password (optional, AES-256)") },
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                }
                if (format == "GZ (single file)" && !canRun)
                    Text("GZ can only hold one file.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = { close(); vm.compress(files, name.trim() + Archive.suffix(format), format, pw) }, enabled = canRun) { Text("Create") }
        },
        dismissButton = { TextButton(close) { Text("Cancel") } })
}

@Composable
private fun ArchiveMenuDialog(vm: FileViewModel, f: File, close: () -> Unit) {
    val base = Archive.baseName(f)
    @Composable
    fun item(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().clickable { close(); onClick() }.padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(16.dp)); Text(label, fontSize = 16.sp)
        }
    }
    AlertDialog(
        onDismissRequest = close, title = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                item(Icons.Filled.FolderOpen, "Open archive") { vm.browseArchive(f) }
                item(Icons.Filled.Unarchive, "Extract here") { vm.extractHere(f) }
                item(Icons.Filled.CreateNewFolder, "Extract to \"$base/\"") { vm.extractToFolder(f) }
                item(Icons.Filled.Folder, "Extract to…") { vm.extractTo(f) }
                item(Icons.Filled.Info, "Properties") { vm.dialog = DialogState.Properties(f) }
            }
        },
        confirmButton = { TextButton(close) { Text("Cancel") } })
}

@Composable
private fun ArchiveBrowseDialog(vm: FileViewModel, d: DialogState.ArchiveBrowse, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        title = { Text(d.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                Text("${d.entries.size} entries", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(d.entries) { e ->
                        val unsafe = e.path.startsWith("/") || e.path.split('/').contains("..")
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (e.dir) Icons.Filled.Folder else Icons.Filled.Description, null, Modifier.size(18.dp),
                                tint = if (unsafe) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(8.dp))
                            Text(e.path, Modifier.weight(1f), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                color = if (unsafe) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                            if (!e.dir && e.size > 0) Text(FileOps.formatSize(e.size, vm.settings.binaryUnits), fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ close(); vm.extract(d.file, vm.dir, d.password) }) { Text("Extract here") } },
        dismissButton = { TextButton(close) { Text("Close") } })
}

@Composable
private fun PickDirDialog(vm: FileViewModel, d: DialogState.PickDir, close: () -> Unit) {
    var cur by remember(d) { mutableStateOf(d.start) }
    val subs by produceState(emptyList<File>(), cur.path) {
        value = withContext(Dispatchers.IO) {
            cur.listFiles { f -> f.isDirectory && (vm.settings.showHidden || !f.name.startsWith(".")) }
                ?.sortedBy { it.name.lowercase() } ?: emptyList()
        }
    }
    val rootOfCur = vm.roots.map { it.second }.filter { cur.path.startsWith(it.path) }.maxByOrNull { it.path.length }
    val canUp = rootOfCur != null && cur.path != rootOfCur.path
    AlertDialog(
        onDismissRequest = close, title = { Text(d.title) },
        text = {
            Column {
                Text(cur.path, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    if (canUp) item {
                        Row(Modifier.fillMaxWidth().clickable { cur = cur.parentFile ?: cur }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.ArrowUpward, null); Spacer(Modifier.width(12.dp)); Text("..")
                        }
                    }
                    items(subs, key = { it.path }) { f ->
                        Row(Modifier.fillMaxWidth().clickable { cur = f }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            FileIcon(f, 24.dp); Spacer(Modifier.width(12.dp)); Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (subs.isEmpty()) item { Text("No folders in here", Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        },
        confirmButton = { TextButton({ close(); d.onPick(cur) }) { Text("Select") } },
        dismissButton = { TextButton(close) { Text("Cancel") } })
}
