# Linux Explorer

A file manager for Android with a soft spot for the Linux command line. It's written in Kotlin with Jetpack Compose.

You get the everyday stuff you'd expect (browsing, copying, zipping, editing a quick note), plus a few things that Linux people tend to miss on a phone: `ls -l` style listings, colored file names, and a terminal.

## Getting it running

1. Open the project in Android Studio and let Gradle finish syncing.
2. Run it on a device or emulator with Android 8.0 or newer. Or pick **Build APK(s)** from the Build menu if you'd rather install it yourself.
3. On Android 11 and newer, the app will ask for access to all files. It needs that to show you what's actually on your storage.
4. Want a smaller release build? Run `./gradlew assembleRelease -Pminify=true`.

## What you can do with it

**Get around**
- Browse internal storage, SD cards, USB drives, and the usual folders.
- Switch between a detailed list, a grid, a compact list, or an `ls -l` style view.
- Sort however you like, show hidden files, and search through a folder and everything inside it.

**Take care of your files**
- Select a bunch of things, then copy, move, rename, duplicate, delete, share, or check their properties.
- Create, browse, and extract ZIP, TAR, TAR.GZ, TAR.BZ2, TAR.XZ, 7Z, and GZ archives. Extraction skips any entry that tries to escape the folder you picked.

**Read and write**
- Edit text and code with line numbers, syntax coloring, undo and redo, find and replace, and save as.
- View pictures in the built-in viewer. You can zoom, rotate, run a slideshow, and share from there.
- Anything the app can't open itself gets passed to another app on your phone.

**Poke around**
- Use the terminal, browse your installed apps, and back up APK files.

**Make it yours**
- Change the list style, file-name colors, row dividers, start folder, top-bar title, and image previews until it feels right.

## About `Android/data` and `Android/obb`

Android keeps these two folders away from regular apps, and the rules change from version to version. Here's where things stand:

- On Android 8 to 12, you can pick the folder once with Android's own picker and Linux Explorer will remember it.
- On Android 13 and newer, Android blocks that picker for these folders. The only ways in are Shizuku or root.
- You can set all of this up under **Settings › Access**.

Everything else works with the normal storage permissions.
