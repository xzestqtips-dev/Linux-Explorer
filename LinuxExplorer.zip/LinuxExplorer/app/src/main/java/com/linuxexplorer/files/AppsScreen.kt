package com.linuxexplorer.files

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(vm: FileViewModel) {
    BackHandler { vm.screen = Screen.Browser }
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }

    var showSystem by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<AppEntry?>(null) }
    val list = remember(vm.apps, showSystem, query) {
        vm.apps.filter {
            it.system == showSystem &&
                    (query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = LocalBar.current.container, titleContentColor = LocalBar.current.content, navigationIconContentColor = LocalBar.current.content),
                navigationIcon = { IconButton({ vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                title = { Text("Apps (${list.size})") }
            )
        },
        snackbarHost = { SnackbarHost(snack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search apps") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp))
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !showSystem, onClick = { showSystem = false }, label = { Text("Installed") })
                FilterChip(selected = showSystem, onClick = { showSystem = true }, label = { Text("System") })
            }
            Spacer(Modifier.height(4.dp))
            if (vm.appsLoading && vm.apps.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.pkg }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { picked = a }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(a.icon, null, Modifier.size(44.dp))
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.label, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${a.pkg} \u00b7 ${a.version}", fontSize = 12.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(FileOps.formatSize(a.size, vm.settings.binaryUnits), fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    picked?.let { a ->
        @Composable
        fun action(label: String, icon: ImageVector, onClick: () -> Unit) {
            Row(
                Modifier.fillMaxWidth().clickable { picked = null; onClick() }.padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, null)
                Spacer(Modifier.width(16.dp))
                Text(label, fontSize = 16.sp)
            }
        }
        AlertDialog(
            onDismissRequest = { picked = null },
            icon = { Image(a.icon, null, Modifier.size(48.dp)) },
            title = { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text(a.pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    action("Open app", Icons.Filled.PlayArrow) {
                        val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
                        if (i != null) {
                            try { ctx.startActivity(i) } catch (e: Exception) { vm.message = "Cannot open: ${e.message}" }
                        } else vm.message = "This app has no launcher"
                    }
                    action("App info", Icons.Filled.Info) {
                        try {
                            ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + a.pkg)))
                        } catch (e: Exception) { vm.message = "Cannot open app info" }
                    }
                    action("Back up APK to Download/Apps", Icons.Filled.Archive) { vm.backupApk(a) }
                    action("Browse data folder", Icons.Filled.FolderOpen) { vm.openAppData(a.pkg) }
                }
            },
            confirmButton = { TextButton({ picked = null }) { Text("Close") } }
        )
    }
}
