package com.linuxexplorer.files

import android.content.Context

data class Settings(
    // Appearance
    val theme: String = "system",      // system | light | dark
    val accent: String = "slate",      // palette key | custom
    val accentC: String = "#263238",   // hex used when accent == custom
    val amoled: Boolean = false,
    val abStyle: String = "accent",    // accent | surface
    val folderColor: String = "blue",  // blue | yellow | green | orange | purple | grey
    val radius: String = "normal",     // square | normal | round | xround
    // Text
    val fz: String = "medium",         // xs | small | medium | large | xl   (file text size)
    val uz: String = "medium",         // small | medium | large             (interface text size)
    val userFont: String = "",
    val fw: String = "regular",        // light | regular | medium | bold
    val ls: String = "normal",         // tight | normal | wide | wider
    val nameLines: String = "trunc",   // trunc | two | full
    val boldDirs: Boolean = false,
    val monoNames: Boolean = false,
    // Layout
    val view: String = "list",         // list | grid | compact
    val density: String = "comfortable", // comfortable | cozy | compact
    val iconSize: String = "medium",   // small | medium | large
    val gridSize: String = "medium",   // small | medium | large
    val showSize: Boolean = true,
    val showDate: Boolean = true,
    val showExt: Boolean = true,
    val folderCount: Boolean = true,
    val showCrumbs: Boolean = true,
    val showStatus: Boolean = false,
    val showFab: Boolean = false,
    // Files
    val sort: String = "name",         // name | size | date | type
    val desc: Boolean = false,
    val foldersFirst: Boolean = true,
    val showHidden: Boolean = false,
    val binaryUnits: Boolean = true,
    val dateFmt: String = "iso",       // iso | locale | relative
    val longPress: Boolean = true,
    val confirmDelete: Boolean = true,
    // Motion
    val anim: Boolean = true,
    val ripple: Boolean = true,
    val favorites: List<String> = emptyList()
)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lxe_settings", Context.MODE_PRIVATE)

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)

    fun load(): Settings {
        val d = Settings()
        return Settings(
            theme = s("theme", d.theme), accent = s("accent", d.accent), accentC = s("accentC", d.accentC),
            amoled = b("amoled", d.amoled), abStyle = s("abStyle", d.abStyle),
            folderColor = s("folderColor", d.folderColor), radius = s("radius", d.radius),
            fz = s("fz", d.fz), uz = s("uz", d.uz), userFont = s("userFont", d.userFont),
            fw = s("fw", d.fw), ls = s("ls", d.ls), nameLines = s("nameLines", d.nameLines),
            boldDirs = b("boldDirs", d.boldDirs), monoNames = b("monoNames", d.monoNames),
            view = s("view", d.view), density = s("density", d.density),
            iconSize = s("iconSize", d.iconSize), gridSize = s("gridSize", d.gridSize),
            showSize = b("showSize", d.showSize), showDate = b("showDate", d.showDate),
            showExt = b("showExt", d.showExt), folderCount = b("folderCount", d.folderCount),
            showCrumbs = b("showCrumbs", d.showCrumbs), showStatus = b("showStatus2", d.showStatus),
            showFab = b("showFab2", d.showFab),
            sort = s("sort", d.sort), desc = b("desc", d.desc), foldersFirst = b("foldersFirst", d.foldersFirst),
            showHidden = b("showHidden", d.showHidden), binaryUnits = b("binaryUnits", d.binaryUnits),
            dateFmt = s("dateFmt", d.dateFmt), longPress = b("longPress", d.longPress),
            confirmDelete = b("confirmDelete", d.confirmDelete),
            anim = b("anim", d.anim), ripple = b("ripple", d.ripple),
            favorites = s("favorites", "").split('\n').filter { it.isNotBlank() }
        )
    }

    fun save(v: Settings) {
        sp.edit()
            .putString("theme", v.theme).putString("accent", v.accent).putString("accentC", v.accentC)
            .putBoolean("amoled", v.amoled).putString("abStyle", v.abStyle)
            .putString("folderColor", v.folderColor).putString("radius", v.radius)
            .putString("fz", v.fz).putString("uz", v.uz).putString("userFont", v.userFont)
            .putString("fw", v.fw).putString("ls", v.ls).putString("nameLines", v.nameLines)
            .putBoolean("boldDirs", v.boldDirs).putBoolean("monoNames", v.monoNames)
            .putString("view", v.view).putString("density", v.density)
            .putString("iconSize", v.iconSize).putString("gridSize", v.gridSize)
            .putBoolean("showSize", v.showSize).putBoolean("showDate", v.showDate)
            .putBoolean("showExt", v.showExt).putBoolean("folderCount", v.folderCount)
            .putBoolean("showCrumbs", v.showCrumbs).putBoolean("showStatus2", v.showStatus)
            .putBoolean("showFab2", v.showFab)
            .putString("sort", v.sort).putBoolean("desc", v.desc).putBoolean("foldersFirst", v.foldersFirst)
            .putBoolean("showHidden", v.showHidden).putBoolean("binaryUnits", v.binaryUnits)
            .putString("dateFmt", v.dateFmt).putBoolean("longPress", v.longPress)
            .putBoolean("confirmDelete", v.confirmDelete)
            .putBoolean("anim", v.anim).putBoolean("ripple", v.ripple)
            .putString("favorites", v.favorites.joinToString("\n"))
            .apply()
    }
}
