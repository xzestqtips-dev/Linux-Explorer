package com.linuxexplorer.files

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/* ---------- lightweight syntax highlighting ---------- */

private val KEYWORDS = Regex(
    "\\b(abstract|and|as|async|await|break|case|catch|class|const|continue|def|default|del|do|elif|else|enum|except|export|extends|" +
            "false|fi|finally|for|fun|func|function|if|implements|import|in|interface|is|lambda|let|local|match|new|not|null|object|" +
            "of|or|override|package|pass|private|protected|public|raise|return|sealed|static|struct|super|switch|then|this|throw|" +
            "true|try|type|typeof|undefined|val|var|void|when|while|with|yield|echo|exit|export|select|from|where|insert|update|" +
            "delete|create|table|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|TABLE)\\b")
private val NUMBERS = Regex("\\b\\d+(?:\\.\\d+)?\\b")
private val STRINGS = Regex("\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'")
private val SLASH_COMMENTS = Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/")
private val HASH_COMMENTS = Regex("(?m)^\\s*#[^\\n]*|\\s#[^\\n]*")
private val TAGS = Regex("</?[A-Za-z][^>]*>")

private val SLASH_LANGS = setOf("c", "h", "cpp", "hpp", "java", "kt", "kts", "js", "mjs", "ts", "tsx", "jsx", "go", "rs", "swift", "dart", "php", "css", "gradle", "json")
private val HASH_LANGS = setOf("py", "sh", "bash", "zsh", "rb", "yml", "yaml", "toml", "ini", "conf", "cfg", "properties", "pl", "env", "gitignore", "desktop", "service")
private val MARKUP_LANGS = setOf("html", "htm", "xml", "svg")

private class Highlighter(val ext: String, val dark: Boolean) : VisualTransformation {
    private val key = if (dark) Color(0xFFCE93D8) else Color(0xFF8E24AA)
    private val str = if (dark) Color(0xFF81C784) else Color(0xFF2E7D32)
    private val num = if (dark) Color(0xFFFFB74D) else Color(0xFFEF6C00)
    private val com = if (dark) Color(0xFF90A4AE) else Color(0xFF78909C)
    private val tag = if (dark) Color(0xFF64B5F6) else Color(0xFF1565C0)
    private val active = ext in SLASH_LANGS || ext in HASH_LANGS || ext in MARKUP_LANGS

    override fun filter(text: AnnotatedString): TransformedText {
        if (!active || text.length > 250_000) return TransformedText(text, OffsetMapping.Identity)
        val src = text.text
        val styled = buildAnnotatedString {
            append(src)
            if (ext in MARKUP_LANGS) {
                TAGS.findAll(src).forEach { addStyle(SpanStyle(color = tag), it.range.first, it.range.last + 1) }
                STRINGS.findAll(src).forEach { addStyle(SpanStyle(color = str), it.range.first, it.range.last + 1) }
            } else {
                NUMBERS.findAll(src).forEach { addStyle(SpanStyle(color = num), it.range.first, it.range.last + 1) }
                KEYWORDS.findAll(src).forEach { addStyle(SpanStyle(color = key), it.range.first, it.range.last + 1) }
                STRINGS.findAll(src).forEach { addStyle(SpanStyle(color = str), it.range.first, it.range.last + 1) }
                val c = if (ext in HASH_LANGS) HASH_COMMENTS else SLASH_COMMENTS
                c.findAll(src).forEach { addStyle(SpanStyle(color = com, fontStyle = FontStyle.Italic), it.range.first, it.range.last + 1) }
            }
        }
        return TransformedText(styled, OffsetMapping.Identity)
    }
}

/* ---------- editor ---------- */

private sealed interface EdAsk {
    data object Find : EdAsk
    data object Replace : EdAsk
    data object SaveAs : EdAsk
    data object GoTo : EdAsk
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: FileViewModel, file: File) {
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    var target by remember(file) { mutableStateOf(file) }
    var loaded by remember(file) { mutableStateOf(false) }
    var saved by remember(file) { mutableStateOf("") }
    var tf by remember(file) { mutableStateOf(TextFieldValue("")) }
    val undo = remember(file) { ArrayDeque<String>() }
    val redo = remember(file) { ArrayDeque<String>() }
    var lastPush by remember(file) { mutableLongStateOf(0L) }
    var menu by remember { mutableStateOf(false) }
    var ask by remember { mutableStateOf<EdAsk?>(null) }
    var confirmExit by remember { mutableStateOf(false) }
    var lastFind by remember { mutableStateOf("") }

    LaunchedEffect(file) {
        val t = withContext(Dispatchers.IO) { runCatching { file.readText() }.getOrNull() }
        if (t == null) { vm.message = "Cannot read file"; vm.screen = Screen.Browser }
        else { saved = t; tf = TextFieldValue(t); loaded = true }
    }

    val dirty = loaded && tf.text != saved

    fun change(v: TextFieldValue) {
        if (v.text != tf.text) {
            val now = System.currentTimeMillis()
            if (undo.isEmpty() || now - lastPush > 700) { undo.addLast(tf.text); if (undo.size > 60) undo.removeFirst() }
            lastPush = now; redo.clear()
        }
        tf = v
    }
    fun doUndo() { if (undo.isNotEmpty()) { redo.addLast(tf.text); val t = undo.removeLast(); tf = TextFieldValue(t, TextRange(minOf(tf.selection.start, t.length))); lastPush = 0 } }
    fun doRedo() { if (redo.isNotEmpty()) { undo.addLast(tf.text); val t = redo.removeLast(); tf = TextFieldValue(t, TextRange(minOf(tf.selection.start, t.length))); lastPush = 0 } }

    fun save(after: (() -> Unit)? = null) {
        val text = tf.text; val dest = target
        scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { dest.writeText(text) }.isSuccess }
            if (ok) { saved = text; vm.refresh(); after?.invoke() ?: snack.showSnackbar("Saved ${dest.name}") }
            else snack.showSnackbar("Could not save file")
        }
    }
    fun exit() { vm.screen = Screen.Browser }
    fun tryExit() { if (dirty) confirmExit = true else exit() }

    fun findNext(q: String) {
        if (q.isEmpty()) return
        lastFind = q
        val t = tf.text
        var i = t.indexOf(q, tf.selection.end, ignoreCase = true)
        if (i < 0) i = t.indexOf(q, 0, ignoreCase = true)
        if (i >= 0) tf = tf.copy(selection = TextRange(i, i + q.length))
        else scope.launch { snack.showSnackbar("No match found") }
    }

    BackHandler { tryExit() }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = LocalBar.current.container, titleContentColor = LocalBar.current.content,
                    navigationIconContentColor = LocalBar.current.content, actionIconContentColor = LocalBar.current.content),
                navigationIcon = { IconButton({ tryExit() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                title = { Text(target.name + if (dirty) " •" else "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp) },
                actions = {
                    IconButton({ doUndo() }) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
                    IconButton({ doRedo() }) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
                    IconButton({ save() }, enabled = loaded) { Icon(Icons.Filled.Save, "Save") }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                        DropdownMenu(menu, { menu = false }) {
                            @Composable
                            fun item(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) =
                                DropdownMenuItem({ Text(label) }, { menu = false; onClick() }, leadingIcon = { Icon(icon, null) })
                            item("Save as…", Icons.Filled.Save) { ask = EdAsk.SaveAs }
                            item("Find…", Icons.Filled.Search) { ask = EdAsk.Find }
                            if (lastFind.isNotEmpty()) item("Find next", Icons.Filled.ArrowDownward) { findNext(lastFind) }
                            item("Replace all…", Icons.Filled.FindReplace) { ask = EdAsk.Replace }
                            item("Go to line…", Icons.Filled.Tag) { ask = EdAsk.GoTo }
                            item("Share", Icons.Filled.Share) { vm.share(listOf(target)) }
                            item("Open with…", Icons.Filled.Apps) { vm.openWith(target) }
                        }
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { pad ->
        if (!loaded) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val cs = MaterialTheme.colorScheme
            val dark = cs.surface.luminance() < 0.5f
            val ext = FileOps.ext(target)
            val hl = remember(ext, dark) { Highlighter(ext, dark) }
            val lines = remember(tf.text) { tf.text.count { it == '\n' } + 1 }
            val gutter = remember(lines) { (1..lines).joinToString("\n") }
            val gutterW = maxOf((lines.toString().length * 9 + 22).dp, 40.dp)
            val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 20.sp, color = cs.onSurface)
            val cfg = LocalConfiguration.current
            val vs = rememberScrollState(); val hs = rememberScrollState()
            Row(Modifier.padding(pad).fillMaxSize().verticalScroll(vs)) {
                Text(gutter, Modifier.width(gutterW).background(cs.surfaceVariant.copy(.5f)).padding(horizontal = 8.dp, vertical = 10.dp),
                    style = mono.copy(color = cs.onSurfaceVariant), textAlign = TextAlign.End)
                Box(Modifier.weight(1f).horizontalScroll(hs)) {
                    BasicTextField(
                        value = tf, onValueChange = { change(it) }, textStyle = mono,
                        cursorBrush = SolidColor(cs.secondary), visualTransformation = hl,
                        keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, capitalization = KeyboardCapitalization.None),
                        modifier = Modifier
                            .defaultMinSize(minWidth = (cfg.screenWidthDp - gutterW.value).dp, minHeight = (cfg.screenHeightDp * 0.75f).dp)
                            .padding(horizontal = 10.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }

    /* ---------- editor dialogs ---------- */
    when (ask) {
        EdAsk.Find -> EdInput("Find", "", "Find", { ask = null }) { findNext(it); ask = null }
        EdAsk.SaveAs -> EdInput("Save as", target.name, "Save", { ask = null }) { name ->
            ask = null
            val err = FileOps.nameError(name)
            val f = File(target.parentFile, name)
            if (err != null) scope.launch { snack.showSnackbar(err) }
            else if (f.exists()) scope.launch { snack.showSnackbar("A file with that name already exists") }
            else { target = f; save() }
        }
        EdAsk.GoTo -> EdInput("Go to line (1–" + (tf.text.count { it == '\n' } + 1) + ")", "", "Go", { ask = null }) { v ->
            ask = null
            val n = v.toIntOrNull()
            if (n != null && n >= 1) {
                var off = 0; var line = 1; val t = tf.text
                while (line < n) { val i = t.indexOf('\n', off); if (i < 0) break; off = i + 1; line++ }
                tf = tf.copy(selection = TextRange(off))
            }
        }
        EdAsk.Replace -> {
            var a by remember { mutableStateOf("") }
            var b by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { ask = null }, title = { Text("Replace all") },
                text = {
                    Column {
                        OutlinedTextField(a, { a = it }, singleLine = true, label = { Text("Find") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(b, { b = it }, singleLine = true, label = { Text("Replace with") }, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {
                    TextButton(enabled = a.isNotEmpty(), onClick = {
                        val n = Regex(Regex.escape(a)).findAll(tf.text).count()
                        change(tf.copy(text = tf.text.replace(a, b)))
                        ask = null
                        scope.launch { snack.showSnackbar("$n replaced") }
                    }) { Text("Replace") }
                },
                dismissButton = { TextButton({ ask = null }) { Text("Cancel") } })
        }
        null -> Unit
    }

    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false }, title = { Text("Unsaved changes") },
        text = { Text("Save changes to ${target.name} before closing?") },
        confirmButton = { TextButton({ confirmExit = false; save { exit() } }) { Text("Save") } },
        dismissButton = {
            Row {
                TextButton({ confirmExit = false }) { Text("Cancel") }
                TextButton({ confirmExit = false; exit() }) { Text("Discard") }
            }
        })
}

@Composable
private fun EdInput(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length))) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(enabled = v.text.isNotBlank(), onClick = { onOk(v.text.trim()) }) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}
