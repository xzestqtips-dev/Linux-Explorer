package com.linuxexplorer.files

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * Paper-page file icons with a texture per language / file type (same look as the HTML version):
 * source files get a coloured language band, shell scripts a dark terminal panel,
 * plain text and config files get text lines.
 */
object FileTextures {
    private class Band(val color: Color, val label: String)

    private fun band(hex: Long, label: String) = Band(Color(0xFF000000 or hex), label)

    private val BANDS: Map<String, Band> = buildMap {
        fun add(b: Band, vararg exts: String) = exts.forEach { put(it, b) }
        add(band(0xE8662C, "HTML"), "html", "htm", "xhtml")
        add(band(0x2F7FD1, "CSS"), "css", "scss", "sass", "less")
        add(band(0xD9A400, "JS"), "js", "mjs", "cjs")
        add(band(0xD9A400, "JSX"), "jsx")
        add(band(0x3178C6, "TS"), "ts")
        add(band(0x3178C6, "TSX"), "tsx")
        add(band(0x3A76A8, "PY"), "py", "pyw")
        add(band(0xB7410E, "RS"), "rs")
        add(band(0x5C6BC0, "C"), "c")
        add(band(0x5C6BC0, "H"), "h")
        add(band(0x5C6BC0, "C++"), "cpp", "cc", "cxx", "hpp")
        add(band(0x7F52FF, "KT"), "kt")
        add(band(0x7F52FF, "KTS"), "kts")
        add(band(0xC0562E, "JAVA"), "java")
        add(band(0x02303A, "GRDL"), "gradle")
        add(band(0xF05138, "SWFT"), "swift")
        add(band(0x0175C2, "DART"), "dart")
        add(band(0x2C2D72, "LUA"), "lua")
        add(band(0x39457E, "PL"), "pl", "pm")
        add(band(0x6C78B0, "PHP"), "php")
        add(band(0xC0392B, "RB"), "rb")
        add(band(0x0097A7, "GO"), "go")
        add(band(0x00796B, "SQL"), "sql")
        add(band(0x8E6BBF, "XML"), "xml")
        add(band(0x6D7B8D, "YML"), "yml", "yaml")
        add(band(0x6D7B8D, "JSON"), "json")
        add(band(0x2E8B57, "CSV"), "csv", "tsv")
        add(band(0x6D7B8D, "LOG"), "log")
        add(band(0xD4622B, "PPT"), "ppt", "pptx")
        add(band(0xD4622B, "ODP"), "odp")
        add(band(0x8A5A44, "EPUB"), "epub")
        add(band(0x7A5CCF, "Aa"), "ttf", "otf", "woff", "woff2")
        add(band(0x3584E4, "DE"), "desktop")
        add(band(0x6D7B8D, "SVC"), "service")
        add(band(0x7A5CCF, "SO"), "so")
        add(band(0x6D7B8D, "PROP"), "properties")
        add(band(0x6D7B8D, "ENV"), "env")
        add(band(0x6D7B8D, "TEX"), "tex")
    }

    private val CONSOLE = setOf("sh", "bash", "zsh", "bat", "cmd")
    private val LINES = setOf("txt", "md", "conf", "ini", "cfg", "toml", "srt", "vtt", "gitignore")

    fun has(ext: String, kind: FileOps.Kind): Boolean =
        ext in BANDS || ext in CONSOLE || ext in LINES ||
                ((kind == FileOps.Kind.CODE || kind == FileOps.Kind.TEXT) && kind != FileOps.Kind.FOLDER)

    private val paper = Color(0xFFF6F7F9)
    private val edge = Color(0xFFAAB2C0)
    private val lineGrey = Color(0xFFB4BCC9)

    private fun DrawScope.page() {
        val p = Path().apply {
            moveTo(14f, 4f); lineTo(40f, 4f); lineTo(52f, 16f); lineTo(52f, 56f)
            quadraticTo(52f, 60f, 48f, 60f); lineTo(14f, 60f)
            quadraticTo(10f, 60f, 10f, 56f); lineTo(10f, 8f)
            quadraticTo(10f, 4f, 14f, 4f); close()
        }
        drawPath(p, paper)
        drawPath(p, edge, style = Stroke(1.5f))
        val corner = Path().apply { moveTo(40f, 4f); lineTo(40f, 16f); lineTo(52f, 16f); close() }
        drawPath(corner, Color(0xFFCFD5DF)); drawPath(corner, edge, style = Stroke(1f))
    }

    private fun DrawScope.bar(x: Float, y: Float, w: Float, color: Color, h: Float = 2.5f) =
        drawRect(color, Offset(x, y), Size(w, h))

    @Composable
    fun Icon(ext: String, kind: FileOps.Kind, size: Dp) {
        val measurer = rememberTextMeasurer()
        val b = BANDS[ext]
        Canvas(Modifier.size(size)) {
            val k = this.size.minDimension / 64f
            scale(k, k, pivot = Offset.Zero) {
                page()
                when {
                    ext in CONSOLE -> {
                        drawRoundRect(Color(0xFF252A33), Offset(15f, 24f), Size(34f, 30f), CornerRadius(3f))
                        bar(19f, 29f, 8f, Color(0xFF6BD48C)); bar(29f, 29f, 12f, Color(0xFFE5A50A))
                        bar(23f, 36f, 14f, Color(0xFF6AA7FF)); bar(19f, 43f, 18f, Color(0xFFD38AFF))
                    }
                    b != null -> {
                        bar(17f, 24f, 26f, lineGrey); bar(17f, 31f, 30f, lineGrey)
                        drawRect(b.color, Offset(12f, 40f), Size(40f, 16f))
                        val fs = floatArrayOf(0f, 13f, 12f, 10.5f, 9f)[minOf(b.label.length, 4)]
                        val style = TextStyle(
                            color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif,
                            fontSize = (fs * k).toSp()
                        )
                        val layout = measurer.measure(b.label, style)
                        // measured in real pixels, so undo the 64-unit scale when positioning
                        val cx = 32f * k; val cy = 48f * k
                        drawContext.canvas.save()
                        drawContext.canvas.scale(1f / k, 1f / k)
                        drawText(layout, topLeft = Offset(cx - layout.size.width / 2f, cy - layout.size.height / 2f))
                        drawContext.canvas.restore()
                    }
                    else -> {
                        bar(17f, 24f, 26f, lineGrey); bar(17f, 31f, 30f, lineGrey)
                        bar(17f, 38f, 22f, lineGrey); bar(17f, 45f, 28f, lineGrey)
                    }
                }
            }
        }
    }
}
