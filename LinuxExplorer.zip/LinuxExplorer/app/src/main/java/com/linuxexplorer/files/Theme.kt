package com.linuxexplorer.files

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp

val BarColor = Color(0xFF263238)
val ContextBarColor = Color(0xFF455A64)
val AccentOrange = Color(0xFFFF6D00)

/** Colours of the top app bar (and the drawer header) for the current settings. */
class BarStyle(val container: Color, val content: Color)

val LocalBar = staticCompositionLocalOf { BarStyle(BarColor, Color.White) }
val LocalFolderColor = staticCompositionLocalOf { Color(0xFF62A0EA) }

/* ---------- accent palettes (same set as the HTML version) ---------- */

class Accent(val name: String, val lightPrimary: Color, val lightBar: Color, val darkPrimary: Color, val darkBar: Color)

private fun c(hex: String) = Color(android.graphics.Color.parseColor(hex))

val ACCENTS: LinkedHashMap<String, Accent> = linkedMapOf(
    "slate" to Accent("Slate", c("#37474f"), c("#263238"), c("#90a4ae"), c("#263238")),
    "teal" to Accent("Teal", c("#00796b"), c("#00796b"), c("#4db6ac"), c("#263238")),
    "blue" to Accent("Blue", c("#1976d2"), c("#1565c0"), c("#64b5f6"), c("#1c2833")),
    "purple" to Accent("Purple", c("#7b1fa2"), c("#6a1b9a"), c("#ba68c8"), c("#2b2233")),
    "green" to Accent("Green", c("#2e7d32"), c("#2e7d32"), c("#81c784"), c("#1f2d22")),
    "red" to Accent("Red", c("#c62828"), c("#c62828"), c("#e57373"), c("#331f1f")),
    "orange" to Accent("Orange", c("#e65100"), c("#e65100"), c("#ffb74d"), c("#33271a")),
    "graphite" to Accent("Graphite", c("#455a64"), c("#37474f"), c("#90a4ae"), c("#263238")),
    "pink" to Accent("Pink", c("#c2185b"), c("#ad1457"), c("#f06292"), c("#33202a")),
    "indigo" to Accent("Indigo", c("#3949ab"), c("#303f9f"), c("#7986cb"), c("#1f2233")),
    "violet" to Accent("Violet", c("#512da8"), c("#4527a0"), c("#9575cd"), c("#241f33")),
    "sky" to Accent("Sky", c("#0277bd"), c("#01579b"), c("#4fc3f7"), c("#182a36")),
    "cyan" to Accent("Cyan", c("#00838f"), c("#006064"), c("#4dd0e1"), c("#1a2c30")),
    "lime" to Accent("Lime", c("#689f38"), c("#558b2f"), c("#aed581"), c("#262d1c")),
    "amber" to Accent("Amber", c("#b26a00"), c("#8f5500"), c("#ffca28"), c("#332b17")),
    "brown" to Accent("Brown", c("#6d4c41"), c("#5d4037"), c("#a1887f"), c("#2a2220"))
)

val HEX_RE = Regex("^#[0-9a-fA-F]{6}$")

fun customAccent(hex: String): Accent {
    val h = c(hex)
    return Accent("Custom", h, lerp(h, Color.Black, .12f), lerp(h, Color.White, .35f), lerp(h, Color(0xFF1C1C1C), .82f))
}

fun accentOf(s: Settings): Accent =
    if (s.accent == "custom" && HEX_RE.matches(s.accentC)) customAccent(s.accentC)
    else ACCENTS[s.accent] ?: ACCENTS.getValue("slate")

val FOLDER_COLORS: LinkedHashMap<String, Pair<String, Color>> = linkedMapOf(
    "blue" to ("Blue" to Color(0xFF62A0EA)), "yellow" to ("Yellow" to Color(0xFFF5C542)),
    "green" to ("Green" to Color(0xFF4CB072)), "orange" to ("Orange" to Color(0xFFF08A3C)),
    "purple" to ("Purple" to Color(0xFF9B6FD6)), "grey" to ("Grey" to Color(0xFF9AA6B4))
)

@Composable
fun isDarkTheme(theme: String): Boolean = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }

/** Top-bar colours for the current settings (used by MainActivity for the system status bar as well). */
fun barStyle(s: Settings, dark: Boolean): BarStyle {
    val a = accentOf(s)
    val surface = if (dark) (if (s.amoled) Color(0xFF0B0B0B) else Color(0xFF303030)) else Color.White
    return if (s.abStyle == "surface") BarStyle(surface, if (dark) Color.White else Color(0xFF1C1B1F))
    else BarStyle(if (dark) a.darkBar else a.lightBar, Color.White)
}

private fun shapesFor(radius: String): Shapes = when (radius) {
    "square" -> Shapes(RoundedCornerShape(0.dp), RoundedCornerShape(0.dp), RoundedCornerShape(0.dp),
        RoundedCornerShape(0.dp), RoundedCornerShape(0.dp))
    "round" -> Shapes(RoundedCornerShape(8.dp), RoundedCornerShape(12.dp), RoundedCornerShape(16.dp),
        RoundedCornerShape(20.dp), RoundedCornerShape(28.dp))
    "xround" -> Shapes(RoundedCornerShape(16.dp), RoundedCornerShape(20.dp), RoundedCornerShape(24.dp),
        RoundedCornerShape(32.dp), RoundedCornerShape(40.dp))
    else -> Shapes()
}

private fun scaleOf(uz: String) = when (uz) { "small" -> .9f; "large" -> 1.12f; else -> 1f }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LxTheme(s: Settings, content: @Composable () -> Unit) {
    val dark = isDarkTheme(s.theme)
    val a = accentOf(s)
    val primary = if (dark) a.darkPrimary else a.lightPrimary
    val scheme = if (dark) darkColorScheme(
        primary = primary, onPrimary = Color(0xFF102027),
        primaryContainer = lerp(primary, Color(0xFF212121), .72f), onPrimaryContainer = Color(0xFFECEFF1),
        secondary = Color(0xFFFF9100), onSecondary = Color.Black,
        background = if (s.amoled) Color.Black else Color(0xFF212121),
        surface = if (s.amoled) Color(0xFF0B0B0B) else Color(0xFF303030),
        surfaceVariant = if (s.amoled) Color(0xFF1A1D1F) else Color(0xFF3A3F42), onSurfaceVariant = Color(0xFFB0BEC5),
        error = Color(0xFFEF5350)
    ) else lightColorScheme(
        primary = primary, onPrimary = Color.White,
        primaryContainer = lerp(primary, Color.White, .8f), onPrimaryContainer = Color(0xFF1C2833),
        secondary = AccentOrange, onSecondary = Color.White,
        background = Color(0xFFFAFAFA), surface = Color.White,
        surfaceVariant = Color(0xFFECEFF1), onSurfaceVariant = Color(0xFF546E7A),
        error = Color(0xFFD32F2F)
    )
    val d = LocalDensity.current
    val folder = (FOLDER_COLORS[s.folderColor] ?: FOLDER_COLORS.getValue("blue")).second
    CompositionLocalProvider(
        LocalBar provides barStyle(s, dark),
        LocalFolderColor provides folder,
        LocalDensity provides Density(d.density, d.fontScale * scaleOf(s.uz)),
        LocalRippleConfiguration provides (if (s.ripple) androidx.compose.material3.RippleConfiguration() else null)
    ) {
        MaterialTheme(colorScheme = scheme, shapes = shapesFor(s.radius), content = content)
    }
}
