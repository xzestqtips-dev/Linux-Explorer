package com.linuxexplorer.files

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.automirrored.filled.WrapText
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class Group(val title: String, val icon: ImageVector)

private val GROUPS = listOf(
    Group("Appearance", Icons.Filled.Palette),
    Group("Text", Icons.Filled.TextFields),
    Group("Layout", Icons.Filled.Dashboard),
    Group("Files", Icons.Filled.Folder),
    Group("Motion", Icons.Filled.Animation)
)

private val SIZES = listOf("small" to "Small", "medium" to "Medium", "large" to "Large")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: FileViewModel) {
    val s = vm.settings
    var page by rememberSaveable { mutableIntStateOf(-1) }
    var popup by rememberSaveable { mutableStateOf("") }   // "", "accent", "folder", "font"
    BackHandler { if (page >= 0) page = -1 else vm.screen = Screen.Browser }

    /* ---------- row building blocks ---------- */

    @Composable
    fun row(icon: ImageVector, title: String, sub: String? = null, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
        Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(40.dp), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp)
                if (sub != null) Text(sub, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trailing()
        }
    }

    @Composable
    fun toggle(icon: ImageVector, title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) =
        row(icon, title, sub, { onChange(!checked) }) { Switch(checked, onChange) }

    @Composable
    fun choice(icon: ImageVector, title: String, options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) =
        row(icon, title, options.firstOrNull { it.first == current }?.second ?: current,
            { vm.dialog = DialogState.Choice(title, options, current, onPick) })

    @Composable
    fun dot(color: Color) = Box(Modifier.size(20.dp).clip(CircleShape).background(color)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape))

    /* ---------- pages ---------- */

    @Composable
    fun appearance() {
        AppPreview(s)
        choice(Icons.Filled.Brightness6, "Theme", listOf("system" to "System default", "light" to "Light", "dark" to "Dark"), s.theme) { v -> vm.update { it.copy(theme = v) } }
        val acc = accentOf(s)
        row(Icons.Filled.Palette, "Accent color", if (s.accent == "custom") "Custom · ${s.accentC}" else acc.name, { popup = "accent" }) { dot(acc.lightBar) }
        toggle(Icons.Filled.DarkMode, "Pure black dark mode", "True black backgrounds when the theme is dark", s.amoled) { v -> vm.update { it.copy(amoled = v) } }
        choice(Icons.Filled.VerticalAlignTop, "App bar style", listOf("accent" to "Accent color", "surface" to "Surface color"), s.abStyle) { v -> vm.update { it.copy(abStyle = v) } }
        row(Icons.Filled.Folder, "Folder color", FOLDER_COLORS[s.folderColor]?.first ?: "Blue", { popup = "folder" }) {
            dot((FOLDER_COLORS[s.folderColor] ?: FOLDER_COLORS.getValue("blue")).second)
        }
        choice(Icons.Filled.RoundedCorner, "Corner roundness", listOf("square" to "Square", "normal" to "Default", "round" to "Rounded", "xround" to "Very rounded"), s.radius) { v -> vm.update { it.copy(radius = v) } }
    }

    @Composable
    fun text() {
        TextPreview(s)
        choice(Icons.Filled.FormatSize, "File text size", listOf("xs" to "Extra small", "small" to "Small", "medium" to "Medium", "large" to "Large", "xl" to "Extra large"), s.fz) { v -> vm.update { it.copy(fz = v) } }
        choice(Icons.Filled.TextFields, "Interface text size", SIZES, s.uz) { v -> vm.update { it.copy(uz = v) } }
        row(Icons.Filled.FontDownload, "Add your own font", if (s.userFont.isBlank()) "Enter a font family name available on your device" else s.userFont, { popup = "font" })
        choice(Icons.Filled.FormatBold, "Name weight", listOf("light" to "Light", "regular" to "Regular", "medium" to "Medium", "bold" to "Bold"), s.fw) { v -> vm.update { it.copy(fw = v) } }
        choice(Icons.Filled.SpaceBar, "Letter spacing", listOf("tight" to "Tight", "normal" to "Normal", "wide" to "Wide", "wider" to "Wider"), s.ls) { v -> vm.update { it.copy(ls = v) } }
        choice(Icons.AutoMirrored.Filled.WrapText, "Long file names", listOf("trunc" to "Truncate", "two" to "Wrap to 2 lines", "full" to "Show full name"), s.nameLines) { v -> vm.update { it.copy(nameLines = v) } }
        toggle(Icons.Filled.Folder, "Bold folder names", null, s.boldDirs) { v -> vm.update { it.copy(boldDirs = v) } }
        toggle(Icons.Filled.Code, "Monospace file names", null, s.monoNames) { v -> vm.update { it.copy(monoNames = v) } }
    }

    @Composable
    fun layout() {
        choice(Icons.AutoMirrored.Filled.ViewList, "Default view", listOf("list" to "Detailed", "grid" to "Grid", "compact" to "Compact"), s.view) { v -> vm.update { it.copy(view = v) } }
        choice(Icons.Filled.FormatLineSpacing, "List density", listOf("comfortable" to "Comfortable", "cozy" to "Cozy", "compact" to "Compact"), s.density) { v -> vm.update { it.copy(density = v) } }
        choice(Icons.Filled.PhotoSizeSelectLarge, "Icon size", SIZES, s.iconSize) { v -> vm.update { it.copy(iconSize = v) } }
        choice(Icons.Filled.GridView, "Grid tile size", SIZES, s.gridSize) { v -> vm.update { it.copy(gridSize = v) } }
        toggle(Icons.Filled.Storage, "Show file size", null, s.showSize) { v -> vm.update { it.copy(showSize = v) } }
        toggle(Icons.Filled.CalendarToday, "Show modified date", null, s.showDate) { v -> vm.update { it.copy(showDate = v) } }
        toggle(Icons.Filled.Tag, "Show file extensions", null, s.showExt) { v -> vm.update { it.copy(showExt = v) } }
        toggle(Icons.Filled.Tag, "Show item count in folders", null, s.folderCount) { v -> vm.update { it.copy(folderCount = v) } }
        toggle(Icons.Filled.LinearScale, "Show path bar", null, s.showCrumbs) { v -> vm.update { it.copy(showCrumbs = v) } }
        toggle(Icons.Filled.BorderBottom, "Show status bar", null, s.showStatus) { v -> vm.update { it.copy(showStatus = v) } }
        toggle(Icons.Filled.AddCircle, "Show floating + button", null, s.showFab) { v -> vm.update { it.copy(showFab = v) } }
    }

    @Composable
    fun files() {
        choice(Icons.AutoMirrored.Filled.Sort, "Sort by", listOf("name" to "Name", "size" to "Size", "date" to "Date", "type" to "Type"), s.sort) { v -> vm.update { it.copy(sort = v) } }
        toggle(Icons.Filled.ArrowDownward, "Descending order", null, s.desc) { v -> vm.update { it.copy(desc = v) } }
        toggle(Icons.Filled.Folder, "Folders first", null, s.foldersFirst) { v -> vm.update { it.copy(foldersFirst = v) } }
        toggle(Icons.Filled.Visibility, "Show hidden files", null, s.showHidden) { v -> vm.update { it.copy(showHidden = v) } }
        choice(Icons.Filled.Straighten, "Size units", listOf("binary" to "Binary (1 KB = 1024 B)", "decimal" to "Decimal (1 KB = 1000 B)"),
            if (s.binaryUnits) "binary" else "decimal") { v -> vm.update { it.copy(binaryUnits = v == "binary") } }
        choice(Icons.Filled.Schedule, "Date format", listOf("iso" to "ISO (2026-10-17 14:30)", "locale" to "Local format", "relative" to "Relative (3 days ago)"), s.dateFmt) { v -> vm.update { it.copy(dateFmt = v) } }
        toggle(Icons.Filled.TouchApp, "Long-press to select", null, s.longPress) { v -> vm.update { it.copy(longPress = v) } }
        toggle(Icons.Filled.Shield, "Confirm before deleting", null, s.confirmDelete) { v -> vm.update { it.copy(confirmDelete = v) } }
        row(Icons.Filled.Refresh, "Reset to defaults", null, {
            vm.dialog = DialogState.Confirm("Reset settings", "Restore all settings to their defaults?", "Reset") { vm.resetSettings() }
        })
    }

    @Composable
    fun motion() {
        toggle(Icons.Filled.Bolt, "Animations", null, s.anim) { v -> vm.update { it.copy(anim = v) } }
        toggle(Icons.Filled.WaterDrop, "Touch ripple effect", null, s.ripple) { v -> vm.update { it.copy(ripple = v) } }
    }

    /* ---------- screen ---------- */

    val bar = LocalBar.current
    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = bar.container, titleContentColor = bar.content, navigationIconContentColor = bar.content),
                navigationIcon = {
                    IconButton({ if (page >= 0) page = -1 else vm.screen = Screen.Browser }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                title = { Text(if (page >= 0) GROUPS[page].title else "Settings") })
        },
        containerColor = MaterialTheme.colorScheme.surface
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            if (page < 0) {
                GROUPS.forEachIndexed { i, g ->
                    row(g.icon, g.title, null, { page = i }) {
                        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else when (page) {
                0 -> appearance()
                1 -> text()
                2 -> layout()
                3 -> files()
                else -> motion()
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    /* ---------- popups ---------- */

    val close = { popup = "" }
    when (popup) {
        "accent" -> {
            var hex by remember { mutableStateOf(if (s.accent == "custom") s.accentC else "") }
            AlertDialog(onDismissRequest = close, title = { Text("Accent color") },
                text = {
                    Column {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            ACCENTS.forEach { (key, a) ->
                                Box(Modifier.size(44.dp).clip(CircleShape).background(a.lightPrimary)
                                    .clickable { vm.update { it.copy(accent = key) }; close() },
                                    contentAlignment = Alignment.Center) {
                                    if (s.accent == key) Icon(Icons.Filled.Check, null, tint = Color.White)
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = hex, onValueChange = { v ->
                                hex = v.trim()
                                val h = if (HEX_RE.matches(hex)) hex else if (Regex("^[0-9a-fA-F]{6}$").matches(hex)) "#$hex" else null
                                if (h != null) vm.update { it.copy(accent = "custom", accentC = h.lowercase()) }
                            },
                            label = { Text("Custom color (#rrggbb)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = { TextButton(close) { Text("Done") } })
        }
        "folder" -> AlertDialog(onDismissRequest = close, title = { Text("Folder color") },
            text = {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FOLDER_COLORS.forEach { (key, p) ->
                        Box(Modifier.size(44.dp).clip(CircleShape).background(p.second)
                            .clickable { vm.update { it.copy(folderColor = key) }; close() },
                            contentAlignment = Alignment.Center) {
                            if (s.folderColor == key) Icon(Icons.Filled.Check, null, tint = Color.White)
                        }
                    }
                }
            },
            confirmButton = { TextButton(close) { Text("Done") } })
        "font" -> {
            var name by remember { mutableStateOf(s.userFont) }
            AlertDialog(onDismissRequest = close, title = { Text("Font family name") },
                text = {
                    OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("e.g. serif, monospace, sans-serif-condensed") })
                },
                confirmButton = { TextButton({ vm.update { it.copy(userFont = name.trim()) }; close() }) { Text("OK") } },
                dismissButton = { TextButton({ vm.update { it.copy(userFont = "") }; close() }) { Text("Use default") } })
        }
    }
}

/* ---------- live previews (as in the HTML settings) ---------- */

@Composable
private fun PreviewFrame(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp).clip(MaterialTheme.shapes.medium)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
        .background(MaterialTheme.colorScheme.background), content = content)
}

@Composable
private fun AppPreview(s: Settings) {
    val bar = LocalBar.current
    PreviewFrame {
        Row(Modifier.fillMaxWidth().background(bar.container).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Files", Modifier.weight(1f), color = bar.content, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Icon(Icons.Filled.Search, null, tint = bar.content, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Filled.MoreVert, null, tint = bar.content, modifier = Modifier.size(18.dp))
        }
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Folder, null, tint = LocalFolderColor.current, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column { Text("Documents", fontSize = 15.sp); Text("12 items", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            FileTextures.Icon("txt", FileOps.Kind.TEXT, 28.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("notes.txt", fontSize = 15.sp); Text("4.2 KB · 2026-10-17", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (s.showFab) Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(AccentOrange), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Add, null, tint = Color.White)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clip(MaterialTheme.shapes.small).background(MaterialTheme.colorScheme.primary).padding(horizontal = 14.dp, vertical = 6.dp)) {
                Text("Button", color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            LinearProgressIndicator(progress = { .62f }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(12.dp))
            Text("Link", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun TextPreview(s: Settings) {
    PreviewFrame {
        listOf(
            "Documents" to true, "Quarterly_report_final_version_reviewed_2026-10-17.pdf" to false,
            "backup.sh" to false, "MainActivity.kt" to false
        ).forEach { (name, dir) ->
            val f = java.io.File(name)
            val kind = if (dir) FileOps.Kind.FOLDER else FileOps.kind(f, false)
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (dir) Icon(Icons.Filled.Folder, null, tint = LocalFolderColor.current, modifier = Modifier.size(28.dp))
                else FileTextures.Icon(FileOps.ext(f), kind, 28.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    val lines = nameMaxLines(s)
                    Text(name, fontSize = (15 * fzScale(s)).sp, fontWeight = nameWeight(s, dir), fontFamily = nameFont(s),
                        letterSpacing = nameSpacing(s), maxLines = lines,
                        overflow = if (lines == Int.MAX_VALUE) androidx.compose.ui.text.style.TextOverflow.Clip else androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text(if (dir) "12 items" else "1.1 KB · 2026-10-15", fontSize = (12 * fzScale(s)).sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
