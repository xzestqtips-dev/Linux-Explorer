package com.linuxexplorer.files

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(vm: FileViewModel, onExit: () -> Unit) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snack = remember { SnackbarHostState() }
    val selecting = vm.selected.isNotEmpty()

    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }

    BackHandler {
        when {
            drawer.isOpen -> scope.launch { drawer.close() }
            selecting -> vm.clearSelection()
            vm.searching -> vm.stopSearch()
            vm.canGoBack -> vm.back()
            !vm.atRoot -> vm.up()
            else -> onExit()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = true,
        drawerContent = { DrawerContent(vm) { scope.launch { drawer.close() } } }
    ) {
        Scaffold(
            topBar = {
                if (selecting) SelectionBar(vm) else MainBar(vm) { scope.launch { drawer.open() } }
            },
            floatingActionButton = { if (!selecting && vm.settings.showFab) NewFab(vm) },
            snackbarHost = { SnackbarHost(snack) },
            containerColor = MaterialTheme.colorScheme.background
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (vm.settings.showCrumbs) Breadcrumbs(vm)
                Box(Modifier.weight(1f).fillMaxWidth()) { FileList(vm) }
                if (vm.settings.showStatus) StatusLine(vm)
            }
        }
    }
}

/* ---------------- top bars ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainBar(vm: FileViewModel, openDrawer: () -> Unit) {
    val bar = LocalBar.current
    val colors = TopAppBarDefaults.topAppBarColors(
        containerColor = bar.container, titleContentColor = bar.content,
        navigationIconContentColor = bar.content, actionIconContentColor = bar.content
    )
    var menu by remember { mutableStateOf(false) }
    if (vm.searching) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { fr.requestFocus() }
        TopAppBar(
            colors = colors,
            navigationIcon = { IconButton({ vm.stopSearch() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close search") } },
            title = {
                TextField(
                    value = vm.query, onValueChange = { vm.updateQuery(it) }, singleLine = true,
                    placeholder = { Text("Search in this folder and below", color = bar.content.copy(.7f), fontSize = 16.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = bar.content, unfocusedTextColor = bar.content, cursorColor = bar.content
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().focusRequester(fr)
                )
            }
        )
        return
    }
    TopAppBar(
        colors = colors,
        navigationIcon = { IconButton(openDrawer) { Icon(Icons.Filled.Menu, "Menu") } },
        title = { Text("Linux Explorer", fontWeight = FontWeight.Medium) },
        actions = {
            IconButton({ vm.startSearch() }) { Icon(Icons.Filled.Search, "Search") }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                DropdownMenu(menu, { menu = false }) {
                    @Composable
                    fun item(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, checked: Boolean = false, onClick: () -> Unit) =
                        DropdownMenuItem(
                            text = { Text(label) }, leadingIcon = { Icon(icon, null) },
                            trailingIcon = if (checked) ({ Icon(Icons.Filled.Check, null) }) else null,
                            onClick = { menu = false; onClick() })
                    item("New folder", Icons.Filled.CreateNewFolder) { vm.newFolder() }
                    item("New file", Icons.Filled.NoteAdd) { vm.newFile() }
                    vm.clip?.let { c -> item("Paste here (${c.files.size})", Icons.Filled.ContentPaste) { vm.paste() } }
                    val fav = vm.isFavorite(vm.dir)
                    item(if (fav) "Remove from favorites" else "Add to favorites",
                        if (fav) Icons.Filled.Star else Icons.Filled.StarBorder) { vm.toggleFavorite(vm.dir) }
                    HorizontalDivider()
                    item("Sort by…", Icons.AutoMirrored.Filled.Sort) {
                        vm.dialog = DialogState.Choice("Sort by",
                            listOf("name" to "Name", "size" to "Size", "date" to "Date modified", "type" to "Type"),
                            vm.settings.sort) { v -> vm.update { it.copy(sort = v) } }
                    }
                    item("Descending order", Icons.Filled.ArrowDownward, vm.settings.desc) { vm.update { it.copy(desc = !it.desc) } }
                    item("View", Icons.Filled.GridView) {
                        vm.dialog = DialogState.Choice("View",
                            listOf("list" to "Detailed list", "grid" to "Grid", "compact" to "Compact"),
                            vm.settings.view) { v -> vm.update { it.copy(view = v) } }
                    }
                    item("Select all", Icons.Filled.SelectAll) { vm.selectAll() }
                    item("Show hidden files", Icons.Filled.Visibility, vm.settings.showHidden) { vm.update { it.copy(showHidden = !it.showHidden) } }
                    item("Refresh", Icons.Filled.Refresh) { vm.refresh() }
                    HorizontalDivider()
                    item("Settings", Icons.Filled.Settings) { vm.screen = Screen.Settings }
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SelectionBar(vm: FileViewModel) {
    val sel = vm.selectedFiles
    var menu by remember { mutableStateOf(false) }
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = ContextBarColor, titleContentColor = Color.White,
            navigationIconContentColor = Color.White, actionIconContentColor = Color.White),
        navigationIcon = { IconButton({ vm.clearSelection() }) { Icon(Icons.Filled.Close, "Clear selection") } },
        title = { Text("${vm.selected.size}") },
        actions = {
            IconButton({ vm.copy(sel) }) { Icon(Icons.Filled.ContentCopy, "Copy") }
            IconButton({ vm.cut(sel) }) { Icon(Icons.Filled.ContentCut, "Cut") }
            IconButton({ vm.dialog = DialogState.Compress(sel) }) { Icon(Icons.Filled.Archive, "Compress") }
            IconButton({ vm.delete(sel) }) { Icon(Icons.Filled.Delete, "Delete") }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                DropdownMenu(menu, { menu = false }) {
                    @Composable
                    fun item(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) =
                        DropdownMenuItem(text = { Text(label) }, leadingIcon = { Icon(icon, null) },
                            onClick = { menu = false; onClick() })
                    val one = sel.singleOrNull()
                    if (one != null) item("Open", Icons.Filled.FolderOpen) { vm.clearSelection(); vm.open(one) }
                    if (one != null && !one.isDirectory) item("Open with…", Icons.Filled.Apps) { vm.openWith(one) }
                    if (one != null) item("Rename", Icons.Filled.Edit) { vm.rename(one) }
                    item("Copy to…", Icons.Filled.FileCopy) { vm.pickAndTransfer(sel, false) }
                    item("Move to…", Icons.Filled.ContentCut) { vm.pickAndTransfer(sel, true) }
                    item("Duplicate", Icons.Filled.ContentCopy) { vm.duplicate(sel) }
                    if (one != null && FileOps.isArchive(one)) item("Extract…", Icons.Filled.Unarchive) { vm.dialog = DialogState.ArchiveMenu(one) }
                    item("Share", Icons.Filled.Share) { vm.share(sel) }
                    if (one != null && one.isDirectory) {
                        val fav = vm.isFavorite(one)
                        item(if (fav) "Remove from favorites" else "Add to favorites", Icons.Filled.Star) { vm.toggleFavorite(one); vm.clearSelection() }
                    }
                    if (one != null) item("Properties", Icons.Filled.Info) { vm.dialog = DialogState.Properties(one) }
                    HorizontalDivider()
                    item("Select all", Icons.Filled.SelectAll) { vm.selectAll() }
                    item("Invert selection", Icons.Filled.FlipToFront) { vm.invertSelection() }
                }
            }
        }
    )
}

/* ---------------- FAB ---------------- */

@Composable
private fun NewFab(vm: FileViewModel) {
    var open by remember { mutableStateOf(false) }
    Box {
        FloatingActionButton(
            onClick = { open = true },
            containerColor = AccentOrange, contentColor = Color.White
        ) { Icon(Icons.Filled.Add, "New") }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text("New folder") }, { open = false; vm.newFolder() },
                leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) })
            DropdownMenuItem({ Text("New file") }, { open = false; vm.newFile() },
                leadingIcon = { Icon(Icons.Filled.NoteAdd, null) })
            vm.clip?.let { c ->
                DropdownMenuItem({ Text("Paste here (${c.files.size})") }, { open = false; vm.paste() },
                    leadingIcon = { Icon(Icons.Filled.ContentPaste, null) })
            }
        }
    }
}

/* ---------------- breadcrumbs ---------------- */

@Composable
private fun Breadcrumbs(vm: FileViewModel) {
    val root = vm.currentRoot
    val rootLabel = if (root.path == vm.internalRoot.path) "Internal" else root.name.ifEmpty { "/" }
    val rel = remember(vm.dir.path, root.path) {
        vm.dir.path.removePrefix(root.path).split('/').filter { it.isNotEmpty() }
    }
    val scroll = rememberScrollState()
    LaunchedEffect(vm.dir.path) { delay(60); scroll.scrollTo(scroll.maxValue) }
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.up() }, enabled = !vm.atRoot) { Icon(Icons.Filled.ArrowUpward, "Up") }
            Row(Modifier.weight(1f).horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically) {
                @Composable
                fun crumb(label: String, target: File, last: Boolean) {
                    Text(label, fontSize = 14.sp,
                        fontWeight = if (last) FontWeight.Medium else FontWeight.Normal,
                        color = if (last) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { vm.navigate(target) }.padding(horizontal = 6.dp, vertical = 10.dp))
                }
                crumb(rootLabel, root, rel.isEmpty())
                var acc = root
                rel.forEachIndexed { i, seg ->
                    acc = File(acc, seg)
                    Text("/", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(.5f))
                    crumb(seg, acc, i == rel.lastIndex)
                }
            }
            IconButton({ vm.goToPath() }) { Icon(Icons.Filled.Edit, "Edit path", Modifier.size(20.dp)) }
        }
    }
    HorizontalDivider()
}

/* ---------------- list / grid ---------------- */

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileList(vm: FileViewModel) {
    val haptic = LocalHapticFeedback.current
    val s = vm.settings
    val files = vm.items
    fun click(f: File) { if (vm.selected.isNotEmpty()) vm.toggle(f) else vm.open(f) }
    fun long(f: File) { haptic.performHapticFeedback(HapticFeedbackType.LongPress); if (f.path in vm.selected) vm.toggle(f) else vm.select(f) }

    if (files.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (vm.loading) CircularProgressIndicator()
            else Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Filled.FolderOpen, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(.35f))
                Spacer(Modifier.height(12.dp))
                Text(
                    if (vm.query.isNotEmpty()) "No matches for \"${vm.query}\"" else if (vm.dir.canRead()) "This folder is empty" else "Can't read this folder",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }
    if (s.view == "grid") {
        val tile = when (s.gridSize) { "small" -> 80.dp; "large" -> 128.dp; else -> 96.dp }
        val gi = when (s.iconSize) { "small" -> 44.dp; "large" -> 72.dp; else -> 56.dp }
        LazyVerticalGrid(GridCells.Adaptive(tile), Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 96.dp)) {
            items(files, key = { it.path }) { f ->
                val m = vm.metaOf(f)
                val sel = f.path in vm.selected
                Column(
                    (if (s.anim) Modifier.animateItem() else Modifier).padding(2.dp)
                        .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent, MaterialTheme.shapes.small)
                        .combinedClickable(onClick = { click(f) }, onLongClick = if (s.longPress) ({ long(f) }) else null)
                        .padding(horizontal = 4.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    FileIcon(f, gi, m.kind, m.modified)
                    Spacer(Modifier.height(6.dp))
                    FileName(f, s, m.isDir, 13f, center = true, maxLinesOverride = if (s.nameLines == "trunc") 2 else null)
                }
            }
        }
    } else {
        val compact = s.view == "compact"
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
            items(files, key = { it.path }) { f ->
                FileRow(f, vm.metaOf(f), f.path in vm.selected, compact, s,
                    onClick = { click(f) }, onLong = if (s.longPress) ({ long(f) }) else null,
                    onIcon = { if (vm.selected.isEmpty() || f.path !in vm.selected) vm.select(f) else vm.toggle(f) },
                    modifier = if (s.anim) Modifier.animateItem() else Modifier)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(f: File, m: FileMeta, selected: Boolean, compact: Boolean, s: Settings,
                    onClick: () -> Unit, onLong: (() -> Unit)?, onIcon: () -> Unit, modifier: Modifier = Modifier) {
    val wantCount = m.isDir && s.folderCount
    val count by produceState(if (wantCount) FileOps.peekCount(f, m.modified) else -1, f.path, m.modified, wantCount) {
        if (wantCount && value < 0) value = withContext(Dispatchers.IO) { FileOps.childCountCached(f, m.modified) }
    }
    val appRes = if (m.kind == FileOps.Kind.APK || m.kind == FileOps.Kind.FOLDER) rememberAppRes(f, m.kind) else null
    val parts = buildList {
        if (appRes != null && appRes.named) add(appRes.label + (appRes.sub?.let { v -> " $v" } ?: ""))
        if (m.isDir) { if (s.folderCount && count >= 0) add("$count ${if (count == 1) "item" else "items"}") }
        else if (s.showSize) add(FileOps.formatSize(m.size, s.binaryUnits))
        if (s.showDate) add(FileOps.formatDate(m.modified, s.dateFmt))
    }
    val fz = fzScale(s)
    val pad = when (s.density) { "compact" -> 4; "cozy" -> 7; else -> 10 }.let { if (compact) maxOf(2, it - 4) else it }
    val icon = when (s.iconSize) { "small" -> if (compact) 20 else 32; "large" -> if (compact) 28 else 48; else -> if (compact) 26 else 40 }
    Row(
        modifier.fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 16.dp, vertical = pad.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size((icon + 2).dp).clickable(onClick = onIcon), contentAlignment = Alignment.Center) {
            FileIcon(f, icon.dp, m.kind, m.modified)
        }
        Spacer(Modifier.width(16.dp))
        if (compact) {
            FileName(f, s, m.isDir, 15f, Modifier.weight(1f))
            if (parts.isNotEmpty()) Text(parts.first(), fontSize = (12 * fz).sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Column(Modifier.weight(1f)) {
                FileName(f, s, m.isDir, 16f)
                if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = (13 * fz).sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** File name drawn with the name-related settings (size, weight, font, spacing, wrapping). */
@Composable
private fun FileName(f: File, s: Settings, isDir: Boolean, baseSp: Float, modifier: Modifier = Modifier,
                     center: Boolean = false, maxLinesOverride: Int? = null) {
    val lines = maxLinesOverride ?: nameMaxLines(s)
    Text(
        displayName(f, s.showExt, isDir), modifier,
        fontSize = (baseSp * fzScale(s)).sp, fontWeight = nameWeight(s, isDir),
        fontFamily = nameFont(s), letterSpacing = nameSpacing(s),
        maxLines = lines, overflow = if (lines == Int.MAX_VALUE) TextOverflow.Clip else TextOverflow.Ellipsis,
        textAlign = if (center) TextAlign.Center else TextAlign.Unspecified
    )
}

@Composable
private fun StatusLine(vm: FileViewModel) {
    val total = remember(vm.items) { vm.items.sumOf { f -> val m = vm.metaOf(f); if (m.isDir) 0L else m.size } }
    HorizontalDivider()
    Text(
        (if (vm.selected.isNotEmpty()) "${vm.selected.size} selected · " else "") +
                "${vm.items.size} items · ${FileOps.formatSize(total, vm.settings.binaryUnits)} · ${vm.dir.path}",
        fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

/* ---------------- drawer ---------------- */

@Composable
private fun DrawerContent(vm: FileViewModel, close: () -> Unit) {
    val bar = LocalBar.current
    val (used, total) = remember(vm.dir.path, vm.items) { FileOps.usage(vm.currentRoot) }
    ModalDrawerSheet(Modifier.width(300.dp)) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth().background(bar.container).padding(16.dp).padding(top = 24.dp)) {
                Image(painterResource(R.drawable.app_logo), null, Modifier.size(48.dp))
                Spacer(Modifier.height(14.dp))
                Text("Linux Explorer", color = bar.content, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(vm.currentRoot.path, color = bar.content.copy(.75f), fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (total > 0) used.toFloat() / total else 0f },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = bar.content, trackColor = bar.content.copy(.3f))
                Spacer(Modifier.height(4.dp))
                Text("${FileOps.formatSize(used, vm.settings.binaryUnits)} used of ${FileOps.formatSize(total, vm.settings.binaryUnits)}",
                    color = bar.content.copy(.85f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            @Composable
            fun entry(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean = false, onClick: () -> Unit) =
                NavigationDrawerItem(
                    label = { Text(label) }, icon = { Icon(icon, null) }, selected = selected,
                    onClick = { close(); onClick() },
                    modifier = Modifier.padding(horizontal = 8.dp),
                    colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer))
            vm.roots.forEach { (label, f) ->
                entry(label, if (f.path == vm.internalRoot.path) Icons.Filled.Home else Icons.Filled.SdCard, vm.dir.path == f.path) { vm.navigate(f) }
            }
            entry("Apps", Icons.Filled.Android) { vm.loadApps(); vm.screen = Screen.Apps }
            entry("Text editor", Icons.Filled.TextFields) { vm.newDocument() }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            FileOps.quickFolders().forEach { (label, key, f) ->
                val icon = when (key) {
                    "download" -> Icons.Filled.Download; "docs" -> Icons.Filled.Description
                    "pictures" -> Icons.Filled.Image; "music" -> Icons.Filled.MusicNote
                    "video" -> Icons.Filled.Movie; else -> Icons.Filled.CameraAlt
                }
                entry(label, icon, vm.dir.path == f.path) { vm.navigate(f) }
            }
            val favs = vm.settings.favorites.map { File(it) }.filter { it.isDirectory }
            if (favs.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("Favorites", Modifier.padding(start = 28.dp, bottom = 4.dp), fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                favs.forEach { f -> entry(f.name.ifEmpty { f.path }, Icons.Filled.Star, vm.dir.path == f.path) { vm.navigate(f) } }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            entry("Settings", Icons.Filled.Settings) { vm.screen = Screen.Settings }
            Spacer(Modifier.height(16.dp))
        }
    }
}
