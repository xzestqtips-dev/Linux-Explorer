package com.linuxexplorer.files

import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.ArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

class PasswordRequired : Exception("This archive is password protected")

object Archive {

    val FORMATS = listOf("ZIP", "TAR.GZ", "TAR", "TAR.BZ2", "TAR.XZ", "7Z", "GZ (single file)")

    fun suffix(format: String) = when (format) {
        "ZIP" -> ".zip"; "TAR.GZ" -> ".tar.gz"; "TAR" -> ".tar"; "TAR.BZ2" -> ".tar.bz2"
        "TAR.XZ" -> ".tar.xz"; "7Z" -> ".7z"; else -> ".gz"
    }

    fun baseName(f: File): String {
        val n = f.name
        for (s in listOf(".tar.gz", ".tar.bz2", ".tar.xz")) if (n.endsWith(s, true)) return n.dropLast(s.length)
        return if (n.contains('.')) n.substringBeforeLast('.') else n
    }

    /* ---------- create ---------- */

    fun create(files: List<File>, dest: File, format: String, password: String?, progress: (String) -> Unit) {
        try {
            when (format) {
                "ZIP" -> createZip(files, dest, password, progress)
                "7Z" -> create7z(files, dest, progress)
                "GZ (single file)" -> {
                    require(files.size == 1 && files[0].isFile) { "GZ compresses exactly one file" }
                    progress(files[0].name)
                    GzipCompressorOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { o ->
                        FileInputStream(files[0]).use { it.copyTo(o, 64 * 1024) }
                    }
                }
                else -> createTar(files, dest, format, progress)
            }
        } catch (e: Exception) {
            dest.delete(); throw e
        }
    }

    private fun createZip(files: List<File>, dest: File, password: String?, progress: (String) -> Unit) {
        val pw = password?.takeIf { it.isNotEmpty() }
        val zf = if (pw != null) ZipFile(dest, pw.toCharArray()) else ZipFile(dest)
        val p = ZipParameters()
        if (pw != null) {
            p.isEncryptFiles = true
            p.encryptionMethod = EncryptionMethod.AES
            p.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
        }
        files.forEach { f ->
            progress(f.name)
            if (f.isDirectory) zf.addFolder(f, p) else zf.addFile(f, p)
        }
    }

    private fun createTar(files: List<File>, dest: File, format: String, progress: (String) -> Unit) {
        val raw = BufferedOutputStream(FileOutputStream(dest))
        val wrapped: java.io.OutputStream = when (format) {
            "TAR.GZ" -> GzipCompressorOutputStream(raw)
            "TAR.BZ2" -> BZip2CompressorOutputStream(raw)
            "TAR.XZ" -> XZCompressorOutputStream(raw)
            else -> raw
        }
        TarArchiveOutputStream(wrapped).use { tos ->
            tos.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            tos.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
            fun add(f: File, base: String) {
                val name = base + f.name + if (f.isDirectory) "/" else ""
                progress(name)
                tos.putArchiveEntry(TarArchiveEntry(f, name))
                if (f.isFile) FileInputStream(f).use { it.copyTo(tos, 64 * 1024) }
                tos.closeArchiveEntry()
                if (f.isDirectory) f.listFiles()?.forEach { add(it, name) }
            }
            files.forEach { add(it, "") }
        }
    }

    private fun create7z(files: List<File>, dest: File, progress: (String) -> Unit) {
        SevenZOutputFile(dest).use { out ->
            val buf = ByteArray(64 * 1024)
            fun add(f: File, base: String) {
                val name = base + f.name + if (f.isDirectory) "/" else ""
                progress(name)
                out.putArchiveEntry(out.createArchiveEntry(f, name))
                if (f.isFile) FileInputStream(f).use { ins ->
                    var n = ins.read(buf)
                    while (n >= 0) { out.write(buf, 0, n); n = ins.read(buf) }
                }
                out.closeArchiveEntry()
                if (f.isDirectory) f.listFiles()?.forEach { add(it, name) }
            }
            files.forEach { add(it, "") }
        }
    }

    /* ---------- list ---------- */

    data class Entry(val path: String, val size: Long, val dir: Boolean)

    fun list(archive: File, password: String?): List<Entry> {
        val n = archive.name.lowercase()
        return when {
            n.endsWith(".zip") -> {
                val zf = zip(archive, password)
                zf.fileHeaders.map { Entry(it.fileName, it.uncompressedSize, it.isDirectory) }
            }
            n.endsWith(".7z") -> {
                val out = ArrayList<Entry>()
                openSevenZ(archive).use { sz ->
                    var e = sz.nextEntry
                    while (e != null) { out.add(Entry(e.name, e.size, e.isDirectory)); e = sz.nextEntry }
                }
                out
            }
            isTar(n) -> {
                val out = ArrayList<Entry>()
                TarArchiveInputStream(tarStream(archive)).use { t ->
                    var e: ArchiveEntry? = t.nextEntry
                    while (e != null) { out.add(Entry(e.name, e.size, e.isDirectory)); e = t.nextEntry }
                }
                out
            }
            n.endsWith(".gz") || n.endsWith(".bz2") || n.endsWith(".xz") ->
                listOf(Entry(baseName(archive), 0, false))
            else -> throw IllegalArgumentException("Unsupported archive type")
        }
    }

    /* ---------- extract ---------- */

    fun extract(archive: File, dest: File, password: String?, progress: (String) -> Unit) {
        dest.mkdirs()
        val n = archive.name.lowercase()
        when {
            n.endsWith(".zip") -> {
                val zf = zip(archive, password)
                progress(archive.name)
                zf.extractAll(dest.path)
            }
            n.endsWith(".7z") -> openSevenZ(archive).use { sz ->
                val buf = ByteArray(64 * 1024)
                var e = sz.nextEntry
                while (e != null) {
                    val t = safeTarget(dest, e.name)
                    if (t != null) {
                        progress(e.name)
                        if (e.isDirectory) t.mkdirs() else {
                            t.parentFile?.mkdirs()
                            FileOutputStream(t).use { o ->
                                var c = sz.read(buf)
                                while (c >= 0) { o.write(buf, 0, c); c = sz.read(buf) }
                            }
                        }
                    }
                    e = sz.nextEntry
                }
            }
            isTar(n) -> TarArchiveInputStream(tarStream(archive)).use { t ->
                var e: ArchiveEntry? = t.nextEntry
                while (e != null) {
                    val target = safeTarget(dest, e.name)
                    if (target != null) {
                        progress(e.name)
                        if (e.isDirectory) target.mkdirs() else {
                            target.parentFile?.mkdirs()
                            FileOutputStream(target).use { o -> t.copyTo(o, 64 * 1024) }
                        }
                    }
                    e = t.nextEntry
                }
            }
            n.endsWith(".gz") || n.endsWith(".bz2") || n.endsWith(".xz") -> {
                val out = File(dest, FileOps.uniqueName(dest, baseName(archive)))
                progress(out.name)
                singleStream(archive).use { ins -> FileOutputStream(out).use { ins.copyTo(it, 64 * 1024) } }
            }
            else -> throw IllegalArgumentException("Unsupported archive type")
        }
    }

    fun needsPassword(archive: File): Boolean =
        archive.name.lowercase().endsWith(".zip") && try { ZipFile(archive).isEncrypted } catch (e: Exception) { false }

    /* ---------- helpers ---------- */

    private fun zip(f: File, password: String?): ZipFile {
        val zf = ZipFile(f)
        if (zf.isEncrypted) {
            if (password.isNullOrEmpty()) throw PasswordRequired()
            zf.setPassword(password.toCharArray())
        }
        return zf
    }

    private fun openSevenZ(f: File): SevenZFile = SevenZFile.builder().setFile(f).get()

    private fun isTar(n: String) = n.endsWith(".tar") || n.endsWith(".tar.gz") || n.endsWith(".tgz") ||
            n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tar.xz") || n.endsWith(".txz")

    private fun tarStream(f: File): InputStream {
        val n = f.name.lowercase()
        val raw = BufferedInputStream(FileInputStream(f))
        return when {
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> GzipCompressorInputStream(raw)
            n.endsWith(".tar.bz2") || n.endsWith(".tbz2") -> BZip2CompressorInputStream(raw)
            n.endsWith(".tar.xz") || n.endsWith(".txz") -> XZCompressorInputStream(raw)
            else -> raw
        }
    }

    private fun singleStream(f: File): InputStream {
        val n = f.name.lowercase()
        val raw = BufferedInputStream(FileInputStream(f))
        return when {
            n.endsWith(".gz") -> GzipCompressorInputStream(raw)
            n.endsWith(".bz2") -> BZip2CompressorInputStream(raw)
            else -> XZCompressorInputStream(raw)
        }
    }

    /** Blocks entries that would escape the destination folder (zip-slip). */
    private fun safeTarget(dest: File, name: String): File? {
        val t = File(dest, name)
        val base = dest.canonicalPath
        val c = t.canonicalPath
        return if (c == base || c.startsWith(base + File.separator)) t else null
    }
}
