# Linux Explorer (Android, Kotlin)

Native file manager built with Kotlin + Jetpack Compose. No web view, no HTML.

## Build
1. Open this folder in **Android Studio** (Koala or newer) and let Gradle sync.
2. Run on a device / emulator (Android 8.0+, minSdk 26), or **Build > Build APK(s)**.
3. On first launch tap **Allow access to all files** (Android 11+ opens the
   "All files access" screen; Android 8–10 shows the normal storage prompt).

## Features
- Full internal storage + SD card / USB roots, quick folders, favorites
- List / grid / compact views, sort by name / size / date / type, hidden files, recursive search
- Multi-select: copy, cut, paste, copy to… / move to…, duplicate, rename, delete, share, properties
- ZIP (AES-256 password), TAR, TAR.GZ, TAR.BZ2, TAR.XZ, 7Z, GZ — create, browse, extract
  (path-traversal entries are blocked on extract)
- Built-in text / code editor: line numbers, syntax colors, undo/redo, find, replace all, go to line, save as
- Opens any other file type with the system's apps via FileProvider
